﻿using OzNet;
using ICD;
using System;
using System.Net.Sockets;
using System.Windows;
using OzUtil;
using System.Runtime.InteropServices;
using System.Windows.Controls;

namespace TestServer
{
    public partial class MainWindow : Window
    {
        private TCPServer m_server;
        private Socket m_clientSocket;
        private const byte SIMSW_ID = 0x01;

        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
            this.Closing += MainWindow_Closing;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            m_server = new TCPServer(9112);
            m_server.Event_NotifyConnectClient += OnClientConnected;
            m_server.Event_NotifyDisconnectClient += OnClientDisconnected;
            m_server.Event_NotifyReceived += OnDataReceived;
            m_server.StartServer();
            LogEvent("서버 시작 PORT 9112. 운용 대기");
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            m_server?.StopServer();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 새로운 클라이언트가 접속했을 때 호출되는 이벤트 핸들러입니다.
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        /// <param name="clientSocket"> [in] 새로 접속한 클라이언트의 소켓 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void OnClientConnected(Socket clientSocket)
        {
            m_clientSocket = clientSocket;
            LogEvent($"연동 접속: {clientSocket.RemoteEndPoint} ");
            //Dispatcher.Invoke(() => sendAngleButton.IsEnabled = true);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 클라이언트의 접속이 끊어졌을 때 호출되는 이벤트 핸들러입니다.
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        /// <param name="clientSocket"> [in] 접속이 끊어진 클라이언트의 소켓 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void OnClientDisconnected(Socket clientSocket)
        {
            // 이벤트 로그 창에 접속 해제 메시지를 출력합니다.
            LogEvent($"연동 해제: {clientSocket.RemoteEndPoint}");
            m_clientSocket = null;
            Dispatcher.Invoke(() => sendAngleButton.IsEnabled = false);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 클라이언트로부터 데이터를 수신했을 때 호출되는 이벤트 핸들러입니다.
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        /// <param name="clientSocket"> [in] 데이터를 수신한 클라이언트의 소켓 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void OnDataReceived(Socket clientSocket)
        {
            try
            {
                int headerSize = Marshal.SizeOf<T_Header>();
                byte[] headerBytes = m_server.Recieve(clientSocket, headerSize);
                if (headerBytes == null) return;

                T_Header rawHeader = MarshalHelper.ByteToStructure<T_Header>(headerBytes, headerBytes.Length);

                // ✨ [수정] 로그에 표시할 모든 헤더 정보를 Endian 변환하여 변수에 저장
                ushort identifier = Endian.Swap(rawHeader.identifier);
                ushort totalSize = Endian.Swap(rawHeader.unSize);
                ushort messageId = Endian.Swap(rawHeader.unMessageId);
                byte senderId = rawHeader.bySenderId;
                byte receiverId = rawHeader.byReceiverId;

                int bodySize = totalSize - headerSize;
                if (bodySize < 0) { /*...*/ return; }
                byte[] bodyBytes = m_server.Recieve(clientSocket, bodySize);
                if (bodyBytes == null) return;

                byte[] fullPacketBytes = new byte[totalSize];
                Buffer.BlockCopy(headerBytes, 0, fullPacketBytes, 0, headerSize);
                Buffer.BlockCopy(bodyBytes, 0, fullPacketBytes, headerSize, bodySize);

                // ✨ [수정] 변환된 헤더 정보들을 각 처리 메서드로 전달
                switch (messageId)
                {
                    case ICD_RDR.MSG_ID_PAN_TILT_ACK:
                    case ICD_RDR.MSG_ID_LOGIN_ACK:
                    case ICD_RDR.MSG_ID_A_ZOOM_CTRL_ACK:
                    case ICD_RDR.MSG_ID_STATUS_REQ_ACK:
                        ProcessEventPacket(messageId, fullPacketBytes, identifier, totalSize, bodySize, senderId, receiverId);
                        break;

                    case ICD_RDR.MSG_ID_GPS_DATA_ACK:
                        ProcessGpsPacket(fullPacketBytes, identifier, totalSize, bodySize, senderId, receiverId);
                        break;

                    default:
                        LogEvent($"[WARNING] Received Unknown Packet | ID: 0x{messageId:X4}, Size: {totalSize}, From: {senderId}, To: {receiverId}");
                        break;
                }
            }
            catch (Exception ex)
            {
                LogEvent($"[FATAL ERROR] An exception occurred during receive process: {ex.Message}");
            }
        }

        private void ProcessEventPacket(ushort messageId, byte[] fullPacketBytes, ushort identifier, ushort totalSize, int bodySize, byte senderId, byte receiverId)
        {
            string logMsg = "";
            string headerInfo = $"identifier: 0x{identifier:X4}, bySenderId: {senderId}, byReceiverId: {receiverId}, " +
                                $"unMessageId: 0x{messageId:X4}, unSize: {totalSize} | ";

            switch (messageId)
            {
                case ICD_RDR.MSG_ID_PAN_TILT_ACK:
                    var dirPacket = MarshalHelper.ByteToStructure<T_AckDirection>(fullPacketBytes, fullPacketBytes.Length);
                    ushort pan = Endian.Swap(dirPacket.unPan);
                    short tilt = Endian.Swap(dirPacket.sTilt);
                    logMsg = $"[RECV] 방위각 고각 ACK | {headerInfo}unPan: {pan}, sTilt: {tilt}";
                    break;
                case ICD_RDR.MSG_ID_LOGIN_ACK:
                    var loginPacket = MarshalHelper.ByteToStructure<T_AckLogin>(fullPacketBytes, fullPacketBytes.Length);
                    uint activeStatus = Endian.Swap(loginPacket.active);
                    logMsg = $"[RECV] 로그인 상태 ACK | {headerInfo}active: {activeStatus}";
                    break;
                case ICD_RDR.MSG_ID_A_ZOOM_CTRL_ACK:
                    var zoomPacket = MarshalHelper.ByteToStructure<T_AckScaleA>(fullPacketBytes, fullPacketBytes.Length);
                    uint scaleValue = Endian.Swap(zoomPacket.unScale);
                    logMsg = $"[RECV] A 배율 변환 ACK | {headerInfo}unScale: {scaleValue}";
                    break;
                case ICD_RDR.MSG_ID_STATUS_REQ_ACK:
                    var statusPacket = MarshalHelper.ByteToStructure<T_AckStatus>(fullPacketBytes, fullPacketBytes.Length);
                    uint status = Endian.Swap(statusPacket.unStatus);
                    logMsg = $"[RECV] 상태 ACK | {headerInfo}unStatus: {status}";
                    break;
            }
            LogEvent(logMsg);
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 레이더 위치 정보 패킷을 처리하고 주기 로그 창에 출력
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcessGpsPacket(byte[] fullPacketBytes, ushort identifier, ushort totalSize, int bodySize, byte senderId, byte receiverId)
        {
            var packet = MarshalHelper.ByteToStructure<T_AckGpsData>(fullPacketBytes, fullPacketBytes.Length);

            float lat = Endian.Swap(packet.fLatitude);
            float lon = Endian.Swap(packet.fLongitude);
            ushort alt = Endian.Swap(packet.unAltitude);
            float dir = Endian.Swap(packet.fDirection);

            string logMsg = $"[RECV] GPS 데이터 ACK | " +
                            $"identifier: 0x{identifier:X4}, bySenderId: {senderId}, byReceiverId: {receiverId}, " +
                            $"unMessageId: 0x{ICD_RDR.MSG_ID_GPS_DATA_ACK:X4}, unSize: {totalSize} | " +
                            $"fLatitude: {lat:F4}, byNSIndicator: {(char)packet.byNSIndicator}, fLongitude: {lon:F4}, byEWIndicator: {(char)packet.byEWIndicator}, " +
                            $"unAltitude: {alt}, fDirection: {dir:F2}";

            LogPeriodic(logMsg);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 이벤트성 패킷(ACK 등)을 처리하고 이벤트 로그 창에 출력
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        private void SendStatusRequestButton_Click(object sender, RoutedEventArgs e)
        {
            if (m_clientSocket == null) { LogEvent("No client connected."); return; }

            try
            {
                // '상태 요청' 패킷(T_ReqStatus) 생성 (데이터 없음)
                var packet = new T_ReqStatus
                {
                    header = new T_Header
                    {
                        identifier = ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD_RDR.SIMSRV_ID,
                        byReceiverId = SIMSW_ID,
                        unMessageId = ICD_RDR.MSG_ID_STATUS_REQ,
                        unSize = (ushort)Marshal.SizeOf<T_ReqStatus>()
                    }
                };

                LogEvent($"[SEND] 상태 요청 | identifier: 0x{packet.header.identifier:X4}, unMessageId: 0x{packet.header.unMessageId:X4}, unSize: {packet.header.unSize}");

                // Endian 변환
                packet.header.identifier = Endian.Swap(packet.header.identifier);
                packet.header.unMessageId = Endian.Swap(packet.header.unMessageId);
                packet.header.unSize = Endian.Swap(packet.header.unSize);

                SendPacket(packet);
            }
            catch (Exception ex)
            {
                LogEvent($"Error sending status request: {ex.Message}");
            }
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 'Send Angle Command' 버튼 클릭 시 입력된 값으로  방향 지점 탐색 명령을 클라이언트로 전송
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void SendAngleButton_Click(object sender, RoutedEventArgs e)
        {
            if (m_clientSocket == null) { LogEvent("No client connected."); return; }
            try
            {
                ushort pan = ushort.Parse(uiTextBox_pan.Text);
                short tilt = short.Parse(uiTextBox_tilt.Text);

                var packet = new T_ReqDirection
                {
                    header = new T_Header
                    {
                        identifier = ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD_RDR.SIMSRV_ID,
                        byReceiverId = SIMSW_ID,
                        unMessageId = ICD_RDR.MSG_ID_CONTROLLER_POS_SEARCH,
                        unSize = (ushort)Marshal.SizeOf<T_ReqDirection>()
                    },
                    unPan = pan,
                    sTilt = tilt
                };

                // 로그 출력을 위해 원본 헤더 정보를 변수에 저장
                var headerInfo = $"identifier: 0x{packet.header.identifier:X4}, bySenderId: {packet.header.bySenderId}, byReceiverId: {packet.header.byReceiverId}, " +
                                 $"unMessageId: 0x{packet.header.unMessageId:X4}, unSize: {packet.header.unSize} | ";
                LogEvent($"[SEND] 방향 지점 탐색 | {headerInfo}unPan: {pan}, sTilt: {tilt}");

                // Endian 변환
                packet.header.identifier = Endian.Swap(packet.header.identifier);
                packet.header.unMessageId = Endian.Swap(packet.header.unMessageId);
                packet.header.unSize = Endian.Swap(packet.header.unSize);
                packet.unPan = Endian.Swap(packet.unPan);
                packet.sTilt = Endian.Swap(packet.sTilt);

                SendPacket(packet);
            }
            catch (Exception ex)
            {
                LogEvent($"Error sending command: {ex.Message}");
            }
        }

        private void Click_RadioButton_Scale(object sender, RoutedEventArgs e)
        {
            if (m_clientSocket == null) { LogEvent("No client connected."); return; }

            var radioButton = sender as RadioButton;
            if (radioButton == null || radioButton.Tag == null) return;

            uint scaleValue = Convert.ToUInt32(radioButton.Tag);

            try
            {
                var packet = new T_ReqScaleA
                {
                    header = new T_Header
                    {
                        identifier = ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD_RDR.SIMSRV_ID,
                        byReceiverId = SIMSW_ID,
                        unMessageId = ICD_RDR.MSG_ID_A_ZOOM_CTRL,

                        unSize = (ushort)Marshal.SizeOf<T_ReqScaleA>()
                    },
                    unScale = scaleValue
                };

                // 로그 출력을 위해 원본 헤더 정보를 변수에 저장
                var headerInfo = $"identifier: 0x{packet.header.identifier:X4}, bySenderId: {packet.header.bySenderId}, byReceiverId: {packet.header.byReceiverId}, " +
                                 $"unMessageId: 0x{packet.header.unMessageId:X4}, unSize: {packet.header.unSize} | ";
                LogEvent($"[SEND] A 배율 제어 명령 | {headerInfo}unScale: {scaleValue}");

                // Endian 변환
                packet.header.identifier = Endian.Swap(packet.header.identifier);
                packet.header.unMessageId = Endian.Swap(packet.header.unMessageId);
                packet.header.unSize = Endian.Swap(packet.header.unSize);
                packet.unScale = Endian.Swap(packet.unScale);

                SendPacket(packet);
            }
            catch (Exception ex)
            {
                LogEvent($"Error sending scale command: {ex.Message}");
            }
        }
        private void SendPacket<T>(T packet) where T : struct
        {
            if (m_clientSocket == null) return;

            byte[] data = MarshalHelper.StructToByte(packet);
            m_server.Send(m_clientSocket, data);
        }
        

        private void LogPeriodic(string message)
        {
            Dispatcher.Invoke(() =>
            {
                uiTextBox_periodicLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\n");
                uiTextBox_periodicLog.ScrollToEnd();
            });
        }
        private void LogEvent(string message)
        {
            Dispatcher.Invoke(() =>
            {
                uiTextBox_eventLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\n");
                uiTextBox_eventLog.ScrollToEnd();
            });
        }

        
    }
}