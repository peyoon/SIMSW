﻿using OzNet;
using ICD;
using System;
using System.Net.Sockets;
using System.Windows;
using OzUtil;
using System.Runtime.InteropServices;

namespace TestServer
{
    public partial class MainWindow : Window
    {
        private TCPServer m_server;
        private Socket m_clientSocket;
        private const byte SIMSW_ID = 0x01; // 수신자인 RDR_SIM의 ID

        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
            this.Closing += MainWindow_Closing;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            m_server = new TCPServer(9112);
            m_server.Event_NotifyConnectClient += OnClientConnected;
            m_server.Event_NotifyDisconnectClient += OnClientDisconnected;
            m_server.Event_NotifyReceived += OnDataReceived;
            m_server.StartServer();
            Log("Server started on port 9112. Waiting for client..."); 
        }

        private void OnClientConnected(Socket clientSocket)
        {
            m_clientSocket = clientSocket;
            Log($"---> Client connected: {clientSocket.RemoteEndPoint} <---");
            Dispatcher.Invoke(() => uiAngleButton_send.IsEnabled = true);
        }

        private void OnClientDisconnected(Socket clientSocket)
        {
            Log($"---> Client disconnected: {clientSocket.RemoteEndPoint} <---");
            m_clientSocket = null;
            Dispatcher.Invoke(() => uiAngleButton_send.IsEnabled = false);
        }

        // 데이터 수신 로직 (이전과 동일)
        private void OnDataReceived(Socket clientSocket)
        {
            try
            {
                // 1. 헤더 수신
                int headerSize = Marshal.SizeOf<T_Header>();
                byte[] headerBytes = m_server.Recieve(clientSocket, headerSize);
                if (headerBytes == null) return;

                // 2. 헤더 정보 분석
                T_Header tempHeader = MarshalHelper.ByteToStructure<T_Header>(headerBytes, headerBytes.Length);
                ushort totalSize = Endian.Swap(tempHeader.unSize);
                ushort messageId = Endian.Swap(tempHeader.unMessageId);

                // 3. 본문 수신
                int bodySize = totalSize - headerSize;
                if (bodySize < 0)
                {
                    Log($"Error: Invalid packet size ({totalSize}).");
                    return;
                }
                byte[] bodyBytes = m_server.Recieve(clientSocket, bodySize);
                if (bodyBytes == null) return;

                // 4. 완전한 패킷으로 조립
                byte[] fullPacketBytes = new byte[totalSize];
                Buffer.BlockCopy(headerBytes, 0, fullPacketBytes, 0, headerSize);
                Buffer.BlockCopy(bodyBytes, 0, fullPacketBytes, headerSize, bodySize);

                // 5. 메시지 ID에 따라 최종 처리
                switch (messageId)
                {
                    case ICD_RDR.MSG_ID_PAN_TILT_ACK:
                        {
                            var packet = MarshalHelper.ByteToStructure<T_AckDirection>(fullPacketBytes, fullPacketBytes.Length);
                            ushort pan = Endian.Swap(packet.unPan);
                            short tilt = Endian.Swap(packet.sTilt);
                            Log($"[SUCCESS] Received Antenna Angle | Azimuth(Pan): {pan}, Elevation(Tilt): {tilt}");
                            break;
                        }
                    case ICD_RDR.MSG_ID_GPS_DATA_ACK:
                        {
                            var packet = MarshalHelper.ByteToStructure<T_AckGpsData>(fullPacketBytes, fullPacketBytes.Length);
                            float lat = Endian.Swap(packet.fLatitude);
                            float lon = Endian.Swap(packet.fLongitude);
                            ushort alt = Endian.Swap(packet.unAltitude);

                            Log($"[SUCCESS] Received Radar Position | Lat: {lat}, Lon: {lon}, Alt: {alt}");
                            break;
                        }
                    default:
                        Log($"[WARNING] Received Unknown Packet | Message ID: 0x{messageId:X4}");
                        break;
                }
            }
            catch (Exception ex)
            {
                Log($"[FATAL ERROR] An exception occurred during receive process: {ex.Message}");
            }
        }


        /// <summary>
        /// ✨ [추가된 기능] 'Send Angle Command' 버튼 클릭 이벤트 핸들러
        /// </summary>
        private void SendAngleButton_Click(object sender, RoutedEventArgs e)
        {
            if (m_clientSocket == null)
            {
                Log("No client connected.");
                return;
            }

            try
            {
                // 1. UI에서 Pan/Tilt 값을 읽어옴
                ushort pan = ushort.Parse(uiTextBox_pan.Text);
                short tilt = short.Parse(uiTextBox_tilt.Text);

                // 2. '방향 지점 탐색' 패킷(T_ReqDirection) 생성
                var packet = new T_ReqDirection
                {
                    header = new T_Header
                    {
                        identifier = ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD_RDR.SIMSRV_ID, // 보내는 사람: 서버(0x00)
                        byReceiverId = SIMSW_ID, // 받는 사람: 클라이언트(0x01)
                        unMessageId = ICD_RDR.MSG_ID_CONTROLLER_POS_SEARCH,
                        unSize = (ushort)Marshal.SizeOf<T_ReqDirection>()
                    },
                    unPan = pan,
                    sTilt = tilt
                };

                // 3. Endian 변환
                packet.header.identifier = Endian.Swap(packet.header.identifier);
                packet.header.unMessageId = Endian.Swap(packet.header.unMessageId);
                packet.header.unSize = Endian.Swap(packet.header.unSize);
                packet.unPan = Endian.Swap(packet.unPan);
                packet.sTilt = Endian.Swap(packet.sTilt);

                // 4. 패킷 전송
                SendPacket(packet);
                Log($"[SEND] Direction Command | Pan: {pan}, Tilt: {tilt}");
            }
            catch (Exception ex)
            {
                Log($"Error sending command: {ex.Message}");
            }
        }

        /// <summary>
        /// ✨ [추가된 기능] 구조체 패킷을 마샬링하여 클라이언트로 전송하는 공통 메서드
        /// </summary>
        private void SendPacket<T>(T packet) where T : struct
        {
            if (m_clientSocket == null) return;

            byte[] data = MarshalHelper.StructToByte(packet);
            m_server.Send(m_clientSocket, data);
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            m_server?.StopServer();
        }

        private void Log(string message)
        {
            Dispatcher.Invoke(() =>
            {
                logTextBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\n");
                logTextBox.ScrollToEnd();
            });
        }
    }
}