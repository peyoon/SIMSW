﻿//// RadarPositionViewModel.cs
//using System;
//using System.ComponentModel; // INotifyPropertyChanged를 위해 필요
//using System.Runtime.CompilerServices; // CallerMemberName을 위해 필요

//namespace RDR_SIM
//{
//    // 1. BaseViewModel 상속 대신 INotifyPropertyChanged 인터페이스를 직접 구현
//    public class RadarPositionViewModel : INotifyPropertyChanged
//    {
//        // 2. BaseViewModel에 있던 코드를 그대로 가져옴
//        public event PropertyChangedEventHandler PropertyChanged;

//        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
//        {
//            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
//        }

//        // --- 여기서부터는 기존 ViewModel 코드와 동일합니다 ---

//        private bool _isUpdating = false;

//        // DMS 경도 속성
//        private double? _lonD, _lonM, _lonS, _lonMs;
//        public double? LonD { get { return _lonD; } set { _lonD = value; OnPropertyChanged(); UpdateDecimalFromDms(); } }
//        public double? LonM { get { return _lonM; } set { _lonM = value; OnPropertyChanged(); UpdateDecimalFromDms(); } }
//        public double? LonS { get { return _lonS; } set { _lonS = value; OnPropertyChanged(); UpdateDecimalFromDms(); } }
//        public double? LonMs { get { return _lonMs; } set { _lonMs = value; OnPropertyChanged(); UpdateDecimalFromDms(); } }

//        // DMS 위도 속성
//        private double? _latD, _latM, _latS, _latMs;
//        public double? LatD { get { return _latD; } set { _latD = value; OnPropertyChanged(); UpdateDecimalFromDms(); } }
//        public double? LatM { get { return _latM; } set { _latM = value; OnPropertyChanged(); UpdateDecimalFromDms(); } }
//        public double? LatS { get { return _latS; } set { _latS = value; OnPropertyChanged(); UpdateDecimalFromDms(); } }
//        public double? LatMs { get { return _latMs; } set { _latMs = value; OnPropertyChanged(); UpdateDecimalFromDms(); } }

//        // Degree 경도/위도 속성
//        private double? _lonDecimal;
//        public double? LonDecimal { get { return _lonDecimal; } set { _lonDecimal = value; OnPropertyChanged(); UpdateDmsFromDecimal(); } }

//        private double? _latDecimal;
//        public double? LatDecimal { get { return _latDecimal; } set { _latDecimal = value; OnPropertyChanged(); UpdateDmsFromDecimal(); } }

//        private void UpdateDecimalFromDms()
//        {
//            if (_isUpdating) return;
//            _isUpdating = true;
//            try
//            {
//                LonDecimal = (_lonD ?? 0) + (_lonM ?? 0) / 60.0 + (_lonS ?? 0) / 3600.0 + (_lonMs ?? 0) / 3600000.0;
//                LatDecimal = (_latD ?? 0) + (_latM ?? 0) / 60.0 + (_latS ?? 0) / 3600.0 + (_latMs ?? 0) / 3600000.0;
//            }
//            finally
//            {
//                _isUpdating = false;
//            }
//        }

//        private void UpdateDmsFromDecimal()
//        {
//            if (_isUpdating) return;
//            _isUpdating = true;
//            try
//            {
//                double lonTotalDegrees = _lonDecimal ?? 0;
//                _lonD = Math.Truncate(lonTotalDegrees);
//                double lonRemainingMinutes = (lonTotalDegrees - _lonD.Value) * 60;
//                _lonM = Math.Truncate(lonRemainingMinutes);
//                double lonRemainingSeconds = (lonRemainingMinutes - _lonM.Value) * 60;
//                _lonS = Math.Truncate(lonRemainingSeconds);
//                _lonMs = Math.Round((lonRemainingSeconds - _lonS.Value) * 1000);

//                double latTotalDegrees = _latDecimal ?? 0;
//                _latD = Math.Truncate(latTotalDegrees);
//                double latRemainingMinutes = (latTotalDegrees - _latD.Value) * 60;
//                _latM = Math.Truncate(latRemainingMinutes);
//                double latRemainingSeconds = (latRemainingMinutes - _latM.Value) * 60;
//                _latS = Math.Truncate(latRemainingSeconds);
//                _latMs = Math.Round((latRemainingSeconds - _latS.Value) * 1000);

//                OnPropertyChanged(nameof(LonD)); OnPropertyChanged(nameof(LonM)); OnPropertyChanged(nameof(LonS)); OnPropertyChanged(nameof(LonMs));
//                OnPropertyChanged(nameof(LatD)); OnPropertyChanged(nameof(LatM)); OnPropertyChanged(nameof(LatS)); OnPropertyChanged(nameof(LatMs));
//            }
//            finally
//            {
//                _isUpdating = false;
//            }
//        }
//    }
//}