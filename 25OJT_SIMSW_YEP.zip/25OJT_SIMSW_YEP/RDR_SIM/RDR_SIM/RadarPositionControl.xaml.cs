﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RDR_SIM
{
    public class LocationData
    {
        public int SeqNum { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
        public string Altitude { get; set; }
        public string Azimuth { get; set; }
    }
    /// <summary>
    /// RadarPositionControl.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class RadarPositionControl : Window
    {
        public ObservableCollection<LocationData> LocationList { get; set; }

        public RadarPositionControl()
        {
            LocationList = new ObservableCollection<LocationData>();

            // 2. DataContext를 현재 창의 인스턴스(this)로 설정합니다.
            // 이렇게 해야 XAML에서 {Binding LocationList}가 이 클래스의 LocationList 속성을 찾아올 수 있습니다.
            this.DataContext = this;
            InitializeComponent();
        }

        private void Btn_Click_Close(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
            for (int i = 1; i <= 5; i++)
            {
                LocationList.Add(new LocationData
                {
                    SeqNum = i,
                    Longitude = "", // 빈 값으로 초기화
                    Latitude = "",
                    Altitude = "",
                    Azimuth = ""
                });
            }
        }
    }
}
