﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace RDR_SIM
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        ConnectControl connectWindow = new ConnectControl();
        private DispatcherTimer _timer;

        public MainWindow()
        {
            InitializeComponent();

            ////////////////////////////////////////////////////
            /// MainWindw_Scope 초기화 - Scope GL
            InitScope();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 윈도우 로딩 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromSeconds(1); // 업데이트 간격: 1초
            _timer.Tick += Timer_Tick; // 1초마다 Timer_Tick 메서드 실행
            _timer.Start();
            ////////////////////////////////////////////////////
            /// MainWindw_Scope.cs 구현
            // Update Scope GL Render
            UpdateScope();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 윈도우 Closing 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("프로그램을 종료할까요?", "종료 확인", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
            {
                Environment.Exit(0); //모두 종료
                System.Diagnostics.Process.GetCurrentProcess().Kill(); //관련프로세스 강제 종료
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // 현재 시간을 "년-월-일 시:분:초" 형식의 문자열로 변환하여 TextBlock에 표시
            uiButton_CurrentTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        

        private void Click_Button_ConnectControl(object sender, RoutedEventArgs e)
        {
            
            connectWindow.Show();
        }

        private void Click_Button_RadarPosition(object sender, RoutedEventArgs e)
        {
            RadarPositionControl connectWindow = new RadarPositionControl();
            connectWindow.ShowDialog();
        }

        private void Click_Button_DirectAngle(object sender, RoutedEventArgs e)
        {
            DirectAngleControl connectWindow = new DirectAngleControl();
            connectWindow.ShowDialog();
        }

        private void Click_Button_SavePosition(object sender, RoutedEventArgs e)
        {

        }
    }
}
