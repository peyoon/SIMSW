﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scope
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// RHI Scope 랜더 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public class CRHIScope
	{		
		private const int		CIRCLE_CNT			= 360;      // 원 해상도
        private const double	CIRCLE_RADIUS_MAX	= 10000.0;	// 원 최대 반지름	
		
		private int m_nWidth	= 800;              // 랜더 뷰 가로
        private int m_nHeight	= 800;				// 랜더 뷰 세로

		private TCamera				m_Camera;		// 랜더 카메라
		private GLFont.FontFreeType m_Font;			// 랜더 폰트

		private E_ScopeDistGap	m_eScopeDistGap;	// 거리 간격
        private E_ScopeAngGap	m_eScopeAngGap;		// 각도 간격

		private int				m_nElevationMil;    // 고각 [mil]


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// RHI Scope 초기화
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public CRHIScope()
		{
			m_Camera = new TCamera();
			m_Camera.m_dZoomDist = 27000.0;
			m_Camera.m_vPosOrigin = new Vector3d(10000.0, 0.0, 0.0);

			m_Font = new GLFont.FontFreeType("./Resources/malgun.ttf", 20);

            m_eScopeDistGap = E_ScopeDistGap._1000;
			m_eScopeAngGap = E_ScopeAngGap._800;
			m_nElevationMil = 0;			// 고각(mil)

		}

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// RHI Scope 기본 설정
        /// 파라미터 :	[in] eScopeAngGap	- 각도 간격
        ///				[in] eScopeDistGap	- 거리 간격
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Setting(E_ScopeAngGap eScopeAngGap, E_ScopeDistGap eScopeDistGap)
		{
            m_eScopeAngGap = eScopeAngGap;
			m_eScopeDistGap = eScopeDistGap;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// PPI Scope 랜더링
        /// 파라미터 :	[in] width		- 랜더 뷰 가로
        ///				[in] height		- 랜더 뷰 세로
        ///				[in] nEleMil	- 고각 값	[mil]
        ///				[in] bShowDir	- 방향 선 랜더 유무
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Render(double width, double height, int nEleMil, bool bShowDir)
		{
            m_nElevationMil = nEleMil;

            GL.ShadeModel(ShadingModel.Smooth);
			GL.Hint(HintTarget.LineSmoothHint, HintMode.Nicest);

			GL.PolygonMode(MaterialFace.Front, PolygonMode.Fill);
			GL.PolygonMode(MaterialFace.Back, PolygonMode.Line);

			GL.Enable(EnableCap.CullFace);
			GL.Disable(EnableCap.DepthTest);

			GL.ClearColor(0.0f, 0.0f, 0.0f, 1.0f);
			GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

			
			m_nWidth = Convert.ToInt32(width);
			m_nHeight = Convert.ToInt32(height);

			m_Camera.Update();
			m_Camera.Apply(0, 0, m_nWidth, m_nHeight);

            drawScopeBG();


			if (bShowDir == true)
			{

				GL.LineWidth(5.0f);
				// 최대 고각
				GL.PushMatrix();
				{
					GL.Rotate(-60.0f, 0.0f, 0.0f, -1.0f);
					GL.Color3(1.0f, 0.0f, 0.0f);
					GL.Begin(PrimitiveType.Lines);
					{
						GL.Vertex3(0.0f, 0.0f, 0.0f);
						GL.Vertex3(CIRCLE_RADIUS_MAX, 0.0f, 0.0f);
					}
					GL.End();
				}
				GL.PopMatrix();

				// 최소 고각
				GL.PushMatrix();
				{
					GL.Rotate(10.0f, 0.0f, 0.0f, -1.0f);
					GL.Color3(1.0f, 0.0f, 0.0f);
					GL.Begin(PrimitiveType.Lines);
					{
						GL.Vertex3(0.0f, 0.0f, 0.0f);
						GL.Vertex3(CIRCLE_RADIUS_MAX, 0.0f, 0.0f);
					}
					GL.End();
				}
				GL.PopMatrix();

				// 지향고각
				GL.PushMatrix();
				{
					GL.Rotate(-ScopeConst.MIL2DEG(m_nElevationMil), 0.0f, 0.0f, -1.0f);
					GL.Color3(0.0f, 1.0f, 0.0f);
					GL.Begin(PrimitiveType.Lines);
					{
						GL.Vertex3(0.0f, 0.0f, 0.0f);
						GL.Vertex3(CIRCLE_RADIUS_MAX, 0.0f, 0.0f);
					}
					GL.End();
				}
				GL.PopMatrix();
				GL.LineWidth(1.0f);
			}
		}

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Scope 원 그리기
        /// 파라미터 :	[in] dRadius	- 원 반지름
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void drawCircle(double dRadius)
		{
			double dAddAng = ScopeConst.PI / (double)CIRCLE_CNT;
			double dCurAng = 0.0;

			int i;
			double x, y;

			GL.PushMatrix();
			GL.Begin(PrimitiveType.LineStrip);
			for (i = 0; i <= CIRCLE_CNT; i++)
			{
				x = dRadius * Math.Sin(dCurAng);
				y = dRadius * Math.Cos(dCurAng);
				GL.Vertex3(x, y, 0.0);
				dCurAng += dAddAng;
			}
			GL.End();
			GL.PopMatrix();
		}

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Scope 배경 그리기
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void drawScopeBG()
		{
			// 배경 폴리곤
			float fImgOutsideGap = 100000.0f;
			GL.Color3(0, 0, 0);
			GL.Begin(PrimitiveType.Quads);
			{
				GL.Vertex3(-fImgOutsideGap, fImgOutsideGap, -0.1f);
				GL.Vertex3(-fImgOutsideGap, -fImgOutsideGap, -0.1f);
				GL.Vertex3(fImgOutsideGap, -fImgOutsideGap, -0.1f);
				GL.Vertex3(fImgOutsideGap, fImgOutsideGap, -0.1f);
			}
			GL.End();

			// 가시선
			double dRadius = 1000.0;
			switch (m_eScopeDistGap)
			{
				default:
				case E_ScopeDistGap._200:	dRadius = 200.0;	break;     // 200m
				case E_ScopeDistGap._500:	dRadius = 500.0;	break;     // 500m
				case E_ScopeDistGap._1000:	dRadius = 1000.0;	break;     // 1000m
				case E_ScopeDistGap.OFF:	dRadius = 0.0;		break;     // OFF
			}
			int nDistNum = (int)(CIRCLE_RADIUS_MAX / dRadius);

			GL.LineWidth(1.0f);

			//GL.Color3(0, 101, 0);
			GL.Color3(0.0, 101.0 / 255.0, 0.0);
			for (int nDistCnt = 0; nDistCnt < nDistNum; nDistCnt++)
			{
				drawCircle(dRadius * (double)(nDistCnt + 1));
			}

			// 방위각
			double dAngGap;
			switch (m_eScopeAngGap)
			{
				default:
				case E_ScopeAngGap._200:	dAngGap = 11.25;	break;     // 11.25도 (200mil)
				case E_ScopeAngGap._400:	dAngGap = 22.5;		break;     // 22.5도 (400mil)
				case E_ScopeAngGap._800:	dAngGap = 45.0;		break;     // 45도 (800mil)
				case E_ScopeAngGap.OFF:		dAngGap = 0.0;		break;     // OFF
			}

			int nRotNum = (int)(90.0 / dAngGap);

			GL.Color3(107.0 / 255.0, 105.0 / 255.0, 107.0 / 255.0);
			GL.PushMatrix();
			for (int nRotCnt = 0; nRotCnt < nRotNum + 1; nRotCnt++)
			{
				if (nRotCnt != 0)
					GL.Rotate(dAngGap, 0.0, 0.0, -1.0);

				GL.Begin(PrimitiveType.Lines);
				GL.Vertex3(0.0, 0.0, 0.0);
				GL.Vertex3(CIRCLE_RADIUS_MAX, 0.0, 0.0);

				GL.Vertex3(0.0, 0.0, 0.0);
				GL.Vertex3(0.0, CIRCLE_RADIUS_MAX, 0.0);
				GL.End();
			}
			GL.PopMatrix();

			GL.LineWidth(1.0f);

			drawScopeBG_Label();
		}

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Scope 라벨 정보 그리기
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void drawScopeBG_Label()
		{
			int[] nViewport = new int[4];
			Matrix4d matModel = new Matrix4d();
			Matrix4d matProj = new Matrix4d();

			GL.GetDouble(GetPName.ProjectionMatrix, out matProj);
			GL.GetDouble(GetPName.ModelviewMatrix, out matModel);
			GL.GetInteger(GetPName.Viewport, nViewport);
			Vector4d vViewport = new Vector4d(nViewport[0], nViewport[1], nViewport[2], nViewport[3]);

			// 단위 
			GL.MatrixMode(MatrixMode.Projection);
			GL.PushMatrix();
			{
				GL.LoadIdentity();
				GL.Viewport(nViewport[0], nViewport[1], nViewport[2], nViewport[3]);
				GL.Ortho(nViewport[0], nViewport[2] + nViewport[0], nViewport[1], nViewport[3] + nViewport[1], -1.0, 1.0);

				GL.MatrixMode(MatrixMode.Modelview);
				GL.PushMatrix();
				{
					GL.LoadIdentity();

					// 방위각
					GL.Color3(90.0f / 255.0f, 158.0f / 255.0f, 156.0f / 255.0f);
					m_Font.AlignHorizontal = GLFont.AlignmentHorizontal.Center;
					m_Font.AlignVertical = GLFont.AlignmentVertical.Bottom;

					if (m_eScopeAngGap != E_ScopeAngGap.OFF)
					{
						double dAngGap;
						switch (m_eScopeAngGap)
						{
							default:
							case E_ScopeAngGap._200:	dAngGap = 11.25;	break;     // 11.25도 (200mil)
							case E_ScopeAngGap._400:	dAngGap = 22.5;		break;     // 22.5도 (400mil)
							case E_ScopeAngGap._800:	dAngGap = 45.0;		break;     // 45도 (800mil)
							case E_ScopeAngGap.OFF:		dAngGap = 0.0;		break;     // OFF
						}

						Vector3d[] ptUnitLine = new Vector3d[2];

						int nRotNum = (int)(180.0 / dAngGap);
						for (int nRotCnt = 0; nRotCnt < nRotNum + 1; nRotCnt++)
						{
							double dAng = dAngGap * (double)nRotCnt;
							ptUnitLine[1] = new Vector3d(0.0, CIRCLE_RADIUS_MAX + 300.0, 0.0);
							ptUnitLine[1] = Vector3d.Transform(ptUnitLine[1], Matrix4d.CreateRotationZ(-dAng * ScopeConst.DEG2RAD));

							string strAng = ScopeConst.DEG2MIL(90.0 - dAng).ToString();
							double sx = 0.0;
							double sy = 0.0;
							double sz = 0.0;

							GLProject(ptUnitLine[1], matModel, matProj, vViewport, ref sx, ref sy, ref sz);
							m_Font.AlignHorizontal = GLFont.AlignmentHorizontal.Center;
							m_Font.AlignVertical = GLFont.AlignmentVertical.Bottom;
							m_Font.RotateAngle = -(float)dAng;
							m_Font.Render((float)sx, (float)sy, strAng);
						}
					}
				}
				GL.PopMatrix();
				GL.MatrixMode(MatrixMode.Projection);
			}
			GL.PopMatrix();
			GL.MatrixMode(MatrixMode.Modelview);
		}

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 스크린 좌표 얻기
        /// 파라미터 :	[in] obj	- 스크린 좌표 얻을 위치
		///				[in] model	- 모델뷰 매트릭스
		///				[in] proj	- 프로젝션 매트릭스
		///				[in] view	- 뷰포트 저옵
		///				[out] scrX	- 스크린 x
		///				[out] scrY	- 스크린 y
		///				[out] scrZ	- 스크린 z
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private bool GLProject(Vector3d obj, Matrix4d model, Matrix4d proj, Vector4d view, ref double scrX, ref double scrY, ref double scrZ)
		{
			Vector4d vIn = new Vector4d(obj, 1.0);
			Vector4d vOut = new Vector4d();

			vOut = Vector4d.Transform(vIn, model);
			vOut = Vector4d.Transform(vOut, proj);

			if (vOut.W == 0.0)
				return false;

			vOut.X /= vOut.W;
			vOut.Y /= vOut.W;
			vOut.Z /= vOut.W;

			/* Map x, y and z to range 0-1 */
			vOut.X = vOut.X * 0.5 + 0.5;
			vOut.Y = vOut.Y * 0.5 + 0.5;
			vOut.Z = vOut.Z * 0.5 + 0.5;

			/* Map x,y to viewport */
			vOut.X = vOut.X * view[2] + view[0];
			vOut.Y = vOut.Y * view[3] + view[1];

			scrX = vOut.X;
			scrY = vOut.Y;
			scrZ = vOut.Z;

			return true;
		}


	}
}
