﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RDR_SIM
{

    // scope 설정 정보 구조체
    public struct T_DpConfig
    {
        public Scope.E_ScopeAngGap ePPIAngGap;      // PPI
        public Scope.E_ScopeAngGap eRHIAngGap;      // PHI

        //public T_DpConfig(bool bFlag)
        //{
        //    ePPIAngGap = Scope.E_ScopeAngGap._800;
        //    eRHIAngGap = Scope.E_ScopeAngGap._800;

        //    if (bFlag == false)
        //    {
        //        Debug.WriteLine("구조체 초기화");

        //    }
        //}
    }

    public class RDR_SIMData
    {
        //public static T_DpConfig m_tDpConfig;      // scope 설정 정보
        public T_DpConfig m_tDpConfig;      // scope 설정 정보

        public RDR_SIMData()
        {
            m_tDpConfig = new T_DpConfig();
            m_tDpConfig.ePPIAngGap = Scope.E_ScopeAngGap._800;
            m_tDpConfig.eRHIAngGap = Scope.E_ScopeAngGap._800;

        }

        //public static void Init()
        //{
        //    m_tDpConfig = new T_DpConfig();
        //    m_tDpConfig.ePPIAngGap = Scope.E_ScopeAngGap._800;
        //    m_tDpConfig.eRHIAngGap = Scope.E_ScopeAngGap._800;
        //}
    }
}
