﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RDR_SIM
{
    /// <summary>
    /// ConnectControl.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ConnectControl : Window
    {
        public delegate bool Handler_RequestConnectSrv(int id);
        public event Handler_RequestConnectSrv Event_RequestConnectSrv;

        RDR_SIMData m_pcData;

        public ConnectControl()
        {
            InitializeComponent();
        }

        private void Loaded_Window(object sender, RoutedEventArgs e)
        {

        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void Btn_Click_Close(object sender, RoutedEventArgs e)
        {
            bool bRet = Event_RequestConnectSrv(10);

            m_pcData.m_tDpConfig.eRHIAngGap = Scope.E_ScopeAngGap.OFF;

            //RDR_SIMData.m_tDpConfig.ePPIAngGap = Scope.E_ScopeAngGap._400;

            Close();
        }

        public void SetPtr(RDR_SIMData pcData)
        {
            m_pcData = pcData;
        }
    }
}
