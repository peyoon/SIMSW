﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Media;

namespace OzUC
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// IP 주소 입력 UC 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 30일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public partial class IpAddressCtrl : UserControl
    {
        private const string ERROR_MESSAGE = "0 ~ 255 값을 입력하세요.";

        // ip  첫번째
        public TextBox FirstBox { get { return uiFirstBox; } }
        // ip  두번째
        public TextBox SecondBox { get { return uiSecondBox; } }
        // ip  세번째
        public TextBox ThirdBox { get { return uiThirdBox; } }
        // ip  네번째
        public TextBox FourthBox { get { return uiFourthBox; } }

        // IP 주소 (string)
        public string IPAddress
        {
            get
            {
                return string.Format("{0}.{1}.{2}.{3}", uiFirstBox.Text, uiSecondBox.Text, uiThirdBox.Text, uiFourthBox.Text);
            }

            set
            {
                string[] strIPtoken = value.ToString().Split('.');

                uiFirstBox.Text = strIPtoken[0];
                uiSecondBox.Text = strIPtoken[1];
                uiThirdBox.Text = strIPtoken[2];
                uiFourthBox.Text = strIPtoken[3];
            }
        }




        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 생성자
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public IpAddressCtrl()
        {
            InitializeComponent();
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// IP 주소 얻기 (byte)
        /// 파라미터 : -
        /// 반 환 값 : IP 주소 Byte 배열
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public byte[] GetByteArray()
        {
            byte[] userInput = new byte[4];

            userInput[0] = Convert.ToByte(uiFirstBox.Text);
            userInput[1] = Convert.ToByte(uiSecondBox.Text);
            userInput[2] = Convert.ToByte(uiThirdBox.Text);
            userInput[3] = Convert.ToByte(uiFourthBox.Text);

            return userInput;
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 오른쪽 입력컨트롤로 이동
        /// 파라미터 :  [in] rightNeighborBox   - 오른쪽 TextBox
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void jumpRight(TextBox rightNeighborBox, KeyEventArgs e)
        {
            rightNeighborBox.Focus();
            rightNeighborBox.CaretIndex = 0;
            e.Handled = true;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 왼쪽 입력컨트롤로 이동
        /// 파라미터 :  [in] rightNeighborBox   - 왼쪽 TextBox
        /// 반 환 값 : IP 주소 Byte 배열
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void jumpLeft(TextBox leftNeighborBox, KeyEventArgs e)
        {
            leftNeighborBox.Focus();
            if (leftNeighborBox.Text != "")
            {
                leftNeighborBox.CaretIndex = leftNeighborBox.Text.Length;
            }
            e.Handled = true;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 오른쪽 입력컨트롤로 이동 가능 체크
        /// 파라미터 :  [in] currentBox         - 현재 입력 중인 TextBox
        ///             [in] rightNeighborBox   - 오른쪽 TextBox
        /// 반 환 값 : 이동 가능 유무
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private bool checkJumpRight(TextBox currentBox, TextBox rightNeighborBox, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Right:
                    if (currentBox.CaretIndex == currentBox.Text.Length || currentBox.Text == "")
                    {
                        jumpRight(rightNeighborBox, e);
                    }
                    return true;
                case Key.OemPeriod:
                case Key.Decimal:
                case Key.Space:
                    jumpRight(rightNeighborBox, e);
                    rightNeighborBox.SelectAll();
                    return true;
                default:
                    return false;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 왼쪽 입력컨트롤로 이동 가능 체크
        /// 파라미터 :  [in] currentBox         - 현재 입력 중인 TextBox
        ///             [in] rightNeighborBox   - 왼쪽 TextBox
        /// 반 환 값 : 이동 가능 유무
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private bool checkJumpLeft(TextBox currentBox, TextBox leftNeighborBox, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left:
                    if (currentBox.CaretIndex == 0 || currentBox.Text == "")
                    {
                        jumpLeft(leftNeighborBox, e);
                    }
                    return true;
                case Key.Back:
                    if ((currentBox.CaretIndex == 0 || currentBox.Text == "") && currentBox.SelectionLength == 0)
                    {
                        jumpLeft(leftNeighborBox, e);
                    }
                    return true;
                default:
                    return false;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Text 입력 체크 (문자값 확인)
        /// 파라미터 :  [in] currentBox         - 현재 입력 중인 TextBox
        ///             [in] rightNeighborBox   - 오른쪽 TextBox
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void handleTextInput(TextBox currentBox, TextBox rightNeighborBox, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(Convert.ToChar(e.Text)))
            {
                e.Handled = true;
                SystemSounds.Beep.Play();
                return;
            }

            if (currentBox.Text.Length == 3 && currentBox.SelectionLength == 0)
            {
                e.Handled = true;
                SystemSounds.Beep.Play();
                if (currentBox != uiFourthBox)
                {
                    rightNeighborBox.Focus();
                    rightNeighborBox.SelectAll();
                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Text 입력 체크 (문자열 값 확인)
        /// 파라미터 :  [in] currentBox         - 현재 입력 중인 TextBox
        ///             [in] rightNeighborBox   - 오른쪽 TextBox
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //checks whether textbox content > 255 when 3 characters have been entered.
        //clears if > 255, switches to next textbox otherwise 
        private void handleTextChange(TextBox currentBox, TextBox rightNeighborBox)
        {
            if (currentBox.Text.Length == 3)
            {
                try
                {
                    Convert.ToByte(currentBox.Text);

                }
                catch (Exception exception) when (exception is FormatException || exception is OverflowException)
                {
                    currentBox.Clear();
                    currentBox.Focus();
                    SystemSounds.Beep.Play();
                    MessageBox.Show(ERROR_MESSAGE, "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                if (currentBox.CaretIndex != 2 && currentBox != uiFourthBox)
                {
                    rightNeighborBox.CaretIndex = rightNeighborBox.Text.Length;
                    rightNeighborBox.SelectAll();
                    rightNeighborBox.Focus();
                }
            }
        }


        //jump right, left or stay. 

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 첫번째 입력 컨트롤 키 다운 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void PreviewKeyDown_FirstByte(object sender, KeyEventArgs e)
        {
            checkJumpRight(uiFirstBox, uiSecondBox, e);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 두번째 입력 컨트롤 키 다운 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void PreviewKeyDown_SecondByte(object sender, KeyEventArgs e)
        {
            if (checkJumpRight(uiSecondBox, uiThirdBox, e))
                return;

            checkJumpLeft(uiSecondBox, uiFirstBox, e);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 세번째 입력 컨트롤 키 다운 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void PreviewKeyDown_ThirdByte(object sender, KeyEventArgs e)
        {
            if (checkJumpRight(uiThirdBox, uiFourthBox, e))
                return;

            checkJumpLeft(uiThirdBox, uiSecondBox, e);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 네번째 입력 컨트롤 키 다운 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void PreviewKeyDown_FourthByte(object sender, KeyEventArgs e)
        {
            checkJumpLeft(uiFourthBox, uiThirdBox, e);

            if (e.Key == Key.Space)
            {
                SystemSounds.Beep.Play();
                e.Handled = true;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 첫번째 입력 컨트롤 문자 변경 전 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //discards non digits, prepares IPMaskedBox for textchange.
        private void PreviewTextInput_FirstByte(object sender, TextCompositionEventArgs e)
        {
            handleTextInput(uiFirstBox, uiSecondBox, e);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 두번째 입력 컨트롤 문자 변경 전 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void PreviewTextInput_SecondByte(object sender, TextCompositionEventArgs e)
        {
            handleTextInput(uiSecondBox, uiThirdBox, e);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 세번째 입력 컨트롤 문자 변경 전 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void PreviewTextInput_ThirdByte(object sender, TextCompositionEventArgs e)
        {
            handleTextInput(uiThirdBox, uiFourthBox, e);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 네번째 입력 컨트롤 문자 변경 전 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void PreviewTextInput_FourthByte(object sender, TextCompositionEventArgs e)
        {
            handleTextInput(uiFourthBox, uiFourthBox, e); //pass fourthbyte twice because no right neighboring box.
        }


        //checks whether textbox content > 255 when 3 characters have been entered.
        //clears if > 255, switches to next textbox otherwise 
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 첫번째 입력 컨트롤 문자열 변경 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void TextChanged_FirstByte(object sender, TextChangedEventArgs e)
        {
            handleTextChange(uiFirstBox, uiSecondBox);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 두번째 입력 컨트롤 문자열 변경 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void TextChanged_SecondByte(object sender, TextChangedEventArgs e)
        {
            handleTextChange(uiSecondBox, uiThirdBox);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 세번째 입력 컨트롤 문자열 변경 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void TextChanged_ThirdByte(object sender, TextChangedEventArgs e)
        {
            handleTextChange(uiThirdBox, uiFourthBox);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 네번째 입력 컨트롤 문자열 변경 이벤트 처리
        /// 파라미터 : -        
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void TextChanged_FourthByte(object sender, TextChangedEventArgs e)
        {
            handleTextChange(uiFourthBox, uiFourthBox);
        }


    }
}
