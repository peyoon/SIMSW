﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OzUC
{
    /// <summary>
    /// UserControl1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class SpinTextBox : UserControl
    {
        private int     m_nValue;           // 현재값
        private int     m_nMinValue;        // 최소값
        private int     m_nMaxValue;        // 최대값

        public SpinTextBox()
        {
            InitializeComponent();

            m_nValue = 0;
            TextBox_Spin.Text = m_nValue.ToString();

            m_nMinValue = int.MinValue;
            m_nMaxValue = int.MaxValue;
        }

        // Value 최소값
        public int MinValue
        {
            set
            {
                m_nMinValue = value;
            }
        }

        // Value 최대값
        public int MaxValue
        {
            set
            {
                m_nMaxValue = value;
            }
        }

        // Value 
        public int Value
        {
            get
            {
                return m_nValue;
            }

            set
            {
                m_nValue = value;
                TextBox_Spin.Text = m_nValue.ToString();
            }
        }




        #region TextBox 속성

       
        public bool IsReadOnly
        {
            get { return (bool)GetValue(IsReadOnlyValueProperty); }
            set { SetValue(IsReadOnlyValueProperty, value); }
        }

        public static readonly DependencyProperty IsReadOnlyValueProperty =
            DependencyProperty.Register("IsReadOnly", typeof(bool), typeof(SpinTextBox), new UIPropertyMetadata(false));

        public TextAlignment TextAlignment
        {
            get { return (TextAlignment)GetValue(TextAlignmentValueProperty); }
            set { SetValue(TextAlignmentValueProperty, value); }
        }

        public static readonly DependencyProperty TextAlignmentValueProperty =
            DependencyProperty.Register("TextAlignment", typeof(TextAlignment), typeof(SpinTextBox), new UIPropertyMetadata(TextAlignment.Left));

        #endregion TextBox 속성


        #region RepeatButton 속성

        public int Delay
        {
            get { return (int)GetValue(DelayValueProperty); }
            set { SetValue(DelayValueProperty, value); }
        }

        public static readonly DependencyProperty DelayValueProperty =
            DependencyProperty.Register("Delay", typeof(int), typeof(SpinTextBox), new UIPropertyMetadata(500));

        public int Interval
        {
            get { return (int)GetValue(IntervalValueProperty); }
            set { SetValue(IntervalValueProperty, value); }
        }

        public static readonly DependencyProperty IntervalValueProperty =
            DependencyProperty.Register("Interval", typeof(int), typeof(SpinTextBox), new UIPropertyMetadata(33));

        #endregion RepeatButton 속성

        // value 증가 버튼 클릭이벤트
        private void Click_Button_Increase(object sender, RoutedEventArgs e)
        {
            m_nValue++;
            if (m_nValue > m_nMaxValue)
                m_nValue = m_nMaxValue;

            TextBox_Spin.Text = m_nValue.ToString();

        }

        // value 감소 버튼 클릭이벤트
        private void Click_Button_Decrease(object sender, RoutedEventArgs e)
        {
            m_nValue--;
            if (m_nValue < m_nMinValue)
                m_nValue = m_nMinValue;

            TextBox_Spin.Text = m_nValue.ToString();
        }

        // value 입력 처리 함수
        private void LostFocus_TextBox_Spin(object sender, RoutedEventArgs e)
        {
            int nValue;
            if (int.TryParse(TextBox_Spin.Text, out nValue) == true)
            {
                m_nValue = nValue;

                if (m_nValue < m_nMinValue)
                    m_nValue = m_nMinValue;

                if (m_nValue > m_nMaxValue)
                    m_nValue = m_nMaxValue;

                TextBox_Spin.Text = m_nValue.ToString();
            }
            else
            {
                TextBox_Spin.Text = m_nValue.ToString();
            }
        }
    }
}
