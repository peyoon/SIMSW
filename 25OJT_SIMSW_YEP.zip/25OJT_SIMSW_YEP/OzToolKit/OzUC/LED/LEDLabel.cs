﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace OzUC
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// LED 효과 적용 Label 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 30일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class LEDLabel : Label
    {
        private E_LEDStatus m_eLEDStatus;           // 상태 정보
        private bool m_bDetectChangeValue;   // 값 변경에 따른 애니매이션 사용 유무

        private Storyboard m_storyboard;           // 깜빡임 애니매이션 story
        private ColorAnimation m_animation;            // 깜빡임 애니매이션

        // Idle 상태 컬러 (시작, 끝)
        private Color m_IdleFrom;             // 시작
        private Color m_IdleTo;               // 끝

        // Off 상태 컬러 (시작, 끝)
        private Color m_OffFrom;              // 시작
        private Color m_OffTo;                // 끝

        // On 상태 컬러 (시작, 끝)
        private Color m_OnFrom;               // 시작
        private Color m_OnTo;                 // 끝


        // 값 변경 감지 사용 유무 - 감지시 애니매이션 동작
        public bool IsDetectChangeValue
        {
            get
            {
                return m_bDetectChangeValue;
            }

            set
            {
                m_bDetectChangeValue = value;
            }
        }

        // 애니매이션 속도 설정 - 시간[s] (ex: 0:0:1)
        // ex) AnimateDuration 0:0:1 설정시 
        // To 까지 1초, 다시 From까지 1초 동작
        public Duration AnimateDuration
        {
            set
            {
                m_animation.Duration = value;
            }
        }

        // 애니메이션 동작 시간 - 시간[s] (ex: 0:0:4)
        // ex1) AnimateDuration == 0:0:1일 때 1회 깜빡임을 구현할 때는 AnimateRepeatBehavior=0:0:2로 설정
        //      To까지 1초, 다시 From까지 1초 원상태까지 2초 걸림        
        // ex2) AnimateDuration=0:0:1일 때 AnimateRepeatBehavior=0:0:4 => 2회 깜빡임
        // 무한: Forever => AnimationStop()이 호출때까지 반복동작
        public RepeatBehavior AnimateRepeatBehavior
        {
            set
            {
                m_animation.RepeatBehavior = value;
            }
        }

        // 상태 정보 - m_eLEDStatus
        public E_LEDStatus LEDStatus
        {
            get
            {
                return m_eLEDStatus;
            }

            set
            {
                switch (value)
                {
                    case E_LEDStatus.Idle:
                        m_animation.To = m_IdleTo;
                        m_animation.From = m_IdleFrom;
                        this.Background = new SolidColorBrush(m_IdleFrom);
                        break;
                    case E_LEDStatus.Off:
                        m_animation.To = m_OffTo;
                        m_animation.From = m_OffFrom;
                        this.Background = new SolidColorBrush(m_OffFrom);
                        break;
                    case E_LEDStatus.On:
                        m_animation.To = m_OnTo;
                        m_animation.From = m_OnFrom;
                        this.Background = new SolidColorBrush(m_OnFrom);
                        break;
                    default:
                        break;
                }

                // 값 변경시 LED 동작
                if (m_eLEDStatus != value && m_bDetectChangeValue == true)
                {
                    m_storyboard.Begin();
                }

                m_eLEDStatus = value;
            }
        }

        ////////////////////
        // 색상 설정

        // Idle 상태 컬러 (시작, 끝)
        public Color IdleTo
        {
            set
            {
                m_IdleTo = value;
            }
        }

        public Color IdleFrom
        {
            set
            {
                m_IdleFrom = value;
            }
        }

        // Off 상태 컬러 (시작, 끝)
        public Color OffTo
        {
            set
            {
                m_OffTo = value;
            }
        }

        public Color OffFrom
        {
            set
            {
                m_OffFrom = value;
            }
        }

        // On 상태 컬러 (시작, 끝)
        public Color OnTo
        {
            set
            {
                m_OnTo = value;
            }
        }

        public Color OnFrom
        {
            set
            {
                m_OnFrom = value;
            }
        }



        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 생성자
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public LEDLabel() : base()
        {
            this.Style = (Style)FindResource(typeof(Label));

            // 값 변경에 따른 애니매이션 사용 유무
            m_bDetectChangeValue = true;

            // 기본 색상 설정
            m_IdleTo = Colors.LightGray;
            m_IdleFrom = Colors.Gray;

            m_OffTo = Colors.LightPink;
            m_OffFrom = Colors.Red;

            m_OnTo = Colors.LightGreen;
            m_OnFrom = Colors.Green;

            // LED Stroryboard 적용
            m_storyboard = new Storyboard();
            m_animation = new ColorAnimation();
            m_animation.Duration = new Duration(TimeSpan.FromSeconds(1));
            m_animation.AutoReverse = true;
            m_animation.RepeatBehavior = new RepeatBehavior(4);

            Storyboard.SetTarget(m_animation, this);
            Storyboard.SetTargetProperty(m_animation, new PropertyPath("Background.(SolidColorBrush.Color)"));
            m_storyboard.Children.Add(m_animation);

            // LED 상태 설정
            LEDStatus = E_LEDStatus.Idle;

            // 기본 컬러
            this.Background = new SolidColorBrush(m_IdleFrom);

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// LED(애니매이션) 동작 시작
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void AnimationBegin()
        {
            m_storyboard.Begin();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// LED(애니매이션) 동작 종료
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void AnimationStop()
        {
            m_storyboard.Stop();
        }

    }
}
