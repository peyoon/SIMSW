using System;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace OzUC.MaskedTextBoxImpl
{
	public enum FilterType
	{
		Any,
		Number,
		UNumber,
		Decimal,
		UDecimal
	}

	public class DefaultFilter
	{
		private Func<string, bool> _isTextValidCheckers;

		public static readonly DefaultFilter IntegerFilter = new DefaultFilter(item => int.TryParse(item, out _));
		public static readonly DefaultFilter NullFilter = new DefaultFilter();

		public DefaultFilter() { }

		public DefaultFilter(Func<string, bool> additionalValidator)
		{
			AddTextValidator(additionalValidator);
		}

		protected void AddTextValidator(Func<string, bool> additionalValidator)
		{
			if (_isTextValidCheckers is null || !_isTextValidCheckers.GetInvocationList().Contains(additionalValidator))
			{
				_isTextValidCheckers += additionalValidator;
			}
		}

		public bool IsTextValid(string newText)
		{
			if (_isTextValidCheckers is null)
			{
				return true;
			}

			foreach (var isTextValidChecker in _isTextValidCheckers.GetInvocationList())
			{
				Func<string, bool> checker = isTextValidChecker as Func<string, bool>;
				//if (isTextValidChecker is not Func<string, bool> checker)
				//{
				//	continue;
				//}
				if (!checker(newText))
				{
					return false;
				}
			}

			return true;
		}
	}

	public class RegExFilter : DefaultFilter
	{
		public static readonly RegExFilter UNumberFilter = new RegExFilter(@"^\d*$");
		public static readonly RegExFilter NumberFilter = new RegExFilter(@"^-?\d*$");
		public static readonly RegExFilter UDecimalFilter = new RegExFilter(@"^\d*([.,]\d*)?$");
		public static readonly RegExFilter DecimalFilter = new RegExFilter(@"^-?\d*([\.,]\d*)?$");

		public int? MaxLength { get; }

		private readonly Regex _regEx;

		public RegExFilter(string regExp, int? maxLength = null)
		{
			_regEx = string.IsNullOrEmpty(regExp) ? null : new Regex(regExp);
			AddTextValidator(CheckRegExp);
			MaxLength = maxLength;
			AddTextValidator(CheckMaxLength);
		}

		public RegExFilter(int? maxLength) : this(string.Empty, maxLength) { }

		private bool CheckRegExp(string newText)
		{
			return _regEx is null || _regEx.Match(newText).Success;
		}

		private bool CheckMaxLength(string newText)
		{
			return !MaxLength.HasValue || MaxLength.Value >= newText.Length;
		}
	}

	public class FilterProvider
	{
		private static readonly Lazy<FilterProvider> InstanceLazy = new Lazy<FilterProvider>(() => new FilterProvider());
		public static FilterProvider Instance => InstanceLazy.Value;

		private readonly Dictionary<FilterType, DefaultFilter> _predefinedFilters = new Dictionary<FilterType, DefaultFilter>();

		private FilterProvider()
		{
			LoadValues();
		}

		private void LoadValues()
		{
			_predefinedFilters.Add(FilterType.Any, DefaultFilter.NullFilter);
			_predefinedFilters.Add(FilterType.Number, RegExFilter.NumberFilter);
			_predefinedFilters.Add(FilterType.Decimal, RegExFilter.DecimalFilter);
			_predefinedFilters.Add(FilterType.UNumber, RegExFilter.UNumberFilter);
			_predefinedFilters.Add(FilterType.UDecimal, RegExFilter.UDecimalFilter);
		}

		public DefaultFilter FilterForMaskedType(FilterType type)
		{
			var filter = _predefinedFilters[type];
			return filter ?? DefaultFilter.NullFilter;
		}
	}
}
