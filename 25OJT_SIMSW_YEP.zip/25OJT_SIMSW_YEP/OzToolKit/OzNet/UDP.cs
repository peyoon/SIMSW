﻿using System;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace OzNet
{

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> UDP 통신 클래스 - 송수신
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 05월 14일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class UDP
    {
        private const int   MAX_BUFFER      = short.MaxValue;   // 수신 최대 버퍼 사이즈

        private Socket      m_cSocketHost   = null;             // Host 소켓
        private EndPoint    m_epRemote      = null;             // 원격지 정보
        private Thread      m_thRecvice     = null;             // 수신 스레드
        private bool        m_isRunning     = false;            // 통신 사용 여부



        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 패킷 수신 이벤트
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] byPacket        -  수신 패킷 버퍼
        /// <br/>       [in] iPacketSize     -  수신 패킷 사이즈
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="byPacket"> [in] 수신 패킷 버퍼 </param>
        /// <param name="iPacketSize">[in] 수신 패킷 사이즈</param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public delegate void Handler_Received(byte[] byPacket, int iPacketSize);
        public event Handler_Received Event_Received;

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 생성자
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public UDP() 
        {
            m_cSocketHost = null;        // Host 소켓
            m_epRemote = null;          // 원격지 정보
            m_thRecvice = null;         // 수신 스레드
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> UDP 통신 연결
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] strRemoteIP -  원격지 IP
        /// <br/>       [in] nRemotePort -  원격지 Port
        /// <br/>       [in] strHostIP   -  Host IP
        /// <br/>       [in] nHostPort   -  Host Port
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="strRemoteIP">  [in] 원격지 IP     </param>
        /// <param name="nRemotePort">  [in] 원격지 Port   </param>
        /// <param name="strHostIP">    [in] Host IP        </param>
        /// <param name="nHostPort">    [in] Host Port      </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Connect(string strRemoteIP, int nRemotePort, string strHostIP, int nHostPort)
        {
            IPEndPoint ipepHost = new IPEndPoint(IPAddress.Parse(strHostIP), nHostPort);
            IPEndPoint ipepRemote = new IPEndPoint(IPAddress.Parse(strRemoteIP), nRemotePort);
            m_epRemote = ipepRemote as EndPoint;

            // 기존 소켓 종료
            Close();

            // Host 소켓 생성 및 binding
            Socket m_SocketHost = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            m_SocketHost.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            m_SocketHost.Bind(ipepHost);

            // 수신 스레드 생성
            m_isRunning = true;
            m_thRecvice = new Thread(new ThreadStart(procThread_Receive));
            m_thRecvice.IsBackground = true;
            m_thRecvice.Start();

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 소켓 종료
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Close()
        {
            if (m_cSocketHost != null)
            {
                // 소켓 종료
                m_cSocketHost.Close();
                m_cSocketHost = null;

                // 수신 스레드 종료
                m_isRunning = false;
                m_thRecvice.Join(1000);

            }

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> UDP 통신 동작 여부
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : t-동작, f-동작안함
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <returns>   t-동작, f-동작안함    </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool IsRunning()
        {
            return m_isRunning;
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 데이터 송신
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] packet  -  송신 패킷 버퍼
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="byPacket"> [in] 송신 패킷 버퍼    </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Send(byte[] byPacket)
        {
            if (m_epRemote != null)
                m_cSocketHost.SendTo(byPacket, byPacket.Length, SocketFlags.None, m_epRemote);
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 스레드 처리 - 수신 스레드
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void procThread_Receive()
        {
            try
            {
                while (m_isRunning == true)
                {
                    byte[] byPacket = new byte[MAX_BUFFER];
                    int iPacketSize = 0;

                    if (m_cSocketHost != null)
                        iPacketSize = m_cSocketHost.ReceiveFrom(byPacket, ref m_epRemote);

                    // packet 전달
                    if (Event_Received != null && iPacketSize != 0)
                        Event_Received(byPacket, iPacketSize);
                }

            }
            catch (Exception ex)
            {
                Close();
                Console.WriteLine(ex);
            }

        }
                

    }


}
