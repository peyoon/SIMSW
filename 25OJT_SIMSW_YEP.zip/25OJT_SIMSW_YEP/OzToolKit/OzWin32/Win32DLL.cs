﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace OzWin32
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> System DLL 함수 클래스
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 05월 14일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public partial class Win32DLL
    {

        #region INI 파일 처리

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> ini 파일에서 정보 얻기 
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>   [in] section    - Section 명
        /// <br/>   [in] key        - key 명
        /// <br/>   [in] def        - Default 값
        /// <br/>   [out] retVal    - Sectino, key에서 가르키는 값을 저장할 버퍼 (string 버퍼)
        /// <br/>   [in] size       - 저장할 버퍼 사이즈(문자 수)
        /// <br/>   [in] filePath   - ini 파일 경로
        /// <br/> 
        /// <br/> 반 환 값 : 복사된 문자 수
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>                
        /// <param name="section">[in] Section 명</param>
        /// <param name="key">[in] key 명</param>
        /// <param name="def">[in] Default 값</param>
        /// <param name="retVal">[out] Sectino, key에서 가르키는 값을 저장할 버퍼 (string 버퍼) </param>
        /// <param name="size">[in] 저장할 버퍼 사이즈(문자 수)</param>
        /// <param name="filePath">[in] ini 파일 경로</param>
        /// <returns>복사된 문자 수</returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("kernel32")]
		public static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal,
														int size, string filePath);

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> ini 파일에서 정보 저장
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>   [in] section    - Section 명
        /// <br/>   [in] key        - key 명
        /// <br/>   [in] val        - 저장할 문자열
        /// <br/>   [in] filePath   - ini 파일 경로
        /// <br/> 
        /// <br/> 반 환 값 : 복사된 문자 수
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>    
        /// <param name="section">[in] Section 명</param>
        /// <param name="key">[in] key 명</param>
        /// <param name="val">[in] 저장할 문자열</param>
        /// <param name="filePath">[in] ini 파일 경로</param>
        /// <returns>실패시 0, 성공시 0 외의 값</returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("kernel32")]
		public static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        #endregion INI 파일 처리		




        #region DLL 파일 처리

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 지정된 모듈(DLL)을 호출 프로세스의 주소 공간에 로드
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>   [in] librayName    - library 파일 명
        /// <br/> 
        /// <br/> 반 환 값 : 성공시 모듈 핸들, 실패시 null
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>    
        /// <param name="librayName">[in] library 파일 명</param>
        /// <returns>성공시 묘듈 핸들, 실패시 null</returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("kernel32.dll", EntryPoint = "LoadLibrary")]
        public static extern IntPtr LoadLibrary(string librayName);


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 지정된 DLL(동적 연결 라이브러리)에서 내보낸 함수(프로시저라고도 함) 또는 변수의 주소를 검색
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>   [in] hModule           - DLL 모듈에 대한 핸들
        /// <br/>   [in] procedureName  - 함수 또는 변수 이름 또는 함수의 서수(명)
        /// <br/> 
        /// <br/> 반 환 값 : 성공시 함수 또는 변수 주소, 실패시 null
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>    
        /// <param name="hModule">[in] DLL 모듈에 대한 핸들</param>
        /// <param name="procedureName">[in] 함수 또는 변수 이름 또는 함수의 서수(명)</param>
        /// <returns>성공시 함수 또는 변수 주소, 실패시 null</returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("kernel32.dll", EntryPoint = "GetProcAddress", CharSet = CharSet.Ansi)]
        public static extern IntPtr GetProcAddress(IntPtr hModule, string procedureName);


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 로드된 DLL(동적 연결 라이브러리) 모듈을 해제
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>   [in] hModule       - DLL 모듈에 대한 핸들
        /// <br/> 
        /// <br/> 반 환 값 : 해제 성공 유무
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// <param name="hModule">[in] DLL 모듈에 대한 핸들param>
        /// <returns>해제 성공 유무</returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("kernel32.dll", EntryPoint = "FreeLibrary")]
        public static extern bool FreeLibrary(IntPtr hModule);


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 지정된 모듈(DLL)에 대한 모듈 핸들을 검색
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>   [in] librayName    - Libray 명
        /// <br/> 
        /// <br/> 반 환 값 : 성공시 모듈 핸들, 실패시 null
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// <param name="librayName">[in] Libray 명</param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("kernel32")]
        public static extern IntPtr GetModuleHandle(string librayName);

        #endregion DLL 파일 처리


    }
}
