﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace OzUtil
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> string Parser 클래스
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public class StringParse
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> TextBox에서 string 값을 읽어 double 형태의 설정된 포맷으로 설정
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] uiTextBox  - 대상 TextBox 컨트롤
        /// <br/>       [out] dValue    - 변환된 값
        /// <br/>       [in] dMax       - 변환 최대 값
        /// <br/>       [in] dMin       - 변환 최소 값
        /// <br/>       [in] dDefault   - 변환실패시 default값
        /// <br/>       [in] nDotNum    - 소수점 자릿수
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 06월 26일
        /// </summary>        
        /// <param name="uiTextBox"> [in] 대상 TextBox 컨트롤 </param>
        /// <param name="dValue"> [out] 변환된 값 </param>
        /// <param name="dMax"> [in] 변환 최대 값 </param>
        /// <param name="dMin"> [in] 변환 최소 값 </param>
        /// <param name="dDefault"> [in] 변환실패시 default값 </param>
        /// <param name="nDotNum"> [in] 소수점 자릿수 </param>        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void TextBox_TryParse_Double(TextBox uiTextBox, ref double dValue, double dMax, double dMin, double dDefault, int nDotNum = 1)
        {
            double dTemp = 0;
            bool bIsdouble = double.TryParse(uiTextBox.Text, out dTemp);

            if (bIsdouble == false)
            {
                dValue = dDefault;

                string strDotFormat = string.Format($"F{nDotNum}");
                uiTextBox.Text = dValue.ToString(strDotFormat);
            }
            else
            {
                if (dTemp <= dMin)
                {
                    dValue = dMin;
                }
                else if (dTemp >= dMax)
                {
                    dValue = dMax;
                }
                else
                {
                    dValue = dTemp;
                }

                string strDotFormat = string.Format($"F{nDotNum}");
                uiTextBox.Text = dValue.ToString(strDotFormat);
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> String에서 string 값을 읽어 double 형태의 설정된 포맷으로 설정
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in/out] strValue   - 대상 string값
        /// <br/>       [out] dValue        - 변환된 값
        /// <br/>       [in] dMax           - 변환 최대 값
        /// <br/>       [in] dMin           - 변환 최소 값
        /// <br/>       [in] dDefault       - 변환실패시 default값
        /// <br/>       [in] nDotNum        - 소수점 자릿수
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 06월 26일
        /// </summary>        
        /// <param name="strValue"> [in/out] 대상 string값 </param>
        /// <param name="dValue"> [out] 변환된 값 </param>
        /// <param name="dMax"> [in] 변환 최대 값 </param>
        /// <param name="dMin"> [in] 변환 최소 값 </param>
        /// <param name="dDefault"> [in] 변환실패시 default값 </param>
        /// <param name="nDotNum"> [in] 소수점 자릿수 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void String_TryParse_Double(ref string strValue, ref double dValue, double dMax, double dMin, double dDefault, int nDotNum = 1)
        {
            double dTemp = 0;
            bool bIsdouble = double.TryParse(strValue, out dTemp);

            if (bIsdouble == false)
            {
                dValue = dDefault;

                string strDotFormat = string.Format($"F{nDotNum}");
                strValue = dValue.ToString(strDotFormat);
            }
            else
            {
                if (dTemp <= dMin)
                {
                    dValue = dMin;
                }
                else if (dTemp >= dMax)
                {
                    dValue = dMax;
                }
                else
                {
                    dValue = dTemp;
                }

                string strDotFormat = string.Format($"F{nDotNum}");
                strValue = dValue.ToString(strDotFormat);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> TextBox에서 string 값을 읽어 int 형태의 설정된 포맷으로 설정
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] uiTextBox  - 대상 TextBox 컨트롤
        /// <br/>       [out] dValue    - 변환된 값
        /// <br/>       [in] dMax       - 변환 최대 값
        /// <br/>       [in] dMin       - 변환 최소 값
        /// <br/>       [in] dDefault   - 변환실패시 default값        
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 06월 26일
        /// </summary>        
        /// <param name="uiTextBox"> [in] 대상 TextBox 컨트롤 </param>
        /// <param name="nValue"> [out] 변환된 값 </param>
        /// <param name="nMax"> [in] 변환 최대 값 </param>
        /// <param name="nMin"> [in] 변환 최소 값 </param>
        /// <param name="nDefault"> [in] 변환실패시 default값 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void TextBox_TryParse_Int(TextBox uiTextBox, ref int nValue, int nMax, int nMin, int nDefault)
        {
            int nTemp = 0;
            bool bIsInt = int.TryParse(uiTextBox.Text, out nTemp);

            if (bIsInt == false)
            {
                nValue = nDefault;
                uiTextBox.Text = Convert.ToString(nDefault);
            }
            else
            {
                if (nMin >= nTemp)
                {
                    nValue = nMin;
                }
                else if (nTemp >= nMax)
                {
                    nValue = nMax;
                }
                else
                {
                    nValue = nTemp;
                }

                uiTextBox.Text = Convert.ToString(nValue);
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> String에서 string 값을 읽어 int 형태의 설정된 포맷으로 설정
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in/out] strValue  - 대상 string값
        /// <br/>       [out] dValue    - 변환된 값
        /// <br/>       [in] dMax       - 변환 최대 값
        /// <br/>       [in] dMin       - 변환 최소 값
        /// <br/>       [in] dDefault   - 변환실패시 default값
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 06월 26일
        /// </summary>        
        /// <param name="strValue"> [in/out] 대상 string값 </param>
        /// <param name="nValue"> [out] 변환된 값 </param>
        /// <param name="nMax"> [in] 변환 최대 값 </param>
        /// <param name="nMin"> [in] 변환 최소 값 </param>
        /// <param name="nDefault"> [in] 변환실패시 default값 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void String_TryParse_Int(ref string strValue, ref int nValue, int nMax, int nMin, int nDefault)
        {
            int nTemp = 0;
            bool bIsInt = int.TryParse(strValue, out nTemp);

            if (bIsInt == false)
            {
                nValue = nDefault;
                strValue = Convert.ToString(nDefault);
            }
            else
            {
                if (nMin >= nTemp)
                {
                    nValue = nMin;
                }
                else if (nTemp >= nMax)
                {
                    nValue = nMax;
                }
                else
                {
                    nValue = nTemp;
                }

                strValue = Convert.ToString(nValue);
            }
        }

    }
}
