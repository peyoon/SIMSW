﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace OzUtil
{
    public static class ExUtils
    {
        /// <summary>
        /// byte 를 hex 형식으로 반환 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="concat">연결자</param>
        /// <returns></returns>
        public static string TobytesToStringEx(this byte[] values,string concat="-")
        {
            StringBuilder sb = new StringBuilder();
            foreach (var b in values)
            {
                sb.Append($"{b.ToString("X2")}{concat}");
            }

            return sb.ToString();
        }


        /// <summary>
        /// 전체 배열의 일부 부분을 반환
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="array"></param>
        /// <param name="startidx">시작 IDX 0 부터시작 </param>
        /// <param name="length">길이</param>
        /// <returns></returns>
        public static T[] ToArraySubReturnEx<T>(this T[] array, int startidx, int length)
        {

            T[] result = new T[length];

            Array.Copy(array, startidx, result, 0, length);

            return result;
        }


        /// <summary>
        /// BYTE 배열을  bit string으로 변환 
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="reverse">BYTE 하나당의 BIT를 뒤집을지 유무</param>
        /// <returns></returns>
        public static string ToByteArrBitResultsEx(this byte[] bytes, bool reverse = false)
        {
            StringBuilder sb = new StringBuilder();

            if (reverse)
            {
                foreach (var item in bytes)
                {
                    sb.Append(Convert.ToString(item, 2).PadLeft(8, '0'));
                }

                return new string(sb.ToString().Reverse().ToArray());
            }
            else
            {
                foreach (var item in bytes)
                {
                    sb.Append(Convert.ToString(item, 2).PadLeft(8, '0'));
                }

                return sb.ToString();
            }
        }

        /// <summary>
        /// 문자열의 Render시 사이즈값 리턴 
        /// </summary>
        /// <param name="str"></param>
        /// <param name="currentDpi"></param>
        /// <param name="typefacename"></param>
        /// <param name="fontsize"></param>
        /// <returns></returns>
        public static System.Windows.Size RendertxtSizeEx(this string str
    , DpiScale currentDpi
    , string typefacename
    , double fontsize
    )
        {

            var rendertxt = new FormattedText(str,
                CultureInfo.InvariantCulture
                , FlowDirection.LeftToRight
                , new Typeface(typefacename)
                , fontsize * (currentDpi.PixelsPerInchX / 72)
                , System.Windows.Media.Brushes.Black
                , currentDpi.PixelsPerInchX
                );

            var txtszie = new System.Windows.Size(rendertxt.Width, rendertxt.Height);


            return txtszie;

        }


        /// <summary>
        /// bytes param에 byte arr 리스트를 추가 하여 리턴 
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="startidx"></param>
        /// <param name="byteList"></param>
        /// <returns></returns>
        public static byte[] UnionByteMessageEx(this byte[] bytes, int startidx, List<byte[]> byteList)
        {

            for (int i = 0; i < byteList.Count; i++)
            {
                Array.Copy(byteList[i], 0, bytes, startidx, byteList[i].Length);

                startidx = startidx + byteList[i].Length;
            }

            return bytes;
        }


        /// <summary>
        /// byte  를 합치는 확장 메서드 
        /// </summary>
        /// <param name="header"></param>
        /// <param name="body"></param>
        /// <returns></returns>
        public static byte[] TotalMessageEx(this byte header, byte[] body)
        {
            byte[] resultbyte = new byte[1 + body.Length];

            resultbyte[0] = header;
            Array.Copy(body, 0, resultbyte, 1, body.Length);

            return resultbyte;
        }

        /// <summary>
        /// byte  배열 를 합치는 확장 메서드 
        /// </summary>
        /// <param name="header"></param>
        /// <param name="body"></param>
        /// <returns></returns>
        public static byte[] TotalMessageEx(this byte[] header, byte[] body)
        {
            byte[] resultbyte = new byte[header.Length + body.Length];

            Array.Copy(header, resultbyte, header.Length);
            Array.Copy(body, 0, resultbyte, header.Length, body.Length);

            return resultbyte;
        }



        /// <summary>
        /// 파일 확장자 지우기
        /// </summary>
        /// <returns></returns>
        public static string ToRemoveextensionEx(this string filename)
        {
            var indexof = filename.LastIndexOf(".");

            string purefilename = filename.Substring(0, indexof);

            return purefilename;
        }
    }
}
