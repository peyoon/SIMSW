﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzUtil
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> 심플 난독화 처리 클래스
    /// <br/> 작 성 자 : 박종일
    /// <br/> 작 성 일 : 2025년 06월 02일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public class SimpleCodeObfuscation
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 파일 난독화
        /// <br/>
        /// <br/> 파라미터 :  
        /// <br/>       [in] inputPath      - 입력 파일 Path
        /// <br/>       [in] outputPath     - 난독화 처리 출력 파일 Path
        /// <br/>       [in] key            - 난독화 key(mask) 값 : Encoding.UTF8.GetBytes("Olzetek")
        /// <br/>
        /// <br/> 반 환 값 : -
        /// <br/>
        /// <br/> 작 성 자 : 박종일
        /// <br/> 작 성 일 : 2025년 06월 02일
        /// </summary>        
        /// <param name="inputPath"> [in] 입력 파일 Path </param>
        /// <param name="outputPath"> [in] 난독화 처리 출력 파일 Path </param>
        /// <param name="key"> [in] 난독화 key(mask) 값 : Encoding.UTF8.GetBytes("Olzetek") </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void XorFile(string inputPath, string outputPath, byte[] key)
        {
            byte[] inputBytes = System.IO.File.ReadAllBytes(inputPath);
            byte[] outputBytes = new byte[inputBytes.Length];

            //for (int bit = 0; bit < inputBytes.Length; bit++)
            Parallel.For(0, inputBytes.Length, bit =>                        
            {
                outputBytes[bit] = (byte)(inputBytes[bit] ^ key[bit % key.Length]);
            });            

            System.IO.File.WriteAllBytes(outputPath, outputBytes);
        }

    }
}