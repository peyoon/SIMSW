﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace OzUtil
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> EXCEL 파일 Export 클래스
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 05월 14일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class OzExcel
    {

        private Application     m_appExcel = null;      // Excel 프로그램
        private Workbook        m_workbook = null;      // 작업중인 excel

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> EXCEL 파일 열기
        /// <br/> 
        /// <br/> 파라메터 : 
        /// <br/>       [in] strFilePath - Excel 파일명 (전체 경로)
        /// <br/>       [in] password    - Excel 파일 open 시 패스워드 
        /// <br/>       [in] bVisible   : t - Excel 화면 전시, f - Excel 화면 미전시
        /// <br/>       [in] isreadonly : t - Excel 읽기전용으로 읽기, f - Excel 수정으로 읽기
        /// <br/> 반 환 값 : 열기 성공 유무
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="strFilePath"> [in] strFilePath - Excel 파일명 (전체 경로) </param>
        /// <param name="bVisible"> t - Excel 화면 전시, f - Excel 화면 미전시 </param>
        /// <returns> 열기 성공 유무 </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool Open(string strFilePath, string password="", bool bVisible = false, bool isreadonly=true)
        {
            bool bSucessed = false;
            m_appExcel = null;
            m_workbook = null;            

            try
            {
                //Excel 프로그램 실행
                m_appExcel = new Microsoft.Office.Interop.Excel.Application();
                //Excel 화면 띄우기 옵션
                m_appExcel.Visible = bVisible;
                //파일로부터 불러오기
                m_workbook = m_appExcel.Workbooks.Open(strFilePath,Password:password,ReadOnly: isreadonly);

                bSucessed = true;

            }
            catch (Exception ex)
            {
                //Excel 프로그램 종료
                m_appExcel.Quit();

                //오브젝트 해제
                if (m_workbook != null)
                {
                    //변경점 저장하면서 닫기
                    m_workbook.Close(true);
                    Marshal.ReleaseComObject(m_workbook);
                }

                if (m_appExcel != null)
                    Marshal.ReleaseComObject(m_appExcel);

                System.Windows.MessageBox.Show(ex.Message);
                System.Console.WriteLine(ex);
            }

            return bSucessed;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> EXCEL 파일 저장
        /// <br/> 
        /// <br/> 파라메터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Save()
        {
            try
            {
                m_workbook.Save();                
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> EXCEL 파일 종료 - 정상 종료를 안하면 백그라운드로 실행상태가 유지된다. 작업관리자를 통해 삭제 필요
        /// <br/> 
        /// <br/> 파라메터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Close()
        {
            try
            {
                //변경점 저장하면서 닫기
                if (m_workbook != null)
                    m_workbook.Close(true);

                //Excel 프로그램 종료
                if (m_appExcel != null)
                    m_appExcel.Quit();


                //오브젝트 해제
                if (m_workbook != null)
                    Marshal.ReleaseComObject(m_workbook);

                if (m_appExcel != null)
                    Marshal.ReleaseComObject(m_appExcel);
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex);
            }
            
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 수정할 Worksheet 가져오기 (인덱스)
        /// <br/> 
        /// <br/> 파라메터 : 
        /// <br/>       [in] idxWorksheet - Worksheet 인덱스
        /// <br/> 
        /// <br/> 반 환 값 : 해당 Worksheet (없으면 null)
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="idxWorksheet"> [in] Worksheet 인덱스 </param>
        /// <returns> 해당 Worksheet (없으면 null) </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public Microsoft.Office.Interop.Excel.Worksheet GetWorksheet(int idxWorksheet)
        {
            Worksheet ws = null;

            try
            {
                if (m_workbook != null)
                {
                    ws = m_workbook.Worksheets.Item[idxWorksheet];
                }
            }
            catch (Exception ex)
            {
                ws = null;

                System.Console.WriteLine(ex);
            }

            return ws;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 수정할 Worksheet 가져오기 (Worksheet 이름) | 시작 인덱스 1 
        /// <br/> 
        /// <br/> 파라메터 : 
        /// <br/>       [in] strSheetName - Worksheet 이름 
        /// <br/> 
        /// <br/> 반 환 값 : 해당 Worksheet (없으면 null)
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="strSheetName"> [in] Worksheet 이름 </param>
        /// <returns> 해당 Worksheet (없으면 null) </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public Microsoft.Office.Interop.Excel.Worksheet GetWorksheet(string strSheetName)
        {
            Worksheet ws = null;

            try
            {
                if (m_workbook != null)
                {
                    ws = m_workbook.Worksheets[strSheetName];
                }
            }
            catch (Exception ex)
            {
                ws = null;

                System.Console.WriteLine(ex);
            }

            return ws;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 수정할 Worksheet 가져오기 (Worksheet 이름)
        /// <br/> 
        /// <br/> 파라메터 : 없음
        /// <br/> 
        /// <br/> 반 환 값 : int 
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 07월 03일
        /// </summary>        
        /// <param name="strSheetName"> [in] Worksheet 이름 </param>
        /// <returns>문제시 0  </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public int GetWorksheetCount()
        {
            Workbook read_wb = null;
            int count = 0;

            try
            {
                read_wb = m_workbook;
                count = read_wb.Worksheets.Count;

            }
            catch (Exception ex)
            {
                count = 0;
                System.Console.WriteLine(ex);
            }

            return count;
        }
    }
}
