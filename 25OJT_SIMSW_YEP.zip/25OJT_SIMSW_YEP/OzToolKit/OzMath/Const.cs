﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzMath
{
    public class Const
    {
        // 원주률
		public const double PI          = 3.14159265358979323846;
		public const double PI_DIV_180  = 0.0174532925199432957692;
		public const double DEG2RAD     = 0.0174532925199432957692;
		public const double RAD2DEG     = 57.2957795130823229;
		public const double EARTH_RADIUS = 6378137.0;                  // 타원체의 장반경 (적도)

		// 단위 변환
		public const double KM2M    = 1000.0;
		public const double M2KM    = 0.001;
		public const double NM2KM   = 1.852;
		public const double KM2NM   = 0.5399568034557235;
		public const double M2FT    = 0.3048;
		public const double FT2M    = 3.28084;
		        
    }
}
