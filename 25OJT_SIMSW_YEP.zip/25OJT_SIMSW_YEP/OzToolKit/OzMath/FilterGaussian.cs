﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzMath
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> 가우시안(Gauusian) 필터 클래스
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 08월 01일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class FilterGaussian
    {
        private double[]    m_dKernel1D = null;       // 가우시안 커널 1D
        private double[,]   m_dKernel2D = null;       // 가우시안 커널 2D
        

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 커널 1D 만들기
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] dSigma - 표준편차 (default : 10.0)
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="dSigma">    [in] 표준편차 (default : 10.0)  </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void MakeKenel1D(double dSigma = 10.0)
        {
            int nWidth = 3 * (int)dSigma;    // 커널 너비 표준편차(dSigma)와 연동

            MakeKenel1D(nWidth, dSigma);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 커널 1D 만들기
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] nKernelSize   - 가우시안 커널 크기
        /// <br/>       [in] dSigma          - 표준편차 (default : 10.0)
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="nKernelWidth"> [in] 가우시안 커널 크기  </param>
        /// <param name="dSigma">        [in] 표준편차 (default : 10.0)  </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void MakeKenel1D(int nKernelWidth, double dSigma = 10.0)
        {
            int nWidth = nKernelWidth;
            double[] kernel = new double[nWidth * 2 + 1];
            double sum = 0.0;

            for (int wcnt = -nWidth; wcnt <= nWidth; wcnt++)
            {
                double w = Math.Exp(-(wcnt * wcnt) / (2 * dSigma * dSigma));
                kernel[wcnt + nWidth] = w;
                sum += w;
            }

            // 정규화
            for (int i = 0; i < kernel.Length; i++)
                kernel[i] /= sum;

            m_dKernel1D = kernel;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 1D 필터 적용
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src     - 원본 데이터
        /// <br/>       [in] useCircular    - 순환 인덱스 적용 유무 (default : false)
        /// <br/> 
        /// <br/> 반 환 값 : 필터 적용 결과, null이면 오류
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="src">       [in] 원본 데이터    </param>
        /// <param name="useCircular">      [in] 순환 인덱스 적용 유무 (default : false) </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public double[] ApplyGauusian1D(double[] src, bool useCircular = false)
        {
            double[] arrdResult = null;

            if (m_dKernel1D != null)
            {
                int nKernelRadius = m_dKernel1D.Length / 2;
                arrdResult = new double[src.Length];

                // 필터 적용 (순환 처리)
                for (int datacnt = 0; datacnt < src.Length; datacnt++)
                {
                    double sum = 0.0;

                    for (int krcnt = -nKernelRadius; krcnt <= nKernelRadius; krcnt++)
                    {
                        // 순환 인덱스 처리
                        if (useCircular == true)
                        {

                            int idx = (datacnt + krcnt + src.Length) % src.Length;
                            sum += src[idx] * m_dKernel1D[krcnt + nKernelRadius];
                        }
                        // 선분 인덱스 처리
                        else
                        {
                            int idx = datacnt + krcnt;
                            if (idx >= 0 && idx < src.Length)
                            {
                                sum += src[idx] * m_dKernel1D[krcnt + nKernelRadius];
                            }
                        }
                    }
                    arrdResult[datacnt] = sum;
                }
            }

            return arrdResult;

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 1D 필터 적용
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src     - 원본 데이터
        /// <br/>       [in] useCircular    - 순환 인덱스 적용 유무 (default : false)
        /// <br/> 
        /// <br/> 반 환 값 : 필터 적용 결과, null이면 오류
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="src">       [in] 원본 데이터    </param>
        /// <param name="useCircular">      [in] 순환 인덱스 적용 유무 (default : false) </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public float[] ApplyGauusian1D(float[] src, bool useCircular = false)
        {
            float[] arrfResult = null;

            if (m_dKernel1D != null)
            {
                int nKernelRadius = m_dKernel1D.Length / 2;
                arrfResult = new float[src.Length];

                // 필터 적용 (순환 처리)
                for (int datacnt = 0; datacnt < src.Length; datacnt++)
                {
                    float sum = 0.0f;

                    for (int krcnt = -nKernelRadius; krcnt <= nKernelRadius; krcnt++)
                    {
                        // 순환 인덱스 처리
                        if (useCircular == true)
                        {

                            int idx = (datacnt + krcnt + src.Length) % src.Length;
                            sum += src[idx] * Convert.ToSingle(m_dKernel1D[krcnt + nKernelRadius]);
                        }
                        // 선분 인덱스 처리
                        else
                        {
                            int idx = datacnt + krcnt;
                            if (idx >= 0 && idx < src.Length)
                            {
                                sum += src[idx] * Convert.ToSingle(m_dKernel1D[krcnt + nKernelRadius]);
                            }
                        }
                    }
                    arrfResult[datacnt] = sum;
                }
            }

            return arrfResult;

        }




        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 커널 2D 만들기
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] dSigma - 표준편차 (default : 10.0)
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="dSigma">    [in] 표준편차 (default : 10.0)  </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void MakeKenel2D(double dSigma = 10.0)
        {
            int nSize = 3 * (int)dSigma;    // 커널 너비 표준편차(dSigma)와 연동

            MakeKenel2D(nSize, dSigma);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 커널 2D 만들기
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] nKernelSize   - 가우시안 커널 크기
        /// <br/>       [in] dSigma         - 표준편차 (default : 10.0)
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="nKernelSize">  [in] 가우시안 커널 크기  </param>
        /// <param name="sigma">        [in] 표준편차 (default : 10.0)  </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void MakeKenel2D(int nKernelSize, double sigma = 10.0)
        {
            int nSize = nKernelSize;
            double[,] kernel = new double[nSize, nSize];

            double sum = 0.0;
            int nHalfSize = nSize / 2;

            for (int y = -nHalfSize; y <= nHalfSize; y++)
            {
                for (int x = -nHalfSize; x <= nHalfSize; x++)
                {
                    double w = (1 / (2 * Math.PI * sigma * sigma)) *
                                Math.Exp(-(x * x + y * y) / (2 * sigma * sigma));
                    kernel[y + nHalfSize, x + nHalfSize] = w;
                    sum += w;
                }
            }

            // 정규화
            for (int y = 0; y < nSize; y++)
            {
                for (int x = 0; x < nSize; x++)
                    kernel[y, x] /= sum;
            }

            m_dKernel2D = kernel;
        }
        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 2D 필터 적용
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src     - 원본 데이터        
        /// <br/> 
        /// <br/> 반 환 값 : 필터 적용 결과
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="src">       [in] 원본 데이터    </param>        
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public double[,] ApplyGauusian2D(double[,] src, int nSrcWidth, int nSrcHeight)
        {
            double[,] arrdResult = null;

            // 1차원 배열로 변환
            double[] src1D = new double[nSrcHeight * nSrcWidth];
            Buffer.BlockCopy(src, 0, src1D, 0, nSrcHeight * nSrcWidth * sizeof(double));

            // 필터 적용
            double[] dResult1D = ApplyGauusian2D(src1D, nSrcWidth, nSrcHeight);

            // 결과 2차원 배열로 변환
            if (dResult1D != null)
            {
                arrdResult = new double[nSrcHeight, nSrcWidth];

                for (int srcy = 0; srcy < nSrcHeight; srcy++)
                {
                    for (int srcx = 0; srcx < nSrcWidth; srcx++)
                    {
                        arrdResult[srcy, srcx] = dResult1D[srcy * nSrcWidth + srcx];
                    }
                }
            }

            return arrdResult;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 2D 필터 적용
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src     - 원본 데이터        
        /// <br/> 
        /// <br/> 반 환 값 : 필터 적용 결과
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="src">       [in] 원본 데이터    </param>        
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public double[][] ApplyGauusian2D(double[][] src, int nSrcWidth, int nSrcHeight)
        {
            double[][] arrdResult = null;

            // 1차원 배열로 변환
            double[] src1D = new double[nSrcHeight * nSrcWidth];
            src1D = src.SelectMany(subArray => subArray).ToArray();
            //Buffer.BlockCopy(src, 0, src1D, 0, nSrcHeight * nSrcWidth * sizeof(double));

            // 필터 적용
            double[] dResult1D = ApplyGauusian2D(src1D, nSrcWidth, nSrcHeight);

            // 결과 2차원 배열로 변환
            if (dResult1D != null)
            {
                arrdResult = new double[nSrcHeight][];
                
                for (int srcy = 0; srcy < nSrcHeight; srcy++)
                {
                    arrdResult[srcy] = new double[nSrcWidth];
                    for (int srcx = 0; srcx < nSrcWidth; srcx++)
                    {
                        arrdResult[srcy][srcx] = dResult1D[srcy * nSrcWidth + srcx];
                    }
                }
            }

            return arrdResult;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 2D 필터 적용
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src     - 원본 데이터        
        /// <br/> 
        /// <br/> 반 환 값 : 필터 적용 결과
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="src">       [in] 원본 데이터    </param>        
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public double[] ApplyGauusian2D(double[] src, int nSrcWidth, int nSrcHeight)
        {
            double[] arrdResult = null;

            if (m_dKernel2D != null)
            {
                arrdResult = new double[nSrcHeight * nSrcWidth];

                int kernelSize = m_dKernel2D.GetLength(0);
                int half = kernelSize / 2;

                for (int srcy = half; srcy < nSrcHeight - half; srcy++)
                {
                    for (int srcx = half; srcx < nSrcWidth - half; srcx++)
                    {
                        double sum = 0.0;

                        for (int ky = -half; ky <= half; ky++)
                        {
                            for (int kx = -half; kx <= half; kx++)
                            {
                                double weight = m_dKernel2D[ky + half, kx + half];

                                sum += (src[srcy * nSrcWidth + srcx] * weight);
                            }
                        }

                        arrdResult[srcy * nSrcWidth + srcx] = sum;
                    }
                }
            }

            return arrdResult;

        }



        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 2D 필터 적용 - RGB 이미지
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src     - 원본 데이터        
        /// <br/> 
        /// <br/> 반 환 값 : 필터 적용 결과
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="src">       [in] 원본 데이터    </param>        
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public byte[] ApplyGauusian2D_RGB(byte[] src, int nSrcWidth, int nSrcHeight)
        {
            byte[] arrdResult = null;

            if (m_dKernel2D != null)
            {
                arrdResult = new byte[src.Length];

                int kernelSize = m_dKernel2D.GetLength(0);
                int half = kernelSize / 2;

                // 필터 적용
                for (int srcy = half; srcy < nSrcHeight - half; srcy++)
                {
                    for (int srcx = half; srcx < nSrcWidth - half; srcx++)
                    {
                        double[] dSrcRGB = new double[3]
                            {
                                Convert.ToDouble(src[(srcy * nSrcWidth * 3) + (srcx * 3) + 0]), // r
                                Convert.ToDouble(src[(srcy * nSrcWidth * 3) + (srcx * 3) + 1]), // g
                                Convert.ToDouble(src[(srcy * nSrcWidth * 3) + (srcx * 3) + 2])  // b
                            };

                        int[] nSumRGB = new int[3] { 0, 0, 0 };

                        for (int ky = -half; ky <= half; ky++)
                        {
                            for (int kx = -half; kx <= half; kx++)
                            {
                                double weight = m_dKernel2D[ky + half, kx + half];

                                nSumRGB[0] += Convert.ToInt32(dSrcRGB[0] * weight); // r
                                nSumRGB[1] += Convert.ToInt32(dSrcRGB[1] * weight); // g
                                nSumRGB[2] += Convert.ToInt32(dSrcRGB[2] * weight); // b
                            }
                        }

                        // byte 범위 체크
                        int nr = OzMathEx.Clamp(nSumRGB[0], 0, 255);    // r
                        int ng = OzMathEx.Clamp(nSumRGB[1], 0, 255);    // g
                        int nb = OzMathEx.Clamp(nSumRGB[2], 0, 255);    // b

                        // 결과 저장
                        arrdResult[(srcy * nSrcWidth * 3) + (srcx * 3) + 0] = Convert.ToByte(nr);   // r
                        arrdResult[(srcy * nSrcWidth * 3) + (srcx * 3) + 1] = Convert.ToByte(ng);   // g
                        arrdResult[(srcy * nSrcWidth * 3) + (srcx * 3) + 2] = Convert.ToByte(nb);   // b
                    }
                }
            }

            return arrdResult;

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 가우시안 2D 필터 적용 - RGBA 이미지
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src     - 원본 데이터        
        /// <br/> 
        /// <br/> 반 환 값 : 필터 적용 결과
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="src">       [in] 원본 데이터    </param>        
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public byte[] ApplyGauusian2D_RGBA(byte[] src, int nSrcWidth, int nSrcHeight)
        {
            byte[] arrdResult = null;

            if (m_dKernel2D != null)
            {
                arrdResult = new byte[src.Length];

                int kernelSize = m_dKernel2D.GetLength(0);
                int half = kernelSize / 2;

                // 필터 적용
                for (int srcy = half; srcy < nSrcHeight - half; srcy++)
                {
                    for (int srcx = half; srcx < nSrcWidth - half; srcx++)
                    {
                        double[] dSrcRGB = new double[4]
                            {
                                Convert.ToDouble(src[(srcy * nSrcWidth * 4) + (srcx * 4) + 0]), // r
                                Convert.ToDouble(src[(srcy * nSrcWidth * 4) + (srcx * 4) + 1]), // g
                                Convert.ToDouble(src[(srcy * nSrcWidth * 4) + (srcx * 4) + 2]), // b
                                Convert.ToDouble(src[(srcy * nSrcWidth * 4) + (srcx * 4) + 3])  // a
                            };

                        int[] nSumRGB = new int[4] { 0, 0, 0, 0 };

                        for (int ky = -half; ky <= half; ky++)
                        {
                            for (int kx = -half; kx <= half; kx++)
                            {
                                double weight = m_dKernel2D[ky + half, kx + half];

                                nSumRGB[0] += Convert.ToInt32(dSrcRGB[0] * weight); // r
                                nSumRGB[1] += Convert.ToInt32(dSrcRGB[1] * weight); // g
                                nSumRGB[2] += Convert.ToInt32(dSrcRGB[2] * weight); // b
                                nSumRGB[3] += Convert.ToInt32(dSrcRGB[3] * weight); // a
                            }
                        }

                        // byte 범위 체크
                        int nr = OzMathEx.Clamp(nSumRGB[0], 0, 255);    // r
                        int ng = OzMathEx.Clamp(nSumRGB[1], 0, 255);    // g
                        int nb = OzMathEx.Clamp(nSumRGB[2], 0, 255);    // b
                        int na = OzMathEx.Clamp(nSumRGB[3], 0, 255);    // a

                        // 결과 저장
                        arrdResult[(srcy * nSrcWidth * 4) + (srcx * 4) + 0] = Convert.ToByte(nr);   // r
                        arrdResult[(srcy * nSrcWidth * 4) + (srcx * 4) + 1] = Convert.ToByte(ng);   // g
                        arrdResult[(srcy * nSrcWidth * 4) + (srcx * 4) + 2] = Convert.ToByte(nb);   // b
                        arrdResult[(srcy * nSrcWidth * 4) + (srcx * 4) + 3] = Convert.ToByte(na);   // a
                    }
                }
            }

            return arrdResult;

        }



    }
}
