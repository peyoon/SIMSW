﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace OzMethodEx
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> 자료형 확장 클래스 - 템플릿
    /// <br/> using OzMethodEx 선언으로 사용
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 07월 28일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	    
    public static class MethodEx_Template
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 전체 배열의 일부 부분을 추출
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] arr     - 원본 배열
        /// <br/>       [in] startidx  - 추출 시작 인덱스
        /// <br/>       [in] length    - 추출 사이즈
        /// <br/> 
        /// <br/> 반 환 값 : 추출된 배열 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <typeparam name="T"></typeparam>
        /// <param name="array">    [in] 원본 배열          </param>
        /// <param name="startidx"> [in] 추출 시작 인덱스  </param>
        /// <param name="length">   [in] 추출 길이     </param>
        /// <returns></returns>        
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static T[] ozSubArray<T>(this T[] array, int startidx, int length)
        {
            T[] result = new T[length];

            Array.Copy(array, startidx, result, 0, length);

            return result;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 배열 추가 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src  - 대상 값 (src)
        /// <br/>       [in] add  - 추가할 배열
        /// <br/> 
        /// <br/> 반 환 값 : 합쳐진 배열 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>    
        /// <param name="src">  [in] 대상 값 (src)  </param>
        /// <param name="add">  [in] 추가할 배열  </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static T[] ozAddArray<T>(this T src, T[] add)
        {
            T[] result = new T[1 + add.Length];

            result[0] = src;
            Array.Copy(add, 0, result, 1, add.Length);

            return result;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 배열 추가 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src  - 대상 값 (src)
        /// <br/>       [in] add  - 추가할 배열
        /// <br/> 
        /// <br/> 반 환 값 : 합쳐진 배열 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>    
        /// <param name="src">  [in] 대상 값 (src)  </param>
        /// <param name="add">  [in] 추가할 배열  </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static T[] ozAddArray<T>(this T[] src, T[] add)
        {
            T[] result = new T[src.Length + add.Length];

            Array.Copy(src, result, src.Length);
            Array.Copy(add, 0, result, src.Length, add.Length);

            return result;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 배열 추가 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src  - 대상 값 (src)
        /// <br/>       [in] add  - 추가할 배열
        /// <br/> 
        /// <br/> 반 환 값 : 합쳐진 배열 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>    
        /// <param name="src">  [in] 대상 값 (src)  </param>
        /// <param name="add">  [in] 추가할 배열  </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static T[] ozAddArray<T>(this T[] src, T add)
        {
            T[] result = new T[src.Length + 1];

            Array.Copy(src, result, src.Length);
            result[result.Length - 1] = add;            

            return result;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 배열 추가 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src        - 대상 값 (src)
        /// <br/>       [in] listAdd    - 추가할 배열 리스트
        /// <br/>       [in] startidx   - src에서 추가할 위치 (default : -1 == 이면 src 뒤에서 이어붙인다.)
        /// <br/> 
        /// <br/> 반 환 값 : 합쳐진 배열 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>    
        /// <param name="src">  [in] 대상 값 (src)  </param>
        /// <param name="listAdd">  [in] 추가할 배열 리스트  </param>
        /// <param name="startidx">  [in] src에서 추가할 위치 (default : -1 == 이면 src 뒤에서 이어붙인다.)  </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static T[] ozAddArray<T>(this T[] src, List<T[]> listAdd, int startidx = -1)
        {
            int idxCur = 0;         // 복사할 현재 위치
            int nTotalSize = 0;     // 전체 합친 사이즈

            // startidx == -1 이면 src 뒤에 추가
            if (startidx <= -1)
            {
                idxCur = src.Length;
                nTotalSize = src.Length;
            }
            else
            {
                idxCur = startidx;
                nTotalSize = src.Length - startidx;
            }

            // 결과 사이즈 계산
            foreach (T[] arr in listAdd)
            {
                nTotalSize += arr.Length;
            }
            
            // 배열 합치기
            T[] result = new T[nTotalSize];
            Array.Copy(src, result, src.Length);            

            for (int arrcnt = 0; arrcnt < listAdd.Count; arrcnt++)
            {
                Array.Copy(listAdd[arrcnt], 0, result, idxCur, listAdd[arrcnt].Length);

                idxCur += listAdd[arrcnt].Length;
            }

            return result;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 입력 값 범위 체크        
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] value  - 비교값
        /// <br/>       [in] min    - 최소값
        /// <br/>       [in] max    - 최대값
        /// <br/> 
        /// <br/> 반 환 값 : 범위 체크 결과 값 반환
        /// <br/> min 보다 작으면 min 
        /// <br/> max 보다 크면 max
        /// <br/> 그 외는 value
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>  
        /// <typeparam name="T"></typeparam>
        /// <param name="value">    [in] 비교값   </param>
        /// <param name="min">      [in] 최소값   </param>
        /// <param name="max">      [in] 최대값   </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static T ozClamp<T>(this T value, T min, T max) where T : IComparable<T>
        {
            T result;

            if (value.CompareTo(min) < 0)
                result = min;
            else if (value.CompareTo(max) > 0)
                result = max;
            else
                result = value;

            return result;
        }

    }
}
