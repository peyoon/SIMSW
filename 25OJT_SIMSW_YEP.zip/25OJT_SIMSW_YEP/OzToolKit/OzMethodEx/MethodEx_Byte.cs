﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace OzMethodEx
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> 자료형 확장 메소드 클래스 - byte, byte[]
    /// <br/> using OzMethodEx 선언으로 사용
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 07월 28일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public static class MethodEx_Byte
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> BYTE 배열을 hex 형식으로 반환 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src        - 대상 값
        /// <br/>       [in] bMarker    - Hex 표기(0x) 유무 (default : false)        
        /// <br/>       [in] concat     - 연결자   (default : "")         
        /// <br/> 
        /// <br/> 반 환 값 : hex형식 문자열
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>        
        /// <param name="src">       [in] 대상 값  </param>
        /// <param name="bMarker">      [in] Hex 표기(0x) 유무 (default : false)           </param>
        /// <param name="concat">       [in] 연결자   (default : "")         </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static string ozToHexString(this byte[] src, bool bMarker = false, string concat = "")
        {
            StringBuilder sb = new StringBuilder();

            // "0x"접두 표기 유무
            if (bMarker == true)
            {
                sb.Append("0x");
                concat = "";
            }

            foreach (var b in src)
            {
                sb.Append($"{b.ToString("X2")}{concat}");
            }

            return sb.ToString();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> BYTE 배열을 bit string으로 변환
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src        - 대상 값
        /// <br/>       [in] bMarker    - 이진 표기(0b) 유무 (default : false)                
        /// <br/> 
        /// <br/> 반 환 값 : bit 형식 문자열
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>          
        /// <param name="src">      [in] src        - 대상 값      </param>
        /// <param name="bMarker">  [in] bMarker    - 이진 표기(0b) 유무 (default : false)  </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static string ozToBitString(this byte[] src, bool bMarker = false)
        {
            StringBuilder sb = new StringBuilder();

            // "0b"접두 표기 유무
            if (bMarker == true)
            {
                sb.Append("0b");
            }

            foreach (var item in src)
            {
                sb.Append(Convert.ToString(item, 2).PadLeft(8, '0'));
            }

            return sb.ToString();
        }

    }
}
