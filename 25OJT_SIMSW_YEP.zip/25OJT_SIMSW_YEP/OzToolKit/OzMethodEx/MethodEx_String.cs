﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace OzMethodEx
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> 자료형 확장 클래스 - string
    /// <br/> using OzMethodEx 선언으로 사용
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 07월 28일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public static class MethodEx_String
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 문자열의 전시시 사이즈값 얻기
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] src            - 대상 값 (src)
        /// <br/>       [in] currentDpi     - DPI 정보
        /// <br/>       [in] typefacename   - 폰트 이름
        /// <br/>       [in] fontsize       - 폰트 사이즈
        /// <br/> 
        /// <br/> 반 환 값 : 문자열 DP 사이즈(Size) 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>   
        /// <param name="src">          [in] 대상 값 (src)    </param>
        /// <param name="currentDpi">   [in] DPI 정보        </param>
        /// <param name="typefacename"> [in] 폰트 이름         </param>
        /// <param name="fontsize">     [in] 폰트 사이즈        </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static System.Windows.Size ozGetDpTextSize(this string src, DpiScale currentDpi, 
                                                            string typefacename, double fontsize)
        {

            var rendertxt = new FormattedText(src,
                CultureInfo.InvariantCulture
                , FlowDirection.LeftToRight
                , new Typeface(typefacename)
                , fontsize * (currentDpi.PixelsPerInchX / 72)
                , System.Windows.Media.Brushes.Black
                , currentDpi.PixelsPerInchX
                );

            System.Windows.Size txtszie = new System.Windows.Size(rendertxt.Width, rendertxt.Height);

            return txtszie;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 파일 확장자 지우기
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] filename       - 파일명 (src)        
        /// <br/> 
        /// <br/> 반 환 값 : 확장자 제거된 문자열 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>           
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static string ozRemoveExt(this string filename)
        {
            int indexof = filename.LastIndexOf(".");

            string purefilename = filename.Substring(0, indexof);
            
            return purefilename;
        }


    }
}
