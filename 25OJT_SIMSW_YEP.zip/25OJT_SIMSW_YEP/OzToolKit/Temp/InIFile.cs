﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Temp
{

    /// <summary>
    /// InI 파일 클래스 관리
    /// <para/>작 성 자 : 강현우
    /// <br/>작 성 일 : 2025년 06월 27일
    /// </summary>
    public class InIBase
    {
        
        /// <summary>
        /// InI 파일 Section 별 Key  | Value 구조 
        /// </summary> 
        public class InICommand
        {
            public string Key { get; set; }

            public string Value { get; set; }

            public void ValueToInICommand(string key, string value)
            {
                if (string.IsNullOrEmpty(value))
                {

                }
                else
                {
                    this.Key = key;
                    this.Value = value;
                }
            }
        }

        
        /// <summary>
        /// InI 파일 읽은 후 Section 별 Key  | Value 구조 
        /// </summary>
        private Dictionary<string, Dictionary<string, string>> m_iniData = new Dictionary<string, Dictionary<string, string>>();
       
        /// <summary>
        /// ini 파일 경로 생성자 파라미터 추가 
        /// </summary>
        private string m_iniFilePath;


        /// <summary>
        /// ini 파일 경로 파일 존재 우뮤 체크
        /// </summary>
        public bool m_IsInIFileExists;

        /// <summary>
        /// InI 파일 생성자
        /// <para/>파라미터 :
        /// <br/> [in] string - ini파일 경로
        /// <br/>[in] bool - ini 없으면 생성 유무
        /// <br/>[in] StringBuilder  - ini 생성시 생성 content
        /// </summary>
        /// <param name="path"></param>
        /// <param name="Create">존재하지 않을때 강제 생성 유무</param>
        /// <param name="sb">강제생성시 사용할 기본값</param>
        public InIBase(string path,bool Create=false,StringBuilder sb=null)
        {
            this.m_iniFilePath = path;

            if (File.Exists(m_iniFilePath))
            {
                m_IsInIFileExists= true;
                
            }
            else
            {
                m_IsInIFileExists = false;
            }

            if (false == m_IsInIFileExists)
            {
                if (Create)
                {
                    if (sb != null)
                    {
                        using (StreamWriter sw = new StreamWriter(m_iniFilePath))
                        {
                            sw.WriteLine(string.Empty);
                        }
                    }
                    else
                    {
                        using (StreamWriter sw = new StreamWriter(m_iniFilePath))
                        {
                            sw.WriteLine(sb.ToString());
                        }
                    }
                }
            }
        }


        /// <summary>
        /// InI 파일 경로 업데이트 
        /// <para/>파라미터 :
        /// <br/> [in] string - ini파일 경로
        /// </summary>
        /// <param name="path">값이 null 이거나 empty 인 경우 false </param>
        /// <returns>업데이트 성공시 true | 실패시 false</returns>
        public bool UpdateInIFilePath(string path)
        {
            bool result = false;

            if (string.IsNullOrEmpty(m_iniFilePath))
            {
                result = false;
            }
            else
            {
                result = true;
            }

            return result;

        }

        /// <summary>
        /// InI 파일 읽기 
        /// <para/>파라미터 :
        /// <br/> [in] string - ini파일 경로
        /// </summary>
        /// <param name="iniFilePath">ini 파일경로 </param>
        /// <returns>결과값 성공 true |  실패 false </returns>
        private bool ReadInI(string iniFilePath)
        {
            bool resultflag = false;
            try
            {
                var inifiledata = File.ReadAllLines(iniFilePath);
                var section = string.Empty;
                foreach (var item in inifiledata)
                {
                    string trimmdata = item.Trim();

                    if (string.IsNullOrEmpty(trimmdata) || trimmdata.StartsWith(";"))
                    {
                        continue;
                    }

                    if (trimmdata.StartsWith("[") && trimmdata.EndsWith("]"))
                    {
                        section = trimmdata.Trim('[', ']');
                        if (m_iniData.ContainsKey(section))
                        {

                        }
                        else
                        {
                            m_iniData.Add(section, new Dictionary<string, string>());
                        }
                    }
                    else if (section != null)
                    {
                        string[] parts = trimmdata.Split(new char[] { '=' }, 2);
                        if (parts.Length == 2)
                        {
                            string key = parts[0].Trim();
                            string value = parts[1].Trim();
                            m_iniData[section][key] = value;
                        }
                    }
                }
                resultflag = true;
            }
            catch
            {
                resultflag = false;
            }
            return resultflag;  
        }

        /// <summary>
        /// InI 파일 쓰기 성공시 GetSecion 으로 체크 가능<para/>파라미터 :
        /// <br/> [in] string - ini파일 경로
        /// </summary>
        /// <param name="iniFilePath">ini 파일경로 </param>
        /// <returns>결과값 성공 true |  실패 false </returns>
        private bool WriteInI(string iniFilePath)
        {
            bool resultflag = false;
            try
            {
                using (StreamWriter writer = new StreamWriter(iniFilePath, false))
                {
                    foreach (var section in m_iniData)
                    {
                        writer.WriteLine($"[{section.Key}]");
                        foreach (var key_value in section.Value)
                        {
                            writer.WriteLine($"{key_value.Key}={key_value.Value}");
                        }
                    }
                }
                resultflag = true;
            }
            catch
            {
                resultflag = false;
            }
            return resultflag;

        }

        /// <summary>
        /// InI 파일 읽기 
        /// </summary>
        /// <returns>결과값 성공 true |  실패 false </returns>
        public bool ReadInI()
        {
            bool flag = false;
            if (m_IsInIFileExists)
            {
                flag= this.ReadInI(m_iniFilePath);
            }
            else
            {
                flag = false;
            }
            return flag;
        }

        /// <summary>
        /// InI 파일 저장<para/>파라미터 : <br/>[in] string - Section 이름
        /// <br/>[in] IList - Section 하위의 명령어 집합
        /// </summary>
        /// <param name="section"></param>
        /// <param name="commands"></param>
        /// <returns>결과값 성공 true |  실패</returns>
        public bool InICommandSave(string section, IList<InICommand> commands)
        {
            bool issucess = false;

            try
            {
                if (m_iniData.ContainsKey(section))
                {
                    m_iniData[section].Clear();
                    foreach (var item in commands)
                    {
                        m_iniData[section].Add(item.Key, item.Value);
                    }
                    WriteInI(m_iniFilePath);
                    issucess = true;
                    ReadInI(m_iniFilePath);
                }
                else
                {
                    issucess = false;
                }
            }
            catch (Exception ex)
            {
                issucess = false;
            }

            return issucess;
        }



        /// <summary>
        /// 읽은 INI 파일에서 특정 Section 값 을 가져오기
        /// <para/>파라미터 : 
        /// <br/>[in] string - Section 이름
        /// <br/>[in] bool   - 설정한 경로에서 재읽기 유무
        /// </summary>
        /// <param name="section">ini 파일 Section 이름</param>
        /// <param name="reload">설정한 경로에서 재읽기 유무</param>
        /// <returns>Section 의 CommandList </returns>
        public IList<InICommand> GetSection(string section, bool reload = false)
        {
            var commands = new List<InICommand>();

            if (m_iniData.ContainsKey(section))
            {
                if (reload)
                {
                    WriteInI(m_iniFilePath);
                }

                var values = m_iniData[section];
                foreach (var item in values)
                {
                    InICommand command = new InICommand();
                    command.ValueToInICommand(item.Key, item.Value);
                    commands.Add(command);
                }
            }
            else
            {
                m_iniData.Add($"{section}", new Dictionary<string, string>());
                WriteInI(m_iniFilePath);
            }
            return commands;
        }


        /// <summary>
        /// 읽은 INI 파일에서 특정 Section 의 KEY 값 가져오기
        /// <para/>파라미터 : 
        /// <br/>[in] string - Section 이름
        /// <br/>[in] bool   - Section 의 키 값
        /// </summary>
        /// <param name="section">Section명</param>
        /// <param name="key">Section 의 키 값</param>
        /// <returns>Section 의 해당 키에 대한 command</returns>
        public InICommand GetMessage(string section, string key)
        {
            InICommand command = new InICommand();

            if (m_iniData.ContainsKey(section))
            {
                var values = m_iniData[section];
                var key_value = values.Where(i => i.Key == key).FirstOrDefault();

            }
            return command;
        }
    }

}
