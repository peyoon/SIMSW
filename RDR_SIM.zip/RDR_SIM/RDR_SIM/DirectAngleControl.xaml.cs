﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Globalization; 

namespace RDR_SIM
{
    public partial class DirectAngleControl : Window
    {
        // 조향각 정보 갱신 이벤트
        public delegate void Handler_ApplyAngle();
        public event Handler_ApplyAngle Event_ApplyAngle;
        

        public DirectAngleControl()
        {
            InitializeComponent();

            this.IsVisibleChanged += IsVisibleChanged_Window;
        }

        private void Closing_Window(object sender, CancelEventArgs e) 
        {
            e.Cancel = true; 
            this.Hide();
        }

        private void Loaded_Window(object sender, RoutedEventArgs e) 
        { 

        }

        private void IsVisibleChanged_Window(object sender, DependencyPropertyChangedEventArgs e)
        {
            uiTexBox_AzimuthMil.Text       = RDR_SIMData.m_tAntennaAngle.nAzimuthMil.ToString("F0");       // 방위각 [mil]
            uiTexBox_ElevationMil.Text     = RDR_SIMData.m_tAntennaAngle.nElevationMil.ToString("F0");     // 고각 [mil]

            LostFocus_TexBox_AzimuthMil(null, null);
            LostFocus_TexBox_ElevationMil(null, null);
        }


        private void Click_RadioButton_AutoMode(object sender, RoutedEventArgs e)
        {
            uiGroupBox_Angle.IsEnabled = false;
        }

        private void Click_RadioButton_ManualMode(object sender, RoutedEventArgs e)
        {
            uiGroupBox_Angle.IsEnabled = true;
        }


        private void Click_RadioButton_Unit_Degree(object sender, RoutedEventArgs e)
        {
            uiTexBox_AzimuthDegree.IsEnabled = true;
            uiTexBox_ElevationDegree.IsEnabled = true;

            // MIL 선택 컨트롤 비활성화            
            uiTexBox_AzimuthMil.IsEnabled = false;
            uiTexBox_ElevationMil.IsEnabled = false;
        }

        private void Click_RadioButton_Unit_Mil(object sender, RoutedEventArgs e)
        {
            uiTexBox_AzimuthDegree.IsEnabled = false;
            uiTexBox_ElevationDegree.IsEnabled = false;
            uiTexBox_AzimuthMil.IsEnabled = true;
            uiTexBox_ElevationMil.IsEnabled = true;
        }

        private void LostFocus_TexBox_AzimuthDegree(object sender, RoutedEventArgs e)
        {
            double dDeg;
            if (double.TryParse(uiTexBox_AzimuthDegree.Text, out dDeg))
            {
                uiTexBox_AzimuthMil.Text = Scope.ScopeConst.DEG2MIL(dDeg).ToString("F0");
            }
            
        }

        private void LostFocus_TexBox_ElevationDegree(object sender, RoutedEventArgs e)
        {
            double dDeg;
            if (double.TryParse(uiTexBox_AzimuthDegree.Text, out dDeg))
            {
                uiTexBox_ElevationMil.Text = Scope.ScopeConst.DEG2MIL(dDeg).ToString("F0");
            }
        }

        private void LostFocus_TexBox_AzimuthMil(object sender, RoutedEventArgs e)
        {
            int nMil;
            if (int.TryParse(uiTexBox_AzimuthMil.Text, out nMil))
            {
                uiTexBox_AzimuthDegree.Text = Scope.ScopeConst.MIL2DEG(nMil).ToString("F2");
            }
        }

        private void LostFocus_TexBox_ElevationMil(object sender, RoutedEventArgs e)
        {
            int nMil;
            if (int.TryParse(uiTexBox_ElevationMil.Text, out nMil))
            {
                uiTexBox_ElevationDegree.Text = Scope.ScopeConst.MIL2DEG(nMil).ToString("F2");
            }
        }


        private void Click_Button_Apply(object sender, RoutedEventArgs e) 
        {
            RDR_SIMData.m_tAntennaAngle.nAzimuthMil         = Convert.ToInt32(uiTexBox_AzimuthMil.Text);        // 방위각 [mil]
            RDR_SIMData.m_tAntennaAngle.nElevationMil       = Convert.ToInt32(uiTexBox_ElevationMil.Text);      // 고각 [mil]

            Event_ApplyAngle?.Invoke();
            
        }

        private void Click_Button_Close(object sender, RoutedEventArgs e) 
        {
            this.Hide(); 
        }

    }
}