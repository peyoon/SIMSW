﻿using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;

namespace RDR_SIM
{
    public partial class ConnectControl : Window
    {
        public delegate void RequestConnectHandler();
        public event RequestConnectHandler OnRequestConnect;

        // UI를 코드로 업데이트할 때 TextChanged 이벤트가 무한으로 발생하는 것을 막기 위한 변수
        private bool m_bIsUpdatingUI = false;

        public ConnectControl()
        {
            InitializeComponent();
            // 창이 화면에 보이거나 숨겨질 때마다 UI를 업데이트하는 이벤트 핸들러 추가
            this.IsVisibleChanged += ConnectControl_IsVisibleChanged;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 창이 화면에 보일 때마다 호출되어 UI 컨트롤의 값들을 중앙 데이터에 맞게 업데이트.
        /// 파라미터 : [in] sender - 이벤트를 발생시킨 객체
        ///            [in] e     - 이벤트 데이터
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 09월 25일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ConnectControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.IsVisible)
            {
                m_bIsUpdatingUI = true;

                // 중앙 데이터(RDR_SIMData)에서 값을 읽어와 UI 컨트롤에 수동채움
                txtIP.Text = RDR_SIMData.m_tConnectData.IP;
                txtPort.Text = RDR_SIMData.m_tConnectData.Port.ToString();
                txtID.Text = RDR_SIMData.m_tConnectData.ID;
                PwBox.Password = RDR_SIMData.m_tConnectData.Password;

                // UI 업데이트가 끝났다는 플래그를 해제
                m_bIsUpdatingUI = false;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// TextBox의 텍스트가 변경될 때마다 호출되어 중앙 데이터를 업데이트
        /// 파라미터 : [in] sender - 이벤트를 발생시킨 객체
        ///            [in] e     - 이벤트 데이터
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 09월 25일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void txt_TextChanged(object sender, TextChangedEventArgs e)
        {
            // UI를 코드로 업데이트하는 동안에는 이 로직을 실행하지 않습니다.
            if (m_bIsUpdatingUI) return;

            // UI 컨트롤의 값을 읽어와 중앙 데이터(RDR_SIMData)에 수동으로 저장합니다.
            RDR_SIMData.m_tConnectData.IP = txtIP.Text;
            int.TryParse(txtPort.Text, out RDR_SIMData.m_tConnectData.Port);
            RDR_SIMData.m_tConnectData.ID = txtID.Text;
        }

        private void PwBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (m_bIsUpdatingUI) return;
            RDR_SIMData.m_tConnectData.Password = PwBox.Password;
        }

        private void Closing_Window(object sender, CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void Click_Button_Connect(object sender, RoutedEventArgs e)
        {
            OnRequestConnect?.Invoke();
            this.Hide();
        }

        private void Click_Button_Close(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
        }
    }
}