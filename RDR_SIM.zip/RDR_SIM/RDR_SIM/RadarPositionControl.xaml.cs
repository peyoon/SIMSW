﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Text.RegularExpressions;

namespace RDR_SIM
{
    public partial class RadarPositionControl : Window
    {
        public delegate void ApplyPositionHandler();
        public event ApplyPositionHandler OnApplyPosition;
        private bool m_bIsUpdatingUI = false;

        public RadarPositionControl()
        {
            InitializeComponent();
            this.IsVisibleChanged += RadarPositionControl_IsVisibleChanged;
        }

        private void Closing_Window(object sender, CancelEventArgs e)
        {
            e.Cancel = true; this.Hide();
        }

        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
        }

        private void RadarPositionControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.IsVisible)
            {
                uiDataGrid_Location.ItemsSource = RDR_SIMData.m_LocationList;
                uiDataGrid_Location.Items.Refresh();
                UpdateAllUIFromData();
                UpdateInputReadOnlyState();

            }
        }
        private void UpdateInputReadOnlyState()
        {
            bool isDmsChecked = uiRadioButton_Unit_DMS.IsChecked == true;

            uiTextBox_LonD.IsReadOnly = !isDmsChecked;
            txtLonM.IsReadOnly = !isDmsChecked;
            txtLonS.IsReadOnly = !isDmsChecked;
            txtLonMs.IsReadOnly = !isDmsChecked;
            txtLatD.IsReadOnly = !isDmsChecked;
            txtLatM.IsReadOnly = !isDmsChecked;
            txtLatS.IsReadOnly = !isDmsChecked;
            txtLatMs.IsReadOnly = !isDmsChecked;

            txtLonDecimal.IsReadOnly = isDmsChecked;
            txtLatDecimal.IsReadOnly = isDmsChecked;
        }
        private void Click_RadioButton_Unit(object sender, RoutedEventArgs e)
        {
            UpdateInputReadOnlyState();
        }

        private void UpdateAllUIFromData()
        {
            m_bIsUpdatingUI = true;
            UpdateDMS_UI();
            UpdateDegree_UI();
            txtAltitude.Text = RDR_SIMData.m_tRadarPosition.Altitude.ToString("F1");
            m_bIsUpdatingUI = false;
        }

        private void UpdateDMS_UI()
        {
            uiTextBox_LonD.Text = RDR_SIMData.m_tRadarPosition.LonD.ToString();
            txtLonM.Text = RDR_SIMData.m_tRadarPosition.LonM.ToString();
            txtLonS.Text = RDR_SIMData.m_tRadarPosition.LonS.ToString();
            txtLonMs.Text = RDR_SIMData.m_tRadarPosition.LonMs.ToString();
            txtLatD.Text = RDR_SIMData.m_tRadarPosition.LatD.ToString();
            txtLatM.Text = RDR_SIMData.m_tRadarPosition.LatM.ToString();
            txtLatS.Text = RDR_SIMData.m_tRadarPosition.LatS.ToString();
            txtLatMs.Text = RDR_SIMData.m_tRadarPosition.LatMs.ToString();
        }

        private void UpdateDegree_UI()
        {
            txtLonDecimal.Text = RDR_SIMData.m_tRadarPosition.LonDecimal.ToString("F7");
            txtLatDecimal.Text = RDR_SIMData.m_tRadarPosition.LatDecimal.ToString("F7");

            txtDegree_TextChanged(null, null);
        }

        private void TextChanged_TexBox_txtDMS(object sender, TextChangedEventArgs e)
        {
            if (m_bIsUpdatingUI == true) 
                return;

            int.TryParse(uiTextBox_LonD.Text, out RDR_SIMData.m_tRadarPosition.LonD);
            int.TryParse(txtLonM.Text, out RDR_SIMData.m_tRadarPosition.LonM);
            int.TryParse(txtLonS.Text, out RDR_SIMData.m_tRadarPosition.LonS);
            int.TryParse(txtLonMs.Text, out RDR_SIMData.m_tRadarPosition.LonMs);
            int.TryParse(txtLatD.Text, out RDR_SIMData.m_tRadarPosition.LatD);
            int.TryParse(txtLatM.Text, out RDR_SIMData.m_tRadarPosition.LatM);
            int.TryParse(txtLatS.Text, out RDR_SIMData.m_tRadarPosition.LatS);
            int.TryParse(txtLatMs.Text, out RDR_SIMData.m_tRadarPosition.LatMs);

            double dLon = 0, dLat = 0;
            Scope.ScopeConst.DMS2DEG(RDR_SIMData.m_tRadarPosition.LonD, RDR_SIMData.m_tRadarPosition.LonM, RDR_SIMData.m_tRadarPosition.LonS, RDR_SIMData.m_tRadarPosition.LonMs, ref dLon);
            Scope.ScopeConst.DMS2DEG(RDR_SIMData.m_tRadarPosition.LatD, RDR_SIMData.m_tRadarPosition.LatM, RDR_SIMData.m_tRadarPosition.LatS, RDR_SIMData.m_tRadarPosition.LatMs, ref dLat);
            RDR_SIMData.m_tRadarPosition.LonDecimal = dLon;
            RDR_SIMData.m_tRadarPosition.LatDecimal = dLat;

            m_bIsUpdatingUI = true;
            UpdateDegree_UI();
            m_bIsUpdatingUI = false;
        }

        private void txtDegree_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (m_bIsUpdatingUI == true)
                return;

            double.TryParse(txtLonDecimal.Text, out RDR_SIMData.m_tRadarPosition.LonDecimal);
            double.TryParse(txtLatDecimal.Text, out RDR_SIMData.m_tRadarPosition.LatDecimal);

            Scope.ScopeConst.DEG2DMS(RDR_SIMData.m_tRadarPosition.LonDecimal, ref RDR_SIMData.m_tRadarPosition.LonD, ref RDR_SIMData.m_tRadarPosition.LonM, ref RDR_SIMData.m_tRadarPosition.LonS, ref RDR_SIMData.m_tRadarPosition.LonMs);
            Scope.ScopeConst.DEG2DMS(RDR_SIMData.m_tRadarPosition.LatDecimal, ref RDR_SIMData.m_tRadarPosition.LatD, ref RDR_SIMData.m_tRadarPosition.LatM, ref RDR_SIMData.m_tRadarPosition.LatS, ref RDR_SIMData.m_tRadarPosition.LatMs);

            m_bIsUpdatingUI = true;
            UpdateDMS_UI();
            m_bIsUpdatingUI = false;
        }
        private void uiDataGrid_Location_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedItem = uiDataGrid_Location.SelectedItem as LocationData;

            if (selectedItem == null) 
                return;

            // 선택된 항목의 문자열 값을 숫자(double)로 변환
            double.TryParse(selectedItem.Longitude, out double dLon);
            double.TryParse(selectedItem.Latitude, out double dLat);
            double.TryParse(selectedItem.Altitude, out double dAlt);
            double.TryParse(selectedItem.Azimuth, out double dAz);

            // 변환된 값을 중앙 데이터(RDR_SIMData)에 저장
            RDR_SIMData.m_tRadarPosition.LonDecimal = dLon;
            RDR_SIMData.m_tRadarPosition.LatDecimal = dLat;
            RDR_SIMData.m_tRadarPosition.Altitude = dAlt;
            RDR_SIMData.m_tRadarPosition.Azimuth = dAz;

            // 변경된 Degree 값을 바탕으로 DMS 값을 다시 계산
            Scope.ScopeConst.DEG2DMS(RDR_SIMData.m_tRadarPosition.LonDecimal, ref RDR_SIMData.m_tRadarPosition.LonD, ref RDR_SIMData.m_tRadarPosition.LonM, ref RDR_SIMData.m_tRadarPosition.LonS, ref RDR_SIMData.m_tRadarPosition.LonMs);
            Scope.ScopeConst.DEG2DMS(RDR_SIMData.m_tRadarPosition.LatDecimal, ref RDR_SIMData.m_tRadarPosition.LatD, ref RDR_SIMData.m_tRadarPosition.LatM, ref RDR_SIMData.m_tRadarPosition.LatS, ref RDR_SIMData.m_tRadarPosition.LatMs);

            // 변경된 중앙 데이터를 바탕으로 수동 입력 UI 전체를 새로고침
            UpdateAllUIFromData();
        }
        private void txtAltitude_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (m_bIsUpdatingUI == true) 
                return;

            double.TryParse(txtAltitude.Text, out RDR_SIMData.m_tRadarPosition.Altitude);
        }

        private void txtDMS_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void LostFocus_TextBox_DMS(object sender, RoutedEventArgs e)
        {
            int.TryParse(uiTextBox_LonD.Text, out RDR_SIMData.m_tRadarPosition.LonD);
            int.TryParse(txtLonM.Text, out RDR_SIMData.m_tRadarPosition.LonM);
            int.TryParse(txtLonS.Text, out RDR_SIMData.m_tRadarPosition.LonS);
            int.TryParse(txtLonMs.Text, out RDR_SIMData.m_tRadarPosition.LonMs);
            int.TryParse(txtLatD.Text, out RDR_SIMData.m_tRadarPosition.LatD);
            int.TryParse(txtLatM.Text, out RDR_SIMData.m_tRadarPosition.LatM);
            int.TryParse(txtLatS.Text, out RDR_SIMData.m_tRadarPosition.LatS);
            int.TryParse(txtLatMs.Text, out RDR_SIMData.m_tRadarPosition.LatMs);

            double dLon = 0, dLat = 0;
            Scope.ScopeConst.DMS2DEG(RDR_SIMData.m_tRadarPosition.LonD, RDR_SIMData.m_tRadarPosition.LonM, RDR_SIMData.m_tRadarPosition.LonS, RDR_SIMData.m_tRadarPosition.LonMs, ref dLon);
            Scope.ScopeConst.DMS2DEG(RDR_SIMData.m_tRadarPosition.LatD, RDR_SIMData.m_tRadarPosition.LatM, RDR_SIMData.m_tRadarPosition.LatS, RDR_SIMData.m_tRadarPosition.LatMs, ref dLat);
            RDR_SIMData.m_tRadarPosition.LonDecimal = dLon;
            RDR_SIMData.m_tRadarPosition.LatDecimal = dLat;

            UpdateDegree_UI();            
        }


        private void Click_Button_Apply(object sender, RoutedEventArgs e)
        {
            OnApplyPosition?.Invoke(); 
        }

        private void Click_Button_Close(object sender, RoutedEventArgs e) 
        {
            this.Hide(); 
        }

        
    }
}