﻿using System;
using System.Windows;
using System.Windows.Threading;
using System.ComponentModel;
using System.Windows.Media;

namespace RDR_SIM
{
    public partial class MainWindow : Window
    {
        private ConnectControl m_connectWindow = new ConnectControl();
        private RadarPositionControl m_radarPositionWindow = new RadarPositionControl();
        private DirectAngleControl m_directAngleWindow = new DirectAngleControl();
        private DispatcherTimer m_timer;

        public MainWindow()
        {
            InitializeComponent();
            RDR_SIMData.Init();
            IniManager.LoadSettings();
            IniManager.LoadLocations();

            m_connectWindow.OnRequestConnect += ReqConnectSrv;
            m_radarPositionWindow.OnApplyPosition += ApplyRadarPosition;
            m_directAngleWindow.Event_ApplyAngle += ApplyDirectAngle;

            InitScope();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 중앙 데이터(RDR_SIMData)의 현재 값들을 읽어와 UI 컨트롤에 수동으로 표시
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 09월 25일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void UpdateDisplayFromData()
        {
            // 레이다 위치 정보 UI 업데이트
            txtLongitude.Text = RDR_SIMData.m_tRadarPosition.LonDecimal.ToString("F7");
            txtLatitude.Text = RDR_SIMData.m_tRadarPosition.LatDecimal.ToString("F7");
            txtAltitude.Text = RDR_SIMData.m_tRadarPosition.Altitude.ToString("F1");
            txtRadarAzimuth.Text = RDR_SIMData.m_tRadarPosition.Azimuth.ToString("F2");

            // 안테나 조향각 정보 UI 업데이트
            txtAntennaAzimuth.Text = RDR_SIMData.m_tAntennaAngle.nAzimuthMil.ToString("F0");
            txtAntennaElevation.Text = RDR_SIMData.m_tAntennaAngle.nElevationMil.ToString("F0");
        }

        private void ReqConnectSrv()
        {
            string sIP = RDR_SIMData.m_tConnectData.IP;
            int nPort = RDR_SIMData.m_tConnectData.Port;
            string sID = RDR_SIMData.m_tConnectData.ID;
            MessageBox.Show($"접속을 시도합니다:\nIP: {sIP}\nPORT: {nPort}\nID: {sID}");

            IniManager.SaveSettings();

            RDR_SIMData.m_operationStatus = E_OperationStatus.Operating;

            UpdateStatusDisplay();
        }

        private void ApplyRadarPosition()
        {
            UpdateScope();
            IniManager.SaveSettings();
            UpdateDisplayFromData(); 
        }

        private void ApplyDirectAngle()
        {            
            //IniManager.SaveSettings();
            
            UpdateDisplayFromData();

            // scope 갱신
            UpdateScope();
        }

        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
            m_timer = new DispatcherTimer();
            m_timer.Interval = TimeSpan.FromSeconds(1);
            m_timer.Tick += Timer_Tick;
            m_timer.Start();

            UpdateDisplayFromData(); // 창이 뜰 때 INI에서 불러온 값들을 UI에 표시
            UpdateRadioButtonsFromData();
            UpdateStatusDisplay();
            UpdateScope();
        }

        private void Closing_Window(object sender, CancelEventArgs e)
        {
            if (MessageBox.Show("프로그램을 종료할까요?", "종료 확인", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
            {
                IniManager.SaveSettings();
                IniManager.SaveLocations();
                Environment.Exit(0);
            }
            else
            {
                e.Cancel = true;
            }
        }
        private void UpdateRadioButtonsFromData()
        {
            // PPI 라디오 버튼 상태 업데이트
            switch (RDR_SIMData.m_ppiAngGap)
            {
                case Scope.E_ScopeAngGap._200:
                    uiRadioButton_ppi200mil.IsChecked = true;
                    break;
                case Scope.E_ScopeAngGap._400:
                    uiRadioButton_ppi400mil.IsChecked = true;
                    break;
                case Scope.E_ScopeAngGap._800:
                    uiRadioButton_ppi800mil.IsChecked = true;
                    break;
                case Scope.E_ScopeAngGap.OFF:
                    uiRadioButton_ppiOFF.IsChecked = true;
                    break;
            }

            // RHI 라디오 버튼 상태 업데이트
            switch (RDR_SIMData.m_rhiDistGap)
            {
                case Scope.E_ScopeDistGap._200:
                    uiRadioButton_rhi200m.IsChecked = true;
                    break;
                case Scope.E_ScopeDistGap._500:
                    uiRadioButton_rhi500m.IsChecked = true;
                    break;
                case Scope.E_ScopeDistGap._1000:
                    uiRadioButton_rhi1000m.IsChecked = true;
                    break;
                case Scope.E_ScopeDistGap.OFF:
                    uiRadioButton_rhiOFF.IsChecked = true;
                    break;
            }
            switch (RDR_SIMData.m_zoomLevel)
            {
                case E_ZoomLevel.X3: rbZoom3x.IsChecked = true; break;
                case E_ZoomLevel.X11: rbZoom11x.IsChecked = true; break;
                case E_ZoomLevel.X40: rbZoom40x.IsChecked = true; break;
            }
        }
        private void Click_ZoomLevel_Changed(object sender, RoutedEventArgs e)
        {
            if (rbZoom3x.IsChecked == true)
                RDR_SIMData.m_zoomLevel = E_ZoomLevel.X3;
            else if (rbZoom11x.IsChecked == true)
                RDR_SIMData.m_zoomLevel = E_ZoomLevel.X11;
            else if (rbZoom40x.IsChecked == true)
                RDR_SIMData.m_zoomLevel = E_ZoomLevel.X40;

            UpdateScope(); // 스코프 화면을 다시 그리도록 명령
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// PPI 각도 설정 라디오 버튼 클릭 시 호출됩니다.
        /// 중앙 데이터를 업데이트하고 스코프 화면을 새로고침합니다.
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_RhiDistGap_Changed(object sender, RoutedEventArgs e)
        {
            if (uiRadioButton_rhi200m.IsChecked == true)
                RDR_SIMData.m_rhiDistGap = Scope.E_ScopeDistGap._200;
            else if (uiRadioButton_rhi500m.IsChecked == true)
                RDR_SIMData.m_rhiDistGap = Scope.E_ScopeDistGap._500;
            else if (uiRadioButton_rhi1000m.IsChecked == true)
                RDR_SIMData.m_rhiDistGap = Scope.E_ScopeDistGap._1000;
            else if (uiRadioButton_rhiOFF.IsChecked == true)
                RDR_SIMData.m_rhiDistGap = Scope.E_ScopeDistGap.OFF;

            UpdateScope();
        }
        private void Click_PpiAngGap_Changed(object sender, RoutedEventArgs e)
        {
            if (uiRadioButton_ppi200mil.IsChecked == true)
                RDR_SIMData.m_ppiAngGap = Scope.E_ScopeAngGap._200;
            else if (uiRadioButton_ppi400mil.IsChecked == true)
                RDR_SIMData.m_ppiAngGap = Scope.E_ScopeAngGap._400;
            else if (uiRadioButton_ppi800mil.IsChecked == true)
                RDR_SIMData.m_ppiAngGap = Scope.E_ScopeAngGap._800;
            else if (uiRadioButton_ppiOFF.IsChecked == true)
                RDR_SIMData.m_ppiAngGap = Scope.E_ScopeAngGap.OFF;

            UpdateScope(); 
        }

        private void UpdateStatusDisplay()
        {
            switch (RDR_SIMData.m_operationStatus)
            {
                case E_OperationStatus.Terminated: // 운용 종료
                    uiLabel_OperationStatus.Content = "운용 종료";
                    uiLabel_OperationStatus.Background = Brushes.Gray;
                    uiButton_SavePosition.IsEnabled = false;
                    uiButton_RadarPosition.IsEnabled = false;
                    uiButtonAngleInput.IsEnabled = false;
                    break;

                case E_OperationStatus.Operating: // 운용 중
                    uiLabel_OperationStatus.Content = "운용 중";
                    uiLabel_OperationStatus.Background = Brushes.Green;
                    uiButton_SavePosition.IsEnabled = true;
                    uiButton_RadarPosition.IsEnabled = true;
                    uiButtonAngleInput.IsEnabled = true;
                    break;

                case E_OperationStatus.Standby: // 운용 대기
                    uiLabel_OperationStatus.Content = "운용 대기";
                    uiLabel_OperationStatus.Background = Brushes.Cyan;
                    uiButton_SavePosition.IsEnabled = false;
                    uiButton_RadarPosition.IsEnabled = false;
                    uiButtonAngleInput.IsEnabled = false;
                    break;
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            uiButton_CurrentTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private void Click_Button_ConnectControl(object sender, RoutedEventArgs e) { m_connectWindow.Show(); }

        private void Click_Button_RadarPosition(object sender, RoutedEventArgs e) 
        {
            m_radarPositionWindow.Show(); 
        }

        private void Click_Button_DirectAngle(object sender, RoutedEventArgs e) { m_directAngleWindow.Show(); }

        private void Click_Button_SavePosition(object sender, RoutedEventArgs e)
        {
            if (RDR_SIMData.m_LocationList.Count >= 5)
            {
                RDR_SIMData.m_LocationList.RemoveAt(RDR_SIMData.m_LocationList.Count - 1);
            }
            var newLocation = new LocationData
            {
                Longitude = RDR_SIMData.m_tRadarPosition.LonDecimal.ToString("F7"),
                Latitude = RDR_SIMData.m_tRadarPosition.LatDecimal.ToString("F7"),
                Altitude = RDR_SIMData.m_tRadarPosition.Altitude.ToString("F1"),
                Azimuth = RDR_SIMData.m_tRadarPosition.Azimuth.ToString("F1")
            };
            RDR_SIMData.m_LocationList.Insert(0, newLocation);
            for (int i = 0; i < RDR_SIMData.m_LocationList.Count; i++)
            {
                RDR_SIMData.m_LocationList[i].SeqNum = i + 1;
            }
            IniManager.SaveLocations();
        }
    }
}