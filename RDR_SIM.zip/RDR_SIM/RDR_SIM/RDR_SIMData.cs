﻿using Scope;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace RDR_SIM
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 연동 설정 정보 담는 구조체
    /// 파라미터 : -
    /// 반 환 값 : -
    /// 작 성 자 : 윤은평
    /// 작 성 일 : 2025년 09월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public struct T_ConnectData { public string IP; public int Port; public string ID; public string Password; }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 레이다 위치 정보를 담는 구조체 (수동 입력 및 상태 표시용)
    /// 작 성 자 : 윤은평
    /// 작 성 일 : 2025-09-26
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public struct T_RadarPosition { public int LonD, LonM, LonS, LonMs; public int LatD, LatM, LatS, LatMs; public double LonDecimal, LatDecimal, Altitude, Azimuth; }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 안테나 조향각 정보를 담는 구조체
    /// 작 성 자 : 윤은평
    /// 작 성 일 : 2025-09-26
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public struct T_AntennaAngle 
    {
        public int      nAzimuthMil;        // 방위각 [mil]
        public int      nElevationMil;      // 고각 [mil]
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 스코프 줌 배율 상태 정의
    /// 작 성 자 : 윤은평
    /// 작 성 일 : 2025-09-26
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public enum E_ZoomLevel { X3, X11, X40 }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 레이다 운용 상태 정의
    /// 작 성 자 : 윤은평
    /// 작 성 일 : 2025-09-26
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public enum E_OperationStatus { Terminated, Operating, Standby }


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// DataGrid에 표시될 저장된 위치 정보 항목을 정의하는 클래스
    /// 작 성 자 : 윤은평
    /// 작 성 일 : 2025-09-26
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class LocationData : INotifyPropertyChanged
    {
        private int m_nSeqNum;
        private string m_sLongitude;
        private string m_sLatitude;
        private string m_sAltitude;
        private string m_sAzimuth;

        public int SeqNum
        {
            get => m_nSeqNum;
            set { m_nSeqNum = value; OnPropertyChanged(); }
        }
        public string Longitude
        {
            get => m_sLongitude;
            set { m_sLongitude = value; OnPropertyChanged(); }
        }
        public string Latitude
        {
            get => m_sLatitude;
            set { m_sLatitude = value; OnPropertyChanged(); }
        }
        public string Altitude
        {
            get => m_sAltitude;
            set { m_sAltitude = value; OnPropertyChanged(); }
        }
        public string Azimuth
        {
            get => m_sAzimuth;
            set { m_sAzimuth = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }


    public static class RDR_SIMData
    {
        public static T_ConnectData m_tConnectData;
        public static T_RadarPosition m_tRadarPosition;
        public static T_AntennaAngle m_tAntennaAngle;
        public static E_ScopeAngGap m_ppiAngGap;
        public static E_ScopeDistGap m_rhiDistGap;
        public static E_ZoomLevel m_zoomLevel;
        public static E_OperationStatus m_operationStatus;


        public static ObservableCollection<LocationData> m_LocationList = new ObservableCollection<LocationData>();

        public static void Init()
        {
            m_tConnectData = new T_ConnectData ();
            m_tRadarPosition = new T_RadarPosition();
            m_tAntennaAngle = new T_AntennaAngle();
            m_ppiAngGap = E_ScopeAngGap._800;
            m_rhiDistGap = E_ScopeDistGap._1000;
            m_zoomLevel = E_ZoomLevel.X11;
            m_operationStatus = E_OperationStatus.Terminated;

        }
    }
}