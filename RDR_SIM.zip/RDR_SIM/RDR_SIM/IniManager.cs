﻿using System.Text;

namespace RDR_SIM
{
    public static class IniManager
    {
        private static readonly string m_filePath = "./RDR_SIM.ini";

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// INI 파일에서 일반 설정값을 읽어와 static RDR_SIMData 클래스에 직접 채움.
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 09월 25일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void LoadSettings()
        {
            StringBuilder sbBuffer = new StringBuilder(256);

            // --- [CONNECT] 섹션 ---
            OzWin32.Win32DLL.GetPrivateProfileString("CONNECT", "IP", "127.0.0.1", sbBuffer, 256, m_filePath);
            RDR_SIMData.m_tConnectData.IP = sbBuffer.ToString();

            OzWin32.Win32DLL.GetPrivateProfileString("CONNECT", "PORT", "9112", sbBuffer, 256, m_filePath);
            int.TryParse(sbBuffer.ToString(), out RDR_SIMData.m_tConnectData.Port);

            OzWin32.Win32DLL.GetPrivateProfileString("CONNECT", "ID", "", sbBuffer, 256, m_filePath);
            RDR_SIMData.m_tConnectData.ID = sbBuffer.ToString();

            OzWin32.Win32DLL.GetPrivateProfileString("CONNECT", "Password", "", sbBuffer, 256, m_filePath);
            RDR_SIMData.m_tConnectData.Password = sbBuffer.ToString();

            // --- [STATE] 섹션 (마지막 작업 상태 값) ---
            OzWin32.Win32DLL.GetPrivateProfileString("STATE", "RadarAzimuth", "0.0", sbBuffer, 256, m_filePath);
            double.TryParse(sbBuffer.ToString(), out RDR_SIMData.m_tRadarPosition.Azimuth);

            //OzWin32.Win32DLL.GetPrivateProfileString("STATE", "Elevation", "0.0", sbBuffer, 256, m_filePath);
            //double.TryParse(sbBuffer.ToString(), out RDR_SIMData.m_tAntennaAngle.dElevationDegree);

            OzWin32.Win32DLL.GetPrivateProfileString("STATE", "Longitude", "0.0", sbBuffer, 256, m_filePath);
            double.TryParse(sbBuffer.ToString(), out RDR_SIMData.m_tRadarPosition.LonDecimal);

            OzWin32.Win32DLL.GetPrivateProfileString("STATE", "Latitude", "0.0", sbBuffer, 256, m_filePath);
            double.TryParse(sbBuffer.ToString(), out RDR_SIMData.m_tRadarPosition.LatDecimal);

            OzWin32.Win32DLL.GetPrivateProfileString("STATE", "Altitude", "0.0", sbBuffer, 256, m_filePath);
            double.TryParse(sbBuffer.ToString(), out RDR_SIMData.m_tRadarPosition.Altitude);

            //OzWin32.Win32DLL.GetPrivateProfileString("STATE", "Azimuth", "0.0", sbBuffer, 256, m_filePath);
            //double.TryParse(sbBuffer.ToString(), out RDR_SIMData.m_tAntennaAngle.dAzimuthDegree);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// static RDR_SIMData 클래스의 현재 값들을 INI 파일에 저장.
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 09월 25일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void SaveSettings()
        {
            // --- [CONNECT] 섹션 ---
            OzWin32.Win32DLL.WritePrivateProfileString("CONNECT", "IP", RDR_SIMData.m_tConnectData.IP, m_filePath);
            OzWin32.Win32DLL.WritePrivateProfileString("CONNECT", "PORT", RDR_SIMData.m_tConnectData.Port.ToString(), m_filePath);
            OzWin32.Win32DLL.WritePrivateProfileString("CONNECT", "ID", RDR_SIMData.m_tConnectData.ID, m_filePath);
            OzWin32.Win32DLL.WritePrivateProfileString("CONNECT", "Password", RDR_SIMData.m_tConnectData.Password, m_filePath);

            // --- [STATE] 섹션 (현재 상태 값) ---
            OzWin32.Win32DLL.WritePrivateProfileString("STATE", "RadarAzimuth", RDR_SIMData.m_tRadarPosition.Azimuth.ToString("F2"), m_filePath);
            //OzWin32.Win32DLL.WritePrivateProfileString("STATE", "Elevation", RDR_SIMData.m_tAntennaAngle.dElevationDegree.ToString("F2"), m_filePath);
            //OzWin32.Win32DLL.WritePrivateProfileString("STATE", "Azimuth", RDR_SIMData.m_tAntennaAngle.dAzimuthDegree.ToString("F2"), m_filePath);
            OzWin32.Win32DLL.WritePrivateProfileString("STATE", "Longitude", RDR_SIMData.m_tRadarPosition.LonDecimal.ToString("F7"), m_filePath);
            OzWin32.Win32DLL.WritePrivateProfileString("STATE", "Latitude", RDR_SIMData.m_tRadarPosition.LatDecimal.ToString("F7"), m_filePath);
            OzWin32.Win32DLL.WritePrivateProfileString("STATE", "Altitude", RDR_SIMData.m_tRadarPosition.Altitude.ToString("F1"), m_filePath);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 프로그램 시작 시 호출. INI 파일에서 저장된 위치 목록을 불러옴.
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 09월 25일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void LoadLocations()
        {
            StringBuilder sbBuffer = new StringBuilder(256);
            RDR_SIMData.m_LocationList.Clear();

            OzWin32.Win32DLL.GetPrivateProfileString("LOCATION_INFO", "Count", "0", sbBuffer, 256, m_filePath);
            int.TryParse(sbBuffer.ToString(), out int nCount);

            for (int i = 1; i <= nCount; i++)
            {
                string sSection = $"LOCATION_{i}";
                var locationData = new LocationData { SeqNum = i };

                OzWin32.Win32DLL.GetPrivateProfileString(sSection, "Longitude", "", sbBuffer, 256, m_filePath);
                locationData.Longitude = sbBuffer.ToString();

                OzWin32.Win32DLL.GetPrivateProfileString(sSection, "Latitude", "", sbBuffer, 256, m_filePath);
                locationData.Latitude = sbBuffer.ToString();

                OzWin32.Win32DLL.GetPrivateProfileString(sSection, "Altitude", "", sbBuffer, 256, m_filePath);
                locationData.Altitude = sbBuffer.ToString();

                OzWin32.Win32DLL.GetPrivateProfileString(sSection, "Azimuth", "", sbBuffer, 256, m_filePath);
                locationData.Azimuth = sbBuffer.ToString();

                RDR_SIMData.m_LocationList.Add(locationData);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// '위치 저장' 버튼 클릭 또는 프로그램 종료 시 호출. 현재 위치 목록을 INI 파일에 저장.
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 09월 25일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void SaveLocations()
        {
            var locationList = RDR_SIMData.m_LocationList;

            OzWin32.Win32DLL.WritePrivateProfileString("LOCATION_INFO", "Count", locationList.Count.ToString(), m_filePath);

            for (int i = 0; i < locationList.Count; i++)
            {
                string sSection = $"LOCATION_{i + 1}";
                var locationData = locationList[i];

                OzWin32.Win32DLL.WritePrivateProfileString(sSection, "Longitude", locationData.Longitude, m_filePath);
                OzWin32.Win32DLL.WritePrivateProfileString(sSection, "Latitude", locationData.Latitude, m_filePath);
                OzWin32.Win32DLL.WritePrivateProfileString(sSection, "Altitude", locationData.Altitude, m_filePath);
                OzWin32.Win32DLL.WritePrivateProfileString(sSection, "Azimuth", locationData.Azimuth, m_filePath);
            }
        }
    }
}