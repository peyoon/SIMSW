﻿using OpenTK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace RDR_SIM
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 메인 윈도우 클래스 - Scope 관리
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public partial class MainWindow : Window
    {
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// GL PPI Scope        
        /// 
        private GLControl   m_ctrlGL_PPIScope;      // PPI Scope GL 컨트롤
        private GLControl   m_ctrlGL_RHIScope;      // RHI Scope GL 컨트롤

        private Scope.CPPIScope m_cPPIScope;     // PPI Scope 랜더링 클래스
        private Scope.CRHIScope m_cRHIScope;     // RHI Scope 랜더링 클래스
                
        //private LogComm     m_cLogComm;              // 로그 관리 및 출력


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Scope 초기화
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitScope()
        {
            // 컨트롤 생성
            m_ctrlGL_PPIScope = new GLControl();
            m_ctrlGL_RHIScope = new GLControl();

            // 랜더링 클래스 생성
            m_cPPIScope = new Scope.CPPIScope();
            m_cRHIScope = new Scope.CRHIScope();

            // 로그 관리 클래스 생성
            //m_cLogComm = new LogComm();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// Scope 갱신
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void UpdateScope()
        {
            m_ctrlGL_PPIScope.Refresh();
            m_ctrlGL_RHIScope.Refresh();
        }



        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        #region PPI Scope 창

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// PPI Scope 컨트롤 로드 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Loaded_GL_PPIScope(object sender, RoutedEventArgs e)
        {
            //컨트롤 로드시 호출될 이벤트 핸들러 추가
            m_ctrlGL_PPIScope.Load += new EventHandler(InitializeGLPPIScope);
            //페인트 이벤트 핸들러 추가
            m_ctrlGL_PPIScope.Paint += new System.Windows.Forms.PaintEventHandler(RenderGLPPIScope);

            // key up event
            m_ctrlGL_PPIScope.KeyUp += new System.Windows.Forms.KeyEventHandler(KeyUp_GLPPIScope);

            ////마우스 이벤트 핸들러 추가
            //m_GLMainControl.MouseMove += new System.Windows.Forms.MouseEventHandler(MouseMove_GLMainWindow);
            //m_GLMainControl.MouseDown += new System.Windows.Forms.MouseEventHandler(MouseDown_GLMainWindow);
            //m_GLMainControl.MouseUp += new System.Windows.Forms.MouseEventHandler(MouseUp_GLMainWindow);
            //m_GLMainControl.MouseWheel += new System.Windows.Forms.MouseEventHandler(MouseWheel_GLMainWindow);

            // 컨트롤 연결
            uiGL_PPIScope.Child = m_ctrlGL_PPIScope;

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// PPI Scope 컨트롤 초기화
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitializeGLPPIScope(object sender, EventArgs e)
        {

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// PPI Scope GL 랜더링
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void RenderGLPPIScope(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            m_ctrlGL_PPIScope.MakeCurrent();

            // Scope 설정
            m_cPPIScope.Setting(RDR_SIMData.m_ppiAngGap, Scope.E_ScopeDistGap._1000);
            //m_cPPIScope.Setting(Scope.E_ScopeAngGap._800, RDR_SIMData.m_rhiDistGap);

            switch (RDR_SIMData.m_zoomLevel)
            {
                case E_ZoomLevel.X3: m_cPPIScope.m_Camera.m_dZoomDist = 80000.0; break;
                case E_ZoomLevel.X11: m_cPPIScope.m_Camera.m_dZoomDist = 27000.0; break;
                case E_ZoomLevel.X40: m_cPPIScope.m_Camera.m_dZoomDist = 8000.0; break;
            }
            // Scope 랜더
            m_cPPIScope.Render(m_ctrlGL_PPIScope.Width, m_ctrlGL_PPIScope.Height, 200, 100, true);

            // 로그 랜더
            //m_cLogComm.RenderLog(m_ctrlGL_PPIScope.Width, m_ctrlGL_PPIScope.Height);

            //스왑버퍼
            m_ctrlGL_PPIScope.SwapBuffers();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// PPI Scope Key Up 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void KeyUp_GLPPIScope(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            // P 키 : 로그 Show/Hide
            //if (e.KeyCode == System.Windows.Forms.Keys.P)
            //{
            //    m_cLogComm.ShowLog = !m_cLogComm.ShowLog;
            //}

            //// O 키 : 로그 Pause
            //if (e.KeyCode == System.Windows.Forms.Keys.O)
            //{
            //    m_cLogComm.PauseLog = !m_cLogComm.PauseLog;
            //}

        }

        #endregion PPI Scope 창
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        #region RHI Scope 창

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// RHI Scope 컨트롤 로드 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Loaded_GL_RHIScope(object sender, RoutedEventArgs e)
        {
            //컨트롤 로드시 호출될 이벤트 핸들러 추가
            m_ctrlGL_RHIScope.Load += new EventHandler(InitializeGLRHIScope);
            //페인트 이벤트 핸들러 추가
            m_ctrlGL_RHIScope.Paint += new System.Windows.Forms.PaintEventHandler(RenderGLRHIScope);

            ////마우스 이벤트 핸들러 추가
            //m_GLMainControl.MouseMove += new System.Windows.Forms.MouseEventHandler(MouseMove_GLMainWindow);
            //m_GLMainControl.MouseDown += new System.Windows.Forms.MouseEventHandler(MouseDown_GLMainWindow);
            //m_GLMainControl.MouseUp += new System.Windows.Forms.MouseEventHandler(MouseUp_GLMainWindow);
            //m_GLMainControl.MouseWheel += new System.Windows.Forms.MouseEventHandler(MouseWheel_GLMainWindow);

            // 컨트롤 연결
            uiGL_RHIScope.Child = m_ctrlGL_RHIScope;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// RHI Scope 컨트롤 초기화
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitializeGLRHIScope(object sender, EventArgs e)
        {


        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// RHI Scope GL 랜더링
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void RenderGLRHIScope(object sender, System.Windows.Forms.PaintEventArgs e)
        {
            m_ctrlGL_RHIScope.MakeCurrent();

            // Scope 설정
            //m_cRHIScope.Setting(Scope.E_ScopeAngGap._800, RDR_SIMData.m_rhiDistGap);
            m_cRHIScope.Setting(Scope.E_ScopeAngGap._800, RDR_SIMData.m_rhiDistGap);

            switch (RDR_SIMData.m_zoomLevel)
            {
                case E_ZoomLevel.X3: m_cRHIScope.m_Camera.m_dZoomDist = 80000.0; break;
                case E_ZoomLevel.X11: m_cRHIScope.m_Camera.m_dZoomDist = 27000.0; break;
                case E_ZoomLevel.X40: m_cRHIScope.m_Camera.m_dZoomDist = 8000.0; break;
            }
            // Scope 랜더
            m_cRHIScope.Render(m_ctrlGL_PPIScope.Width, m_ctrlGL_PPIScope.Height, 100, true);

            //스왑버퍼
            m_ctrlGL_RHIScope.SwapBuffers();
        }

        #endregion RHI Scope 창
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    }
}
