﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using SharpFont;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace GLFont
{
    public enum AlignmentHorizontal
    {
        Left,
        Center,
        Right        
    }

    public enum AlignmentVertical
    {
        Top,
        Middle,
        Bottom
    }

    public struct Character
    {
        public int TextureID { get; set; }
        public Vector2 Size { get; set; }
        public Vector2 Bearing { get; set; }
        public int Advance { get; set; }
        public float Width { get; set; }
        public float Height { get; set; }
        public float StartX { get; set; }
        public float StartY { get; set; }
    }
        
    class FontFreeType : IDisposable
    {
        private const double DEG2RAD = 1.7453292519943295769236907684886e-2;

        private Face m_Face;        
        private Rect m_rectText = new Rect();  // Text 영역        
        private List<Character> m_listTextChars = new List<Character>();

        public float Scale { get; set; }
        public float RotateAngle { get; set; }

        public AlignmentHorizontal AlignHorizontal { get; set; }
        public AlignmentVertical AlignVertical { get; set; }

        public bool ShowTextBox { get; set; }

        #region 폰트생성

        public FontFreeType(string strFontpath, uint fontsize)
        {
            createFont(strFontpath, fontsize);
        }

        ~FontFreeType()
        {
            Dispose();
        }
        public void Dispose()
        {
            m_Face.Dispose();
        }
        public void Render(float x, float y, string text)
        {
            m_listTextChars.Clear();
            m_rectText = new Rect(0.0, 0.0, 0.0, 0.0);

            createCharacters(text);

            renderCharacters(x, y);
        }

        private void createFont(string strFontpath, uint fontsize)
        {
            Scale = 1.0f;
            AlignHorizontal = AlignmentHorizontal.Left;
            AlignVertical = AlignmentVertical.Bottom;
            ShowTextBox = false;

            // initialize library
            Library lib = new Library();
            //Face face = new Face(lib, strFontpath);
            m_Face = new Face(lib, strFontpath);

            m_Face.SetPixelSizes(0, fontsize);
        }

        #endregion
        
        private void createCharacters(string text)
        {
            float char_x = 0.0f;
            int nTxtNum = text.Length;
            
            // set 1 byte pixel alignment 
            GL.PixelStore(PixelStoreParameter.UnpackAlignment, 1);

            for (int ntxtCnt = 0; ntxtCnt < nTxtNum; ntxtCnt++)
            {
                m_Face.LoadChar(text[ntxtCnt], LoadFlags.Render, LoadTarget.Normal);
                GlyphSlot glyph = m_Face.Glyph;
                FTBitmap bitmap = glyph.Bitmap;

                // create glyph texture
                int texObj = GL.GenTexture();
                GL.BindTexture(TextureTarget.Texture2D, texObj);
                GL.TexImage2D(TextureTarget.Texture2D, 0,
                              PixelInternalFormat.Alpha, bitmap.Width, bitmap.Rows, 0,
                              PixelFormat.Alpha, PixelType.UnsignedByte, bitmap.Buffer);

                // set texture parameters
                GL.TextureParameter(texObj, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
                GL.TextureParameter(texObj, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
                GL.TextureParameter(texObj, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToEdge);
                GL.TextureParameter(texObj, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToEdge);

                // add character
                Character ch = new Character();
                ch.TextureID = texObj;
                ch.Size = new Vector2(bitmap.Width, bitmap.Rows);
                ch.Bearing = new Vector2(glyph.BitmapLeft, glyph.BitmapTop);
                ch.Advance = (int)glyph.Advance.X.Value;

                ch.Width = ch.Size.X * Scale;
                ch.Height = ch.Size.Y * Scale;
                ch.StartX = char_x + ch.Bearing.X * Scale;
                //float yrel = (ch.Size.Y - ch.Bearing.Y) * scale;
                ch.StartY = (ch.Bearing.Y - ch.Size.Y) * Scale;

                // Now advance cursors for next glyph (note that advance is number of 1/64 pixels)
                char_x += (ch.Advance >> 6) * Scale; // Bitshift by 6 to get value in pixels (2^6 = 64 (divide amount of 1/64th pixels by 64 to get amount of pixels))

                // text 전체 height
                if (m_rectText.Height < ch.Height)
                    m_rectText.Height = ch.Height;
                // text 시작 Y
                if (m_rectText.Y > ch.StartY)
                    m_rectText.Y = ch.StartY;

                m_listTextChars.Add(ch);
            }
            // text 전체 width
            m_rectText.Width += char_x;

            // set default (4 byte) pixel alignment 
            GL.PixelStore(PixelStoreParameter.UnpackAlignment, 4);
        }

        private void renderCharacters(float x, float y)
        {
            float angle_rad = (float)(RotateAngle * DEG2RAD);

            Matrix4 rotateM = Matrix4.CreateRotationZ(angle_rad);
            Matrix4 transOriginM = Matrix4.CreateTranslation(new Vector3(x, y, 0f));

            float fAlignX = 0.0f, fAlignY = 0.0f;

            switch (AlignHorizontal)
            {
                default:
                case AlignmentHorizontal.Left:
                    fAlignX = - (float)m_rectText.X;
                    break;
                case AlignmentHorizontal.Center:
                    fAlignX = - (float)(m_rectText.X + m_rectText.Width / 2.0);
                    break;
                case AlignmentHorizontal.Right:
                    fAlignX = - (float)(m_rectText.X + (float)m_rectText.Width);
                    break;
            }

            switch (AlignVertical)
            {
                default:
                case AlignmentVertical.Top:
                    fAlignY = - (float)(m_rectText.Y + m_rectText.Height);
                    break;
                case AlignmentVertical.Middle:
                    fAlignY = - (float)(m_rectText.Y + m_rectText.Height / 2.0);
                    break;
                case AlignmentVertical.Bottom:
                    fAlignY = - (float)m_rectText.Y;
                    break;
            }

            Matrix4 alignM = Matrix4.CreateTranslation(new Vector3(fAlignX, fAlignY, 0f));

            GL.PushAttrib(AttribMask.EnableBit | AttribMask.ColorBufferBit);

            GL.Enable(EnableCap.Blend);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

            GL.Enable(EnableCap.Texture2D);

            foreach (var ch in m_listTextChars)
            {
                GL.PushMatrix();
                {
                    Matrix4 scaleM = Matrix4.CreateScale(new Vector3(ch.Width, ch.Height, 1.0f));
                    Matrix4 transRelM = Matrix4.CreateTranslation(new Vector3(ch.StartX, ch.StartY, 0.0f));
                    //Matrix4 modelM = scaleM * transRelM * rotateM * transOriginM; // OpenTK `*`-operator is reversed
                    Matrix4 modelM = scaleM * alignM * transRelM * rotateM * transOriginM; // OpenTK `*`-operator is reversed

                    GL.LoadMatrix(ref modelM);

                    // Render glyph texture over quad
                    GL.BindTexture(TextureTarget.Texture2D, ch.TextureID);

                    // Render quad                
                    GL.Begin(PrimitiveType.TriangleStrip);
                    {
                        GL.TexCoord2(0.0, 0.0);
                        GL.Vertex2(0.0, 1.0);

                        GL.TexCoord2(0.0, 1.0);
                        GL.Vertex2(0.0, 0.0);

                        GL.TexCoord2(1.0, 0.0);
                        GL.Vertex2(1.0, 1.0);

                        GL.TexCoord2(1.0, 1.0);
                        GL.Vertex2(1.0, 0.0);
                    }
                    GL.End();
                }
                GL.PopMatrix();

                GL.DeleteTexture(ch.TextureID);
            }

            //GL.Disable(EnableCap.Texture2D);
            //GL.Disable(EnableCap.Blend);

            GL.PopAttrib();

            // box
            if (ShowTextBox)
            {
                //GL.Disable(EnableCap.DepthTest);

                GL.PushMatrix();
                {
                    GL.Translate(x, y, 0.0);                    
                    GL.Rotate(-RotateAngle, 0.0, 0.0, -1.0);

                    GL.Translate(fAlignX, fAlignY, 0.0);
                    GL.Begin(PrimitiveType.LineLoop);
                    GL.Vertex2(0.0, 0.0);
                    GL.Vertex2(m_rectText.Width, 0.0);
                    GL.Vertex2(m_rectText.Width, m_rectText.Height);
                    GL.Vertex2(0.0, m_rectText.Height);
                    GL.End();
                }                
                GL.PopMatrix();
            }

        }


    }
}
