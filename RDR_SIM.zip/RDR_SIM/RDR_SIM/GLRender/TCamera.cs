﻿using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace Scope
{
    public class TCamera
    {
        // 회전축
        public Vector3d m_vAxisLook, m_vAxisUp, m_vAxisRight;
        //public Vector3d m_vAxisLook;
        //public Vector3d m_vAxisUp;
        //public Vector3d m_vAxisRight;

        // 카메라 벡터
        public Vector3d m_vLook,m_vUp, m_vRight, m_vLookAt;
        //public Vector3d m_vLook = new Vector3d();
        //public Vector3d m_vUp = new Vector3d();
        //public Vector3d m_vRight = new Vector3d();
        //public Vector3d m_vLookAt = new Vector3d();

        // 회전 - 자세
        public double m_dYaw, m_dPitch, m_dRoll;

        // 카메라 설정 값
        public double m_dFOV, m_dRatio, m_dNear, m_dFar;

        // 위치 좌표
        public Vector3d m_vPosOrigin, m_vPosCamera;
        //public Vector3d m_vPosOrigin = new Vector3d();
        //public Vector3d m_vPosCamera = new Vector3d();

        // 회전 정보
        public Quaterniond m_quatDatum;      // 회전 기준
        public Quaterniond m_quatAttitude;   // 자세 회전 quat. (yaw, pitch, roll)
        public Quaterniond m_quatCamera;     // 최종 camera 적용 회전

        // 화면 정보
        public int m_nWndWidth, m_nWndHeight;      // 화면 사이즈
        public double m_dViewPixelSize;            // 픽셀당 사이즈

        // 줌 정보
        public double m_dZoomDist;                 // 줌 거리
        public double m_dZoomDistGap;              // 줌 간격
        public double m_dZoomDistMax;              // 최대 줌아웃
        public double m_dZoomDistMin;				// 최소 줌인


        public TCamera()
        {
            m_vAxisLook = new Vector3d(0.0, 0.0, -1.0);
            m_vAxisUp = new Vector3d(0.0, 1.0, 0.0);
            m_vAxisRight = new Vector3d(1.0, 0.0, 0.0);

            m_vLook = new Vector3d(0.0, 0.0, -1.0);
            m_vUp = new Vector3d(0.0, 1.0, 0.0);
            m_vRight = new Vector3d(1.0, 0.0, 0.0);
            m_vLookAt = new Vector3d(0.0, 0.0, 0.0);

            m_vPosOrigin = new Vector3d(0.0, 0.0, 0.0);
            m_vPosCamera = new Vector3d(0.0, 0.0, 0.0);

            m_dYaw = 0.0;
            m_dPitch = 0.0;
            m_dRoll = 0.0;

            m_dFOV = 45.0;
            m_dRatio = 1.0;
            m_dNear = 1.0;
            m_dFar = 100000.0;

            m_quatDatum = new Quaterniond(0.0, 0.0, 0.0);      // 회전 기준
            m_quatAttitude = new Quaterniond(m_dPitch, m_dYaw, m_dRoll);   // 자세 회전 quat. (yaw, pitch, roll)
            m_quatCamera = new Quaterniond(0.0, 0.0, 0.0);     // 최종 camera 적용 회전

            m_nWndWidth = 0;
            m_nWndHeight = 0;
            m_dViewPixelSize = 1.0;

            m_dZoomDist = 0.0;
            m_dZoomDistGap = 10.0;
            m_dZoomDistMax = 1000.0;
            m_dZoomDistMin = 0.0;

            //m_bLbutton = false;
            //m_bRbutton = false;

            //m_nPrevMouseX = 0;
            //m_nPrevMouseY = 0;

            
        }

        public void SetRotateDatum(double yaw, double pitch, double roll)
        {
            m_quatDatum = Quaterniond.FromEulerAngles(pitch, yaw, roll);
        }

        public void SetRotateDatum(Quaterniond quatDatum)
        {
            m_quatDatum = quatDatum;
        }


        public void SetEuler(double yaw, double pitch, double roll)
        {
            m_dYaw = yaw;
            m_dPitch = pitch;
            m_dRoll = roll;
        }


        public void Update()
        {
            // FromEulerAngles 쓰지 말자. 회전축이 틀리다.
            // 개별 축 회전을 시킨 후 합성하여 사용하자.
            Quaterniond qYaw, qPitch, qRoll;
            //m_quatAttitude = Quaterniond.FromEulerAngles(m_dPitch, m_dYaw, m_dRoll);
            qYaw = Quaterniond.FromAxisAngle(m_vAxisUp, m_dYaw * ScopeConst.DEG2RAD);
            qPitch = Quaterniond.FromAxisAngle(m_vAxisRight, m_dPitch * ScopeConst.DEG2RAD);
            qRoll = Quaterniond.FromAxisAngle(m_vAxisLook, m_dRoll * ScopeConst.DEG2RAD);
            m_quatAttitude = qYaw * qPitch * qRoll;
            m_quatAttitude.Normalize();

            m_quatCamera = m_quatDatum * m_quatAttitude;
            m_quatCamera.Normalize();

            m_vLook = Vector3d.Transform(m_vAxisLook, m_quatCamera);
            m_vUp = Vector3d.Transform(m_vAxisUp, m_quatCamera);
            m_vRight = Vector3d.Transform(m_vAxisRight, m_quatCamera);

            //m_vLook = m_quatCamera.Rotate(m_vAxisLook); ;
            //m_vUp = m_quatCamera.Rotate(m_vAxisUp); ;
            //m_vRight = m_quatCamera.Rotate(m_vAxisRight); ;

            m_vPosCamera = m_vPosOrigin + (m_vLook * -m_dZoomDist);
            m_vLookAt = m_vPosCamera + (m_vLook * 10000.0);

            //m_dViewPixelSize = tan(m_dFOV / 2.0 * DEG2RAD) * m_vPosCamera.z / ((double)m_nWndHeight / 2.0);
        }

        public void Apply(int x, int y, int width, int height)
        {
            m_nWndWidth = width;
            m_nWndHeight = height;

            m_dRatio = (double)width / (double)height;
            m_dNear = m_vPosCamera.Z / 10.0;
            m_dFar = m_vPosCamera.Z + 1000.0;
                        
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();

            Matrix4d matPerspective;

            GL.Viewport(x, y, width, height);
            //gluPerspective(m_dFOV, m_dRatio, m_dNear, m_dFar);
            matPerspective = Matrix4d.Perspective(m_dFOV * ScopeConst.DEG2RAD, m_dRatio, m_dNear, m_dFar);
            GL.LoadMatrix(ref matPerspective);

            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();

            //gluLookAt(m_vPosCamera.x, m_vPosCamera.y, m_vPosCamera.z, m_vLookAt.x, m_vLookAt.y, m_vLookAt.z, m_vUp.x, m_vUp.y, m_vUp.z);
            Matrix4d matModelView;
            matModelView = Matrix4d.LookAt(m_vPosCamera, m_vLookAt, m_vUp);
            GL.LoadMatrix(ref matModelView);

            
        }

    }
}
