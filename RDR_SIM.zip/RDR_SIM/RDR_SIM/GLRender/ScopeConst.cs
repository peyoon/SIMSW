﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scope
{
    // scope 전시 각도 간격
    public enum E_ScopeAngGap
    {
        _200,   // 200 mil
        _400,   // 400 mil
        _800,   // 800 mil
        OFF     // OFF
    }

    // scope 전시 거리 간격
    public enum E_ScopeDistGap
    {
        _200,   // 200 m
        _500,   // 500 m
        _1000,  // 1000 m
        OFF     // OFF
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Scope 상수 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public class ScopeConst
    {
        public  const double	PI			= 3.14159265358979323846;       // 원주율
        public  const double    DEG2RAD     = 0.0174532925199432957692;     // Degree -> Radian



        #region 단위 변환 ( 좌표, 각도)

        public static void DEG2DMS(double dDeg, ref int nDeg, ref int nMin, ref int nSec, ref int nMSec)
        {
            (nDeg) = (int)dDeg;
            dDeg = dDeg - (nDeg);
            (nMin) = (int)(dDeg * 60.0);
            dDeg = (dDeg * 60.0) - (nMin);
            (nSec) = (int)(dDeg * 60.0);
            dDeg = (dDeg * 60.0) - (nSec);
            (nMSec) = (int)(dDeg * 1000.0);
        }

        public static void DMS2DEG(int nDeg, int nMin, int nSec, int nMSec, ref double dDeg)
        {
            (dDeg) = 0.0;
            (dDeg) += ((double)nDeg);
            (dDeg) += ((double)nMin / 60.0);
            (dDeg) += ((double)nSec / 3600.0);
            (dDeg) += ((double)nMSec / 3600.0 / 1000.0);
        }

        public static int DEG2MIL(double dDeg)
        {
            int mil = 0;

            mil = (int)(dDeg * 6400.0 / 360.0);

            return mil;
        }

        public static double MIL2DEG(int nMil)
        {
            double deg = 0.0;

            deg = (double)((double)nMil * 360.0 / 6400.0);

            return deg;
        }


        #endregion 단위 변환 ( 좌표, 각도)

    }
}
