﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ICD
{
    // ICD 상 Define 값
    public class ICD_Exam_Const
    {
        ///////////////////////////////////////////
        // 클라이언트 -> 서버
        public const uint MSG_CLIENT_10     = 1201;
        public const uint MSG_CLIENT_50     = 1202;
        public const uint MSG_CLIENT_100    = 1203;


        ///////////////////////////////////////////
        // 서버 -> 클라이언트 
        // 0x21xx 으로 시작.
        public const uint MSG_SERVER_10     = 2101;
        public const uint MSG_SERVER_50     = 2102;
        public const uint MSG_SERVER_100    = 2103;

    }

    // 패킷 헤더
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct T_Header
    {
        public uint msgID;          // msg id
        public uint dataSize;       // data size
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct T_Msg10Hz
    {
        public T_Header tHeader;
        public int data;
        [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.Struct, SizeConst = 10)]
        public int[] dummy;

        public T_Msg10Hz(bool bFlag)
        {
            tHeader = new T_Header();
            data = 0;
            dummy = new int[10];
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct T_Msg50Hz
    {
        public T_Header tHeader;
        public double data;
        [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.Struct, SizeConst = 10)]
        public double[] dummy;

        public T_Msg50Hz(bool bFlag)
        {
            tHeader = new T_Header();
            data = 0.0;
            dummy = new double[10];
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct T_Msg100Hz
    {
        public T_Header tHeader;
        public float data;
        [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.Struct, SizeConst = 10)]
        public float[] dummy;

        public T_Msg100Hz(bool bFlag)
        {
            tHeader = new T_Header();
            data = 0.0f;
            dummy = new float[10];
        }
    }

}
