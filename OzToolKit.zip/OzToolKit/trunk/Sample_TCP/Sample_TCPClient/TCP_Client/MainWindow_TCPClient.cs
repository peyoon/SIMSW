﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace TCP_Client
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 메인 클래스 - TCP 연동 관리 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 07월 04일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public partial class MainWindow : Window
    {
        private OzNet.TCPClient     m_cTCPClient;       // TCP 클라이언트 모듈
        private Thread              m_threadClient;     // 패킷 수신 스레드


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// TCP 클라이언트 초기화
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitTCPClient()
        {
            m_cTCPClient = new OzNet.TCPClient();
            m_cTCPClient.Event_NotifyDisconnect += DisconnectServer;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 서버 접속
        /// 파라미터 : -
        /// 반 환 값 : 서버 접속 성공 유무
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private bool ConnectServer()
        {
            bool bConnect = false;

            if (m_cTCPClient.Connect("127.0.0.1", 10001) != null)
            {
                bConnect = true;

                m_threadClient = new Thread(new ThreadStart(ProcThread_Recieve));
                m_threadClient.IsBackground = true;
                m_threadClient.Start();
            }
            
            
            return bConnect;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 서버 연동 해제
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void DisconnectServer()
        {
            // UI 초기화
            Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
            {
                InitUI();
            }));
            
            m_cTCPClient.Disconnect();
            m_threadClient?.Join(1000);
            
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 패킷 전송
        /// 파라미터 :  [in] byPacket   - 전송할 패킷 byte 배열
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Send(byte[] byPacket)
        {
            m_cTCPClient.Send(byPacket, byPacket.Length);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// [스레드 수행] 패킷 수신 및 패킷 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcThread_Recieve()
        {
            int nHeaderSize = Marshal.SizeOf(typeof(ICD.T_Header));
            byte[] byHeader = new byte[nHeaderSize];
            ICD.T_Header tHeader = new ICD.T_Header();

            while (m_cTCPClient.IsClientRun() == true)
            {
                // header 수신
                byHeader = m_cTCPClient.Recieve(nHeaderSize);
                if (byHeader != null)
                {
                    tHeader = OzUtil.MarshalHelper.ByteToStructure<ICD.T_Header>(byHeader, nHeaderSize);

                    // data 수신 
                    int nDataSize = Convert.ToInt32(tHeader.dataSize);
                    byte[] byRecvData = m_cTCPClient.Recieve(nDataSize);
                    if (byRecvData != null)
                    {
                        // 최종 packet 만들기
                        int nPacketSize = nHeaderSize + nDataSize;
                        byte[] byPacket = new byte[nPacketSize];

                        // 헤더랑 데이터의 바이트배열을 하나로 합침
                        Buffer.BlockCopy(byHeader, 0, byPacket, 0, nHeaderSize);
                        Buffer.BlockCopy(byRecvData, 0, byPacket, nHeaderSize, nDataSize);


                        // packet 처리
                        switch (tHeader.msgID)
                        {
                            case ICD.ICD_Exam_Const.MSG_SERVER_10:
                                {
                                    ICD.T_Msg10Hz tMsg10 = OzUtil.MarshalHelper.ByteToStructure<ICD.T_Msg10Hz>(byPacket, nPacketSize);

                                    Console.WriteLine($"Recv 10Hz: {tMsg10.data}");

                                }
                                break;

                            case ICD.ICD_Exam_Const.MSG_SERVER_50:
                                {
                                    ICD.T_Msg50Hz tMsg50 = OzUtil.MarshalHelper.ByteToStructure<ICD.T_Msg50Hz>(byPacket, nPacketSize);

                                    Console.WriteLine($"Recv 50Hz: {tMsg50.data}");
                                }
                                break;

                            case ICD.ICD_Exam_Const.MSG_SERVER_100:
                                {
                                    ICD.T_Msg100Hz tMsg100 = OzUtil.MarshalHelper.ByteToStructure<ICD.T_Msg100Hz>(byPacket, nPacketSize);

                                    Console.WriteLine($"Recv 100Hz: {tMsg100.data}");
                                }
                                break;
                            default:
                                break;
                        }


                    } // if (byRecvData != null)


                } // if (byHeader != null)


            } // while (m_cTCPClient.IsClientRun() == true)

        }



    }
}
