﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace TCP_Sever
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 메인 클래스 - TCP 서버 관리 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 07월 04일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public partial class MainWindow : Window
    {
        private uint                        m_unClientId = 0;           // 클라이언트 ID
        private Dictionary<Socket, uint>    m_dicClientInfo = null;     // 연동 클라이언트 리스트

        private OzNet.TCPServer           m_TCPServer = null;         // TCP 서버 모듈


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// TCP 서버 초기화
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitTCPServer()
        {
            m_dicClientInfo = new Dictionary<Socket, uint>();

            m_TCPServer = new OzNet.TCPServer(10001);
            m_TCPServer.Event_NotifyConnectClient += ProcEvent_NotifyConnectClient;
            m_TCPServer.Event_NotifyDisconnectClient += ProcEvent_NotifyDisconnectClient;
            m_TCPServer.Event_NotifyReceived += ProcEvent_NotifyReceived;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 서버 시작
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void StartSever()
        {
            m_unClientId = 0;            
            m_TCPServer.StartServer();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 서버 종료
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void StopServer()
        {
            m_TCPServer.StopServer();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 패킷 전송
        /// 파라미터 :  [in] socketClient   - 클라이언트 소켓
        ///             [in] byPacket       - 전송할 패킷 byte 배열
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Send(Socket socketClient, byte[] byPacket)
        {
            m_TCPServer.Send(socketClient, byPacket);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// [이벤트 수행] 클라이언트 접속 알림 이벤트
        /// 파라미터 :  [in] socketClient   - 접속 클라이언트 소켓
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcEvent_NotifyConnectClient(Socket socketClient)
        {
            m_dicClientInfo.Add(socketClient, m_unClientId);
            m_unClientId++;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// [이벤트 수행] 클라이언트 접속 종료 알림 이벤트
        /// 파라미터 :  [in] socketClient   - 종료 클라이언트 소켓
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcEvent_NotifyDisconnectClient(Socket socketClient)
        {
            m_dicClientInfo.Remove(socketClient);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// [이벤트 수행] 클라이언트 패킷 수신 알림 이벤트
        /// 파라미터 :  [in] socketClient   - 신규 클라이언트 소켓
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcEvent_NotifyReceived(Socket socketClient)
        {
            // 패킷 수신 및 처리
            RecvPacketAndProc(socketClient);
        }
        

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 패킷 수신 및 패킷 처리
        /// 파라미터 :  [in] socketClient   - 클라이언트 소켓
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void RecvPacketAndProc(Socket socketClient)
        {
            // socket으로 id 찾기
            uint unClientID;
            if (m_dicClientInfo.TryGetValue(socketClient, out unClientID) == true)
            {
                int nHeaderSize = Marshal.SizeOf(typeof(ICD.T_Header));
                byte[] byHeader = new byte[nHeaderSize];
                ICD.T_Header tHeader = new ICD.T_Header();

                // header 수신
                byHeader = m_TCPServer.Recieve(socketClient, nHeaderSize);
                if (byHeader != null)
                {
                    tHeader = OzUtil.MarshalHelper.ByteToStructure<ICD.T_Header>(byHeader, nHeaderSize);

                    // data 수신 
                    int nDataSize = Convert.ToInt32(tHeader.dataSize);
                    byte[] byRecvData = m_TCPServer.Recieve(socketClient, nDataSize);
                    if (byRecvData != null)
                    {
                        // 최종 packet 만들기
                        int nPacketSize = nHeaderSize + nDataSize;
                        byte[] byPacket = new byte[nPacketSize];

                        // 헤더랑 데이터의 바이트배열을 하나로 합침
                        Buffer.BlockCopy(byHeader, 0, byPacket, 0, nHeaderSize);
                        Buffer.BlockCopy(byRecvData, 0, byPacket, nHeaderSize, nDataSize);


                        // packet 처리
                        switch (tHeader.msgID)
                        {
                            case ICD.ICD_Exam_Const.MSG_CLIENT_10:
                                {
                                    ICD.T_Msg10Hz tMsg10 = OzUtil.MarshalHelper.ByteToStructure<ICD.T_Msg10Hz>(byPacket, nPacketSize);

                                    Console.WriteLine($"Recv 10Hz: {unClientID}, {tMsg10.data}");

                                }
                                break;

                            case ICD.ICD_Exam_Const.MSG_CLIENT_50:
                                {
                                    ICD.T_Msg50Hz tMsg50 = OzUtil.MarshalHelper.ByteToStructure<ICD.T_Msg50Hz>(byPacket, nPacketSize);

                                    Console.WriteLine($"Recv 50Hz: {unClientID}, {tMsg50.data}");
                                }
                                break;

                            case ICD.ICD_Exam_Const.MSG_CLIENT_100:
                                {
                                    ICD.T_Msg100Hz tMsg100 = OzUtil.MarshalHelper.ByteToStructure<ICD.T_Msg100Hz>(byPacket, nPacketSize);

                                    Console.WriteLine($"Recv 100Hz: {unClientID}, {tMsg100.data}");
                                }
                                break;
                            default:
                                break;
                        }


                    } // if (byRecvData == null)

                } // if (byHeader == null)


            } // if (m_dicClientInfo.TryGetValue


        }


    }
}
