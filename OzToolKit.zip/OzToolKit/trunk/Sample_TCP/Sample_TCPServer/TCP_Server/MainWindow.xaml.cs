﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCP_Sever
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 메인 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 07월 04일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public partial class MainWindow : Window
    {
        private Thread m_threadSend10Hz;        // 10hz 전송 스레드
        private Thread m_threadSend50Hz;        // 50hz 전송 스레드
        private Thread m_threadSend100Hz;       // 100hz 전송 스레드

        private bool    m_bSend10Hz = false;    // 10hz 전송 스레드 플래그
        private bool    m_bSend50Hz = false;    // 50hz 전송 스레드 플래그
        private bool    m_bSend100Hz = false;   // 100hz 전송 스레드 플래그


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 생성자
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public MainWindow()
        {
            InitializeComponent();

            // TCP 서버 초기화
            InitTCPServer();

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// UI초기화 - 모든 Send 스레드 중지
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitUI()
        {
            // 스레드 중지
            m_bSend10Hz = false;
            m_threadSend10Hz?.Join();

            m_bSend50Hz = false;
            m_threadSend10Hz?.Join();

            m_bSend100Hz = false;
            m_threadSend10Hz?.Join();

            // UI 초기화
            uiToggleButton_10Hz.IsChecked = false;
            uiToggleButton_50Hz.IsChecked = false;
            uiToggleButton_100Hz.IsChecked = false;
                        
            uiGroupBox_Send.IsEnabled = false;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// [스레드 수행] 10hz 전송
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcThread_Send10Hz()
        {
            // 패킷 생성
            ICD.T_Msg10Hz tMsg = new ICD.T_Msg10Hz(true);
            tMsg.tHeader.msgID = ICD.ICD_Exam_Const.MSG_SERVER_10;
            tMsg.tHeader.dataSize = (uint)(Marshal.SizeOf(new ICD.T_Msg10Hz()) - Marshal.SizeOf(new ICD.T_Header()));

            while (m_bSend10Hz == true)
            {
                byte[] byPacket = OzUtil.MarshalHelper.StructToByte<ICD.T_Msg10Hz>(tMsg);

                try
                {
                    // 연동된 모든 클라이언트에 전송
                    foreach (Socket socketClient in m_dicClientInfo.Keys)
                    {
                        Send(socketClient, byPacket);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"client 변경 발생. passing {ex.Message}");
                }
                

                tMsg.data += 1;
                if (tMsg.data == int.MaxValue)
                    tMsg.data = int.MinValue;

                Thread.Sleep(100);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// [스레드 수행] 50hz 전송
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcThread_Send50Hz()
        {
            // 패킷 생성
            ICD.T_Msg50Hz tMsg = new ICD.T_Msg50Hz(true);
            tMsg.tHeader.msgID = ICD.ICD_Exam_Const.MSG_SERVER_50;
            tMsg.tHeader.dataSize = (uint)(Marshal.SizeOf(new ICD.T_Msg50Hz()) - Marshal.SizeOf(new ICD.T_Header()));

            while (m_bSend50Hz == true)
            {
                byte[] byPacket = OzUtil.MarshalHelper.StructToByte<ICD.T_Msg50Hz>(tMsg);

                try
                {
                    // 연동된 모든 클라이언트에 전송
                    foreach (Socket socketClient in m_dicClientInfo.Keys)
                    {
                        Send(socketClient, byPacket);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"client 변경 발생. passing {ex.Message}");
                }

                tMsg.data += 0.2;
                if (tMsg.data == double.MaxValue)
                    tMsg.data = double.MinValue;

                Thread.Sleep(20);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// [스레드 수행] 100hz 전송
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcThread_Send100Hz()
        {
            // 패킷 생성
            ICD.T_Msg100Hz tMsg = new ICD.T_Msg100Hz(true);
            tMsg.tHeader.msgID = ICD.ICD_Exam_Const.MSG_SERVER_100;
            tMsg.tHeader.dataSize = (uint)(Marshal.SizeOf(new ICD.T_Msg100Hz()) - Marshal.SizeOf(new ICD.T_Header()));

            while (m_bSend100Hz == true)
            {
                byte[] byPacket = OzUtil.MarshalHelper.StructToByte<ICD.T_Msg100Hz>(tMsg);

                try
                {
                    // 연동된 모든 클라이언트에 전송                
                    foreach (Socket socketClient in m_dicClientInfo.Keys)
                    {
                        Send(socketClient, byPacket);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"client 변경 발생. passing {ex.Message}");                    
                }

                tMsg.data += 0.1f;
                if (tMsg.data == float.MaxValue)
                    tMsg.data = float.MinValue;

                Thread.Sleep(10);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 서버 시작 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_Connect(object sender, RoutedEventArgs e)
        {
            Button bt = sender as Button;

            // 서버 작동중 -> 서버 중지
            if (m_TCPServer.IsRunServer() == true)
            {
                InitUI();

                StopServer();

                bt.Content = "서버 시작";

                uiLEDLabel_Status.LEDStatus = OzUC.E_LEDStatus.Off;
                uiLEDLabel_Status.Content = "서버 중지";            
            }
            // 서버 중지 -> 서버 시작
            else
            {
                uiGroupBox_Send.IsEnabled = true;

                StartSever();

                bt.Content = "서버 중지";

                uiLEDLabel_Status.LEDStatus = OzUC.E_LEDStatus.On;
                uiLEDLabel_Status.Content = "서버 작동중";
            }
                
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 10Hz 전송 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_ToggleButton_10Hz(object sender, RoutedEventArgs e)
        {
            ToggleButton tbt = sender as ToggleButton;

            if (m_TCPServer.IsRunServer() == true)
            {
                // 전송 시작
                if (tbt.IsChecked == true)
                {
                    m_bSend10Hz = true;
                    m_threadSend10Hz = new Thread(new ThreadStart(ProcThread_Send10Hz));
                    m_threadSend10Hz.IsBackground = true;
                    m_threadSend10Hz.Start();
                }
                // 전송 중지
                else
                {
                    m_bSend10Hz = false;
                    m_threadSend10Hz.Join();
                }
            }
            else
            {
                tbt.IsChecked = false;
            }

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 50Hz 전송 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_ToggleButton_50Hz(object sender, RoutedEventArgs e)
        {
            ToggleButton tbt = sender as ToggleButton;

            if (m_TCPServer.IsRunServer() == true)
            {
                // 전송 시작
                if (tbt.IsChecked == true)
                {
                    m_bSend50Hz = true;
                    m_threadSend50Hz = new Thread(new ThreadStart(ProcThread_Send50Hz));
                    m_threadSend50Hz.IsBackground = true;
                    m_threadSend50Hz.Start();
                }
                // 전송 중지
                else
                {
                    m_bSend50Hz = false;
                    m_threadSend50Hz.Join();
                }
            }
            else
            {
                tbt.IsChecked = false;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 100Hz 전송 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 07월 04일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_ToggleButton_100Hz(object sender, RoutedEventArgs e)
        {
            ToggleButton tbt = sender as ToggleButton;

            if (m_TCPServer.IsRunServer() == true)
            {
                // 전송 시작
                if (tbt.IsChecked == true)
                {
                    m_bSend100Hz = true;
                    m_threadSend100Hz = new Thread(new ThreadStart(ProcThread_Send100Hz));
                    m_threadSend100Hz.IsBackground = true;
                    m_threadSend100Hz.Start();
                }
                // 전송 중지
                else
                {
                    m_bSend100Hz = false;
                    m_threadSend100Hz.Join();
                }
            }
            else
            {
                tbt.IsChecked = false;
            }
        }


    }
}
