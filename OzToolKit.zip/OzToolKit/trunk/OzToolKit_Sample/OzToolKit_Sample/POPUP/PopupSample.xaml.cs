﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OzToolKit_Sample
{    
    public partial class PopupSample : Window
    {
        bool m_bModal;


        public PopupSample(bool bModal = true)
        {
            InitializeComponent();

            // Modal, Modaless 구분
            m_bModal = bModal;
        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // 모달리스 팝업윈도우는 Cancel 하고 Hide하여야 메모리 삭제가 안된다.
            if (m_bModal == false)
            {
                e.Cancel = true;
                this.Hide();
            }            
        }

        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
            // 팝업일때 타이틀바 때문에 타이틀바 크기 만큼 공간이 생긴다.
            // 디자인 후 Height 값을 타이틀바 크기(30)만큼 줄이거나.. 
            // Show 할때 Height 값을 타이틀바 크기(30)만큼 뺀다.
            // 반드시 할 필요는 없다. 상황에 따라 설정한다.
            //this.Height -= 30;            
        }
    }
}
