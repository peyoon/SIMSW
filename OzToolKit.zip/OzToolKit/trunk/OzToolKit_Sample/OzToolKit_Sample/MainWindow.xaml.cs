﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Runtime.InteropServices;

namespace OzToolKit_Sample
{
    public partial class MainWindow : Window
    {
        

        private PopupSample m_ModalessPopup;

        public MainWindow()
        {
            InitializeComponent();

            m_ModalessPopup = new PopupSample(false);

        }

        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
            // 리사이즈 막기
            //this.ResizeMode = ResizeMode.NoResize;

            // 최소화/최대화 버튼 제거
            //this.WindowStyle = WindowStyle.ToolWindow;

            // 모든 버튼 제거
            //this.WindowStyle = WindowStyle.None;

        }

        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("프로그램을 종료할까요?", "종료 확인", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
            {
                Environment.Exit(0); //모두 종료
                System.Diagnostics.Process.GetCurrentProcess().Kill(); //관련프로세스 강제 종료
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void Click_Menu_Modal_Popup(object sender, RoutedEventArgs e)
        {
            PopupSample popup = new PopupSample();

            popup.ShowDialog();
        }

        private void Click_Menu_Modaless_Popup(object sender, RoutedEventArgs e)
        {
            m_ModalessPopup.Show();
        }

        private void Click_Button_ExcelExport(object sender, RoutedEventArgs e)
        {
            string TEMPLATE_FILE = "\\ExcelExport\\template.xlsx";

            OzUtil.OzExcel cExcel = new OzUtil.OzExcel();

            string strTempPath = System.Environment.CurrentDirectory + TEMPLATE_FILE;
            string strCopyPath = System.Environment.CurrentDirectory + "\\ExcelExport\\Output.xlsx";

            System.IO.File.Copy(strTempPath, strCopyPath, true);


            if (cExcel.Open(strCopyPath))
            {
                // 첫번째 worksheet
                //Microsoft.Office.Interop.Excel.Worksheet worksheet = cExcel.GetWorksheet(1);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = cExcel.GetWorksheet("생성테스트");
                if (worksheet != null)
                {
                    Microsoft.Office.Interop.Excel.Range rg;

                    // 생성일시
                    rg = worksheet.Range["C4"];
                    rg.Value = DateTime.Now.ToString();
                    Marshal.ReleaseComObject(rg);

                    // 작성자
                    rg = worksheet.Range["C5"];
                    rg.Value = "작성자";
                    Marshal.ReleaseComObject(rg);

                    // DATA
                    Microsoft.Office.Interop.Excel.Range rgA, rgB, rgC, rgSum;

                    Random rand = new Random();
                    for (int cellcnt = 0; cellcnt < 20; cellcnt++)
                    {
                        rgA = worksheet.Cells[9 + cellcnt, 3];
                        rgB = worksheet.Cells[9 + cellcnt, 4];
                        rgC = worksheet.Cells[9 + cellcnt, 5];
                        rgSum = worksheet.Cells[9 + cellcnt, 6];


                        rgA.Value = rand.Next(100);
                        rgB.Value = rand.Next(100);
                        rgC.Value = rand.Next(100);
                        rgSum.Formula = string.Format($"=sum(C{9 + cellcnt}:E{9 + cellcnt})");

                        Marshal.ReleaseComObject(rgA);
                        Marshal.ReleaseComObject(rgB);
                        Marshal.ReleaseComObject(rgC);
                        Marshal.ReleaseComObject(rgSum);
                    }


                    // 이미지

                    // 이미지 저장
                    string strName = string.Format("\\ExcelExport\\test.png");
                    string strPath = System.Environment.CurrentDirectory + strName;

                    int width = (int)SystemParameters.PrimaryScreenWidth;
                    int height = (int)SystemParameters.PrimaryScreenHeight;
                    int x = (int)this.Left;
                    int y = (int)this.Top;
                    width = (int)this.ActualWidth;
                    height = (int)this.ActualHeight;

                    using (System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(width, height, System.Drawing.Imaging.PixelFormat.Format32bppArgb))
                    {
                        using (System.Drawing.Graphics gr = System.Drawing.Graphics.FromImage(bmp))
                        {
                            gr.CopyFromScreen(x, y, 0, 0, bmp.Size);
                        }
                        bmp.Save(strPath, System.Drawing.Imaging.ImageFormat.Png);
                    }

                    // 시트에 이미지 넣기
                    rg = worksheet.Range["B32", "F54"];
                    Microsoft.Office.Interop.Excel.Pictures pictures = worksheet.Pictures(Type.Missing) as Microsoft.Office.Interop.Excel.Pictures;
                    Microsoft.Office.Interop.Excel.Picture picture = pictures.Insert(strPath, Type.Missing);  // 파일 경로시
                    picture.Left = (double)rg.Left;
                    picture.Top = (double)rg.Top;
                    picture.Width = (double)rg.Width;
                    picture.Height = (double)rg.Height;

                    Marshal.ReleaseComObject(rg);

                }

                // 저장만 할때
                //cExcel.Save();

                // 저장 및 종료 할때
                cExcel.Close();

                // 엑셀 실행
                System.Diagnostics.Process.Start(strCopyPath);
            }
        }

        private void ucBaseControl_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
