﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OzToolKit_Sample
{
    /// <summary>
    /// ucDataGrid.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ucDataGrid : UserControl
    {
        public enum EGrade : int
        {
            _1 = 0,
            _2,
            _3,
            _4
        }

        public static List<string> m_listGradeString { get; } = new List<string>() { "1학년", "2학년", "3학년", "4학년" };

        public class Data
        {
            public string name { get; set; }
            public string id { get; set; }
            public string major { get; set; }

            public EGrade grade { get; set; }

            public string etc { get; set; }


            // binding용
            public int Grade
            {
                get
                {
                    return (int)grade;
                }
                set
                {
                    grade = (EGrade)value;
                }
            }

            public string GradeStr
            {
                get
                {
                    return m_listGradeString[(int)grade];
                }                
            }
        }
                

        List<Data> listJYP = new List<Data>();

        public ucDataGrid()
        {
            InitializeComponent();

            List<Data> listHibe = new List<Data>();
            listHibe.Add(new Data { name = "진", id = "210651", major = "하이브", grade = EGrade._3, etc = "방탄" });
            listHibe.Add(new Data { name = "슈가", id = "210184", major = "하이브", grade = EGrade._3, etc = "방탄" });
            listHibe.Add(new Data { name = "RM", id = "210017", major = "하이브", grade = EGrade._3, etc = "방탄" });
            listHibe.Add(new Data { name = "제이홉", id = "210439", major = "하이브", grade = EGrade._3, etc = "방탄" });
            listHibe.Add(new Data { name = "뷔", id = "210005", major = "하이브", grade = EGrade._3, etc = "방탄" });
            listHibe.Add(new Data { name = "지민", id = "210005", major = "하이브", grade = EGrade._3, etc = "방탄" });
            listHibe.Add(new Data { name = "정국", id = "210005", major = "하이브", grade = EGrade._3, etc = "방탄" });
            listHibe.Add(new Data { name = "민지", id = "210651", major = "하이브", grade = EGrade._1, etc = "뉴진스" });
            listHibe.Add(new Data { name = "해린", id = "210184", major = "하이브", grade = EGrade._1, etc = "뉴진스" });
            listHibe.Add(new Data { name = "다니엘", id = "210017", major = "하이브", grade = EGrade._1, etc = "뉴진스" });
            listHibe.Add(new Data { name = "하니", id = "210439", major = "하이브", grade = EGrade._1, etc = "뉴진스" });
            listHibe.Add(new Data { name = "해인", id = "210005", major = "하이브", grade = EGrade._1, etc = "뉴진스" });
            listHibe.Add(new Data { name = "김채원", id = "210651", major = "하이브", grade = EGrade._2, etc = "르세라핌" });
            listHibe.Add(new Data { name = "사쿠라", id = "210184", major = "하이브", grade = EGrade._2, etc = "르세라핌" });
            listHibe.Add(new Data { name = "허윤진", id = "210017", major = "하이브", grade = EGrade._2, etc = "르세라핌" });
            listHibe.Add(new Data { name = "카즈하", id = "210439", major = "하이브", grade = EGrade._2, etc = "르세라핌" });
            listHibe.Add(new Data { name = "홍은채", id = "210005", major = "하이브", grade = EGrade._2, etc = "르세라핌" });
            uiDataGrid_Hibe.ItemsSource = listHibe;

            
            listJYP.Add(new Data { name = "박진영", id = "210651", major = "JYP Ent", grade = EGrade._3, etc = "CEO" });
            listJYP.Add(new Data { name = "나연", id = "210651", major = "JYP Ent", grade = EGrade._3, etc = "트와이스" });
            listJYP.Add(new Data { name = "정연", id = "210184", major = "JYP Ent", grade = EGrade._3, etc = "트와이스" });
            listJYP.Add(new Data { name = "모모", id = "210017", major = "JYP Ent", grade = EGrade._3, etc = "트와이스" });
            listJYP.Add(new Data { name = "사나", id = "210439", major = "JYP Ent", grade = EGrade._3, etc = "트와이스" });
            listJYP.Add(new Data { name = "지효", id = "210005", major = "JYP Ent", grade = EGrade._3, etc = "트와이스" });
            listJYP.Add(new Data { name = "미나", id = "210005", major = "JYP Ent", grade = EGrade._3, etc = "트와이스" });
            listJYP.Add(new Data { name = "다현", id = "210005", major = "JYP Ent", grade = EGrade._3, etc = "트와이스" });
            listJYP.Add(new Data { name = "채영", id = "210651", major = "JYP Ent", grade = EGrade._1, etc = "트와이스" });
            listJYP.Add(new Data { name = "쯔위", id = "210184", major = "JYP Ent", grade = EGrade._1, etc = "트와이스" });
            listJYP.Add(new Data { name = "방찬", id = "210017", major = "JYP Ent", grade = EGrade._1, etc = "스트레이 키즈" });
            listJYP.Add(new Data { name = "리노", id = "210439", major = "JYP Ent", grade = EGrade._1, etc = "스트레이 키즈" });
            listJYP.Add(new Data { name = "창빈", id = "210005", major = "JYP Ent", grade = EGrade._1, etc = "스트레이 키즈" });
            listJYP.Add(new Data { name = "현진", id = "210651", major = "JYP Ent", grade = EGrade._2, etc = "스트레이 키즈" });
            listJYP.Add(new Data { name = "한", id = "210184", major = "JYP Ent", grade = EGrade._2, etc = "스트레이 키즈" });
            listJYP.Add(new Data { name = "필릭스", id = "210017", major = "JYP Ent", grade = EGrade._2, etc = "스트레이 키즈" });
            listJYP.Add(new Data { name = "승민", id = "210439", major = "JYP Ent", grade = EGrade._2, etc = "스트레이 키즈" });
            listJYP.Add(new Data { name = "아이엔", id = "210005", major = "JYP Ent", grade = EGrade._2, etc = "스트레이 키즈" });

            uiDataGrid_JYP.ItemsSource = listJYP;
        }

        private void SelectionChanged_Datagrid(object sender, SelectionChangedEventArgs e)
        {
            int a = 0;
        }
    }
}
