﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OzToolKit_Sample
{
    /// <summary>
    /// ucUserControl.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ucUserControl : UserControl
    {
        public ucUserControl()
        {
            InitializeComponent();
        }

        private void Click_Button_LEDCtrl_Idle(object sender, RoutedEventArgs e)
        {
            uiLEDEllipse.LEDStatus = OzUC.E_LEDStatus.Idle;
            uiLEDEllipse_Color.LEDStatus = OzUC.E_LEDStatus.Idle;

            uiLEDRectangle.LEDStatus = OzUC.E_LEDStatus.Idle;
            uiLEDRectangle_Color.LEDStatus = OzUC.E_LEDStatus.Idle;

            uiLEDLabel.LEDStatus = OzUC.E_LEDStatus.Idle;
            uiLEDLabel_Color.LEDStatus = OzUC.E_LEDStatus.Idle;
        }

        private void Click_Button_LEDCtrl_Off(object sender, RoutedEventArgs e)
        {
            uiLEDEllipse.LEDStatus = OzUC.E_LEDStatus.Off;
            uiLEDEllipse_Color.LEDStatus = OzUC.E_LEDStatus.Off;

            uiLEDRectangle.LEDStatus = OzUC.E_LEDStatus.Off;
            uiLEDRectangle_Color.LEDStatus = OzUC.E_LEDStatus.Off;

            uiLEDLabel.LEDStatus = OzUC.E_LEDStatus.Off;
            uiLEDLabel_Color.LEDStatus = OzUC.E_LEDStatus.Off;

            uiLEDComboBox.SelectedIndex = 0;
            uiLEDComboBox_Color.SelectedIndex = 0;

            uiLEDTextBox.Text = "0000";
            uiLEDTextBox_Color.Text = "0000";
        }

        private void Click_Button_LEDCtrl_On(object sender, RoutedEventArgs e)
        {
            uiLEDEllipse.LEDStatus = OzUC.E_LEDStatus.On;
            uiLEDEllipse_Color.LEDStatus = OzUC.E_LEDStatus.On;

            uiLEDRectangle.LEDStatus = OzUC.E_LEDStatus.On;
            uiLEDRectangle_Color.LEDStatus = OzUC.E_LEDStatus.On;

            uiLEDLabel.LEDStatus = OzUC.E_LEDStatus.On;
            uiLEDLabel_Color.LEDStatus = OzUC.E_LEDStatus.On;

            uiLEDComboBox.SelectedIndex = 1;
            uiLEDComboBox_Color.SelectedIndex = 1;

            uiLEDTextBox.Text = "1111";
            uiLEDTextBox_Color.Text = "1111";
        }

        private void Click_Button_LEDCtrl_Start(object sender, RoutedEventArgs e)
        {
            uiLEDEllipse_Ani.AnimationBegin();
            uiLEDEllipse_Color_Ani.AnimationBegin();

            uiLEDRectangle_Ani.AnimationBegin();
            uiLEDRectangle_Color_Ani.AnimationBegin();

            uiLEDLabel_Ani.AnimationBegin();
            uiLEDLabel_Color_Ani.AnimationBegin();

            uiLEDComboBox_Ani.AnimationBegin();
            uiLEDComboBox_Color_Ani.AnimationBegin();

            uiLEDTextBox_Ani.AnimationBegin();
            uiLEDTextBox_Color_Ani.AnimationBegin();
        }

        private void Click_Button_LEDCtrl_Stop(object sender, RoutedEventArgs e)
        {
            uiLEDEllipse_Ani.AnimationStop();
            uiLEDEllipse_Color_Ani.AnimationStop();

            uiLEDRectangle_Ani.AnimationStop();
            uiLEDRectangle_Color_Ani.AnimationStop();

            uiLEDLabel_Ani.AnimationStop();
            uiLEDLabel_Color_Ani.AnimationStop();

            uiLEDComboBox_Ani.AnimationStop();
            uiLEDComboBox_Color_Ani.AnimationStop();

            uiLEDTextBox_Ani.AnimationStop();
            uiLEDTextBox_Color_Ani.AnimationStop();
        }
    }
}
