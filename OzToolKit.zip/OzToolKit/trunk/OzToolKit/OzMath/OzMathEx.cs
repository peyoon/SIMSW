﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzMath
{
    public class OzMathEx
    {

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 입력 값 범위 체크        
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] value  - 비교값
        /// <br/>       [in] min    - 최소값
        /// <br/>       [in] max    - 최대값
        /// <br/> 
        /// <br/> 반 환 값 : 범위 체크 결과 값 반환
        /// <br/> min 보다 작으면 min 
        /// <br/> max 보다 크면 max
        /// <br/> 그 외는 value
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 08월 01일
        /// </summary>  
        /// <typeparam name="T"></typeparam>
        /// <param name="value">    [in] 비교값   </param>
        /// <param name="min">      [in] 최소값   </param>
        /// <param name="max">      [in] 최대값   </param>
        /// <returns></returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
        public static T Clamp<T>(T value, T min, T max) where T : IComparable<T>
        {
            T result;

            if (value.CompareTo(min) < 0)
                result = min;
            else if (value.CompareTo(max) > 0)
                result = max;
            else
                result = value;

            return result;
        }




    }


}
