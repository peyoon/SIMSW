﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzUC
{
    // LED 관련 UC 상태 열거 값
    public enum E_LEDStatus : int
    {
        Idle = 0,       // 대기
        Off,            // OFF
        On,             // ON
    }

}
